import express, { type Express } from "express";
import cors from "cors";
import pinoHttp from "pino-http";
import { existsSync } from "node:fs";
import path from "node:path";
import router from "./routes";
import { logger } from "./lib/logger";
import { sessionMiddleware } from "./lib/session";

const app: Express = express();

// Trust Replit's reverse proxy so session cookies with Secure flag work correctly
app.set("trust proxy", 1);

app.use(
  pinoHttp({
    logger,
    serializers: {
      req(req) {
        return {
          id: req.id,
          method: req.method,
          url: req.url?.split("?")[0],
        };
      },
      res(res) {
        return {
          statusCode: res.statusCode,
        };
      },
    },
  }),
);

app.use(cors({
  origin: true,
  credentials: true,
}));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(sessionMiddleware);

app.use("/api", router);

// In external Node.js hosting, serve the built dashboard from the same
// process as the API. Replit can still use the dashboard artifact separately.
const configuredDashboardDist = process.env["DASHBOARD_DIST_PATH"];
const dashboardDist =
  configuredDashboardDist
    ? path.resolve(configuredDashboardDist)
    : [
        path.resolve(process.cwd(), "artifacts/dashboard/dist/public"),
        path.resolve(process.cwd(), "../dashboard/dist/public"),
      ].find((candidate) => existsSync(path.join(candidate, "index.html"))) ??
      path.resolve(process.cwd(), "artifacts/dashboard/dist/public");

app.use(express.static(dashboardDist));
app.get(/^(?!\/api(?:\/|$)).*/, (_req, res) => {
  res.sendFile(path.join(dashboardDist, "index.html"));
});

export default app;
