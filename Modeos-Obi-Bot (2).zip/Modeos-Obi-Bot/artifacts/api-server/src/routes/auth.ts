import { Router, type IRouter, type Request, type Response } from "express";
import { db } from "@workspace/db";
import { dashboardAdminsTable } from "@workspace/db/schema";
import { eq, and } from "drizzle-orm";
import { logger } from "../lib/logger";

const router: IRouter = Router();

const DISCORD_API = "https://discord.com/api/v10";

function getRedirectUri(req: Request): string {
  const domains = process.env["REPLIT_DOMAINS"];
  if (domains) {
    const primary = domains.split(",")[0]!.trim();
    return `https://${primary}/api/auth/discord/callback`;
  }
  const host = req.get("host") ?? "localhost";
  const proto = req.get("x-forwarded-proto") ?? "http";
  return `${proto}://${host}/api/auth/discord/callback`;
}

router.get("/auth/discord", async (req: Request, res: Response): Promise<void> => {
  const clientId = process.env["DISCORD_CLIENT_ID"];
  if (!clientId) {
    res.status(500).json({ error: "DISCORD_CLIENT_ID not configured" });
    return;
  }
  const redirectUri = getRedirectUri(req);
  const params = new URLSearchParams({
    client_id: clientId,
    redirect_uri: redirectUri,
    response_type: "code",
    scope: "identify",
  });
  res.redirect(`https://discord.com/oauth2/authorize?${params}`);
});

router.get("/auth/discord/callback", async (req: Request, res: Response): Promise<void> => {
  const code = req.query["code"];
  const clientId = process.env["DISCORD_CLIENT_ID"];
  const clientSecret = process.env["DISCORD_CLIENT_SECRET"];

  if (!clientId || !clientSecret) {
    res.redirect("/?error=not_configured");
    return;
  }
  if (typeof code !== "string") {
    res.redirect("/?error=missing_code");
    return;
  }

  try {
    const redirectUri = getRedirectUri(req);
    const tokenRes = await fetch(`${DISCORD_API}/oauth2/token`, {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body: new URLSearchParams({
        client_id: clientId,
        client_secret: clientSecret,
        grant_type: "authorization_code",
        code,
        redirect_uri: redirectUri,
      }),
    });

    if (!tokenRes.ok) {
      logger.error({ status: tokenRes.status }, "Discord token exchange failed");
      res.redirect("/?error=token_failed");
      return;
    }

    const tokenData = (await tokenRes.json()) as { access_token: string };
    const accessToken = tokenData.access_token;

    const userRes = await fetch(`${DISCORD_API}/users/@me`, {
      headers: { Authorization: `Bearer ${accessToken}` },
    });

    if (!userRes.ok) {
      res.redirect("/?error=user_fetch_failed");
      return;
    }

    const user = (await userRes.json()) as {
      id: string;
      username: string;
      global_name: string | null;
      avatar: string | null;
    };

    const adminRows = await db
      .select()
      .from(dashboardAdminsTable)
      .where(eq(dashboardAdminsTable.userId, user.id))
      .limit(1);

    if (adminRows.length === 0) {
      res.redirect("/?error=unauthorized");
      return;
    }

    req.session.discordUser = {
      id: user.id,
      username: user.username,
      globalName: user.global_name ?? null,
      avatar: user.avatar,
      guildId: adminRows[0]!.guildId,
    };

    // Explicitly save session to DB before redirecting — avoids race condition
    // where the browser follows the redirect before pg-store finishes writing.
    req.session.save((saveErr) => {
      if (saveErr) {
        logger.error({ err: saveErr }, "Session save failed");
        res.redirect("/?error=server_error");
        return;
      }
      res.redirect("/app");
    });
  } catch (err) {
    logger.error({ err }, "OAuth callback error");
    res.redirect("/?error=server_error");
  }
});

router.post("/auth/logout", async (req: Request, res: Response): Promise<void> => {
  req.session.destroy(() => {
    res.sendStatus(204);
  });
});

export default router;
