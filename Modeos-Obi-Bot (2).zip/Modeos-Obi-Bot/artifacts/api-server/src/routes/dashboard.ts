import { Router, type IRouter, type Request, type Response } from "express";
import { db } from "@workspace/db";
import {
  dashboardAdminsTable,
  vouchesTable,
  warnsTable,
  blacklistTable,
  salesTable,
  eventLogsTable,
} from "@workspace/db/schema";
import { and, desc, eq, count, sql } from "drizzle-orm";
import { removeFromBlacklist, getGuildConfig, updateGuildConfig } from "../bot/store";
import { getDiscordClient } from "../bot";
import { logEvent } from "../bot/logger-events";
import { refreshServerStatsChannels } from "../bot/server-stats-channels";
import { buildWelcomePayload } from "../bot/welcome";
import { EmbedBuilder, ChannelType, type TextChannel, type NewsChannel, PermissionFlagsBits } from "discord.js";

const router: IRouter = Router();

function requireAuth(req: Request, res: Response): boolean {
  if (!req.session.discordUser) {
    res.status(401).json({ error: "Not authenticated" });
    return false;
  }
  return true;
}

router.get("/dashboard/me", async (req: Request, res: Response): Promise<void> => {
  if (!requireAuth(req, res)) return;
  res.json(req.session.discordUser);
});

router.get("/dashboard/discord-info", async (req: Request, res: Response): Promise<void> => {
  if (!requireAuth(req, res)) return;
  const client = getDiscordClient();
  if (!client) {
    res.status(503).json({ error: "Bot no conectado" });
    return;
  }

  try {
    const guildId = req.session.discordUser!.guildId!;
    const guild = client.guilds.cache.get(guildId) ?? await client.guilds.fetch(guildId);
    await guild.members.fetch();

    const members = guild.members.cache;
    const bots = members.filter((member) => member.user.bot).size;
    const admins = members.filter((member) =>
      member.permissions.has(PermissionFlagsBits.Administrator),
    ).size;

    const channels = guild.channels.cache
      .filter((channel) => !channel.isThread())
      .sort((a, b) => a.position - b.position)
      .map((channel) => ({
        id: channel.id,
        name: channel.name,
        type: channel.type,
        parentId: channel.parentId,
      }));

    const roles = guild.roles.cache
      .filter((role) => !role.managed)
      .sort((a, b) => b.position - a.position)
      .map((role) => ({
        id: role.id,
        name: role.name,
        color: role.hexColor,
        position: role.position,
      }));

    res.json({
      guild: {
        id: guild.id,
        name: guild.name,
        icon: guild.iconURL({ size: 128 }),
        memberCount: members.size,
      },
      stats: {
        bots,
        users: members.size - bots,
        admins,
        total: members.size,
      },
      channels,
      roles,
    });
  } catch (err) {
    const message = err instanceof Error ? err.message : String(err);
    res.status(500).json({ error: message });
  }
});

router.post("/dashboard/stats-channels/refresh", async (req: Request, res: Response): Promise<void> => {
  if (!requireAuth(req, res)) return;
  const client = getDiscordClient();
  if (!client) {
    res.status(503).json({ error: "Bot no conectado" });
    return;
  }

  try {
    await refreshServerStatsChannels(client, req.session.discordUser!.guildId!);
    res.json({ ok: true, message: "Canales estadísticos actualizados." });
  } catch (err) {
    const message = err instanceof Error ? err.message : String(err);
    res.status(500).json({ ok: false, error: message });
  }
});

router.get("/dashboard/stats", async (req: Request, res: Response): Promise<void> => {
  if (!requireAuth(req, res)) return;
  const guildId = req.session.discordUser!.guildId!;

  const [vouches, warns, blacklisted, sales, events, recentEvents] = await Promise.all([
    db.select({ count: count() }).from(vouchesTable).where(eq(vouchesTable.guildId, guildId)),
    db.select({ count: count() }).from(warnsTable).where(eq(warnsTable.guildId, guildId)),
    db.select({ count: count() }).from(blacklistTable).where(eq(blacklistTable.guildId, guildId)),
    db.select({ count: count() }).from(salesTable).where(eq(salesTable.guildId, guildId)),
    db.select({ count: count() }).from(eventLogsTable).where(eq(eventLogsTable.guildId, guildId)),
    db.select({ count: count() }).from(eventLogsTable).where(
      and(
        eq(eventLogsTable.guildId, guildId),
        sql`created_at > now() - interval '24 hours'`,
      ),
    ),
  ]);

  res.json({
    totalVouches: vouches[0]!.count,
    totalWarns: warns[0]!.count,
    totalBlacklisted: blacklisted[0]!.count,
    totalSales: sales[0]!.count,
    totalEvents: events[0]!.count,
    recentEvents: recentEvents[0]!.count,
  });
});

router.get("/dashboard/logs", async (req: Request, res: Response): Promise<void> => {
  if (!requireAuth(req, res)) return;
  const guildId = req.session.discordUser!.guildId!;
  const limit = Math.min(Number(req.query["limit"] ?? 50), 200);
  const offset = Number(req.query["offset"] ?? 0);
  const eventType = typeof req.query["eventType"] === "string" ? req.query["eventType"] : undefined;

  const rows = await db
    .select()
    .from(eventLogsTable)
    .where(
      eventType
        ? and(eq(eventLogsTable.guildId, guildId), eq(eventLogsTable.eventType, eventType))
        : eq(eventLogsTable.guildId, guildId),
    )
    .orderBy(desc(eventLogsTable.createdAt))
    .limit(limit)
    .offset(offset);

  res.json(rows.map((r) => ({ ...r, createdAt: r.createdAt.toISOString() })));
});

router.get("/dashboard/blacklist", async (req: Request, res: Response): Promise<void> => {
  if (!requireAuth(req, res)) return;
  const guildId = req.session.discordUser!.guildId!;
  const rows = await db
    .select()
    .from(blacklistTable)
    .where(eq(blacklistTable.guildId, guildId))
    .orderBy(desc(blacklistTable.createdAt));
  res.json(rows.map((r) => ({ ...r, createdAt: r.createdAt.toISOString() })));
});

router.delete("/dashboard/blacklist/:userId", async (req: Request, res: Response): Promise<void> => {
  if (!requireAuth(req, res)) return;
  const guildId = req.session.discordUser!.guildId!;
  const rawUserId = Array.isArray(req.params["userId"]) ? req.params["userId"][0] : req.params["userId"];
  const userId = rawUserId ?? "";
  const removed = await removeFromBlacklist(guildId, userId);
  if (!removed) {
    res.status(404).json({ error: "Not in blacklist" });
    return;
  }
  res.sendStatus(204);
});

router.get("/dashboard/vouches", async (req: Request, res: Response): Promise<void> => {
  if (!requireAuth(req, res)) return;
  const guildId = req.session.discordUser!.guildId!;
  const limit = Math.min(Number(req.query["limit"] ?? 50), 200);
  const offset = Number(req.query["offset"] ?? 0);
  const rows = await db
    .select()
    .from(vouchesTable)
    .where(eq(vouchesTable.guildId, guildId))
    .orderBy(desc(vouchesTable.createdAt))
    .limit(limit)
    .offset(offset);
  res.json(rows.map((r) => ({ ...r, createdAt: r.createdAt.toISOString() })));
});

router.get("/dashboard/warns", async (req: Request, res: Response): Promise<void> => {
  if (!requireAuth(req, res)) return;
  const guildId = req.session.discordUser!.guildId!;
  const limit = Math.min(Number(req.query["limit"] ?? 50), 200);
  const offset = Number(req.query["offset"] ?? 0);
  const rows = await db
    .select()
    .from(warnsTable)
    .where(eq(warnsTable.guildId, guildId))
    .orderBy(desc(warnsTable.createdAt))
    .limit(limit)
    .offset(offset);
  res.json(rows.map((r) => ({ ...r, createdAt: r.createdAt.toISOString() })));
});

router.get("/dashboard/admins", async (req: Request, res: Response): Promise<void> => {
  if (!requireAuth(req, res)) return;
  const guildId = req.session.discordUser!.guildId!;
  const rows = await db
    .select()
    .from(dashboardAdminsTable)
    .where(eq(dashboardAdminsTable.guildId, guildId))
    .orderBy(desc(dashboardAdminsTable.createdAt));
  res.json(rows.map((r) => ({ ...r, createdAt: r.createdAt.toISOString() })));
});

router.post("/dashboard/admins", async (req: Request, res: Response): Promise<void> => {
  if (!requireAuth(req, res)) return;
  const { userId, guildId, userTag } = req.body as {
    userId: string;
    guildId: string;
    userTag: string;
  };
  if (!userId || !guildId || !userTag) {
    res.status(400).json({ error: "userId, guildId and userTag are required" });
    return;
  }
  const [row] = await db
    .insert(dashboardAdminsTable)
    .values({
      guildId,
      userId,
      userTag,
      addedById: req.session.discordUser!.id,
    })
    .onConflictDoNothing()
    .returning();
  if (!row) {
    res.status(409).json({ error: "Already has access" });
    return;
  }
  res.status(201).json({ ...row, createdAt: row.createdAt.toISOString() });
});

router.delete("/dashboard/admins/:userId", async (req: Request, res: Response): Promise<void> => {
  if (!requireAuth(req, res)) return;
  const guildId = req.session.discordUser!.guildId!;
  const rawUserId = Array.isArray(req.params["userId"]) ? req.params["userId"][0] : req.params["userId"];
  const userId = rawUserId ?? "";
  const [removed] = await db
    .delete(dashboardAdminsTable)
    .where(
      and(
        eq(dashboardAdminsTable.guildId, guildId),
        eq(dashboardAdminsTable.userId, userId),
      ),
    )
    .returning();
  if (!removed) {
    res.status(404).json({ error: "Not found" });
    return;
  }
  res.sendStatus(204);
});

router.get("/dashboard/admins/detected", async (req: Request, res: Response): Promise<void> => {
  if (!requireAuth(req, res)) return;
  const guildId = req.session.discordUser!.guildId!;

  const client = getDiscordClient();
  if (!client) {
    res.status(503).json({ error: "Bot no conectado" });
    return;
  }

  try {
    const guild = client.guilds.cache.get(guildId) ?? await client.guilds.fetch(guildId);
    await guild.members.fetch();

    const detected = guild.members.cache
      .filter((m) =>
        !m.user.bot &&
        m.permissions.has(PermissionFlagsBits.Administrator),
      )
      .map((m) => ({
        id: m.user.id,
        username: m.user.username,
        displayName: m.displayName,
        avatar: m.user.avatar,
        roles: m.roles.cache
          .filter((r) => r.id !== guild.id)
          .map((r) => ({ id: r.id, name: r.name, color: r.hexColor }))
          .slice(0, 4),
      }));

    res.json(detected);
  } catch (err) {
    const msg = err instanceof Error ? err.message : String(err);
    res.status(500).json({ error: msg });
  }
});

router.get("/dashboard/sales", async (req: Request, res: Response): Promise<void> => {
  if (!requireAuth(req, res)) return;
  const guildId = req.session.discordUser!.guildId!;
  const limit = Math.min(Number(req.query["limit"] ?? 50), 200);
  const offset = Number(req.query["offset"] ?? 0);
  const rows = await db
    .select()
    .from(salesTable)
    .where(eq(salesTable.guildId, guildId))
    .orderBy(desc(salesTable.createdAt))
    .limit(limit)
    .offset(offset);
  res.json(rows.map((r) => ({ ...r, createdAt: r.createdAt.toISOString() })));
});

router.get("/dashboard/config", async (req: Request, res: Response): Promise<void> => {
  if (!requireAuth(req, res)) return;
  const guildId = req.session.discordUser!.guildId!;
  const cfg = await getGuildConfig(guildId);
  res.json(cfg);
});

router.patch("/dashboard/config", async (req: Request, res: Response): Promise<void> => {
  if (!requireAuth(req, res)) return;
  const guildId = req.session.discordUser!.guildId!;
  const allowedKeys = [
    "verifiedRoleId", "staffRoleId", "announcementChannelId", "welcomeChannelId",
    "salesChannelId", "vouchChannelId", "ticketsCategoryId", "logChannelId",
    "verificationChannelId", "welcomeTitle", "welcomeMessage", "welcomeFooter",
    "welcomeColor",
  ];
  const booleanKeys = [
    "welcomeEnabled", "verificationEnabled", "loggingEnabled",
    "statsChannelsEnabled", "announcementsEnabled", "salesEnabled",
    "vouchesEnabled", "ticketsEnabled",
    "memberJoinAlertsEnabled", "memberLeaveAlertsEnabled",
    "moderationAlertsEnabled", "messageAlertsEnabled", "channelAlertsEnabled",
    "roleAlertsEnabled", "verificationAlertsEnabled", "announcementAlertsEnabled",
    "saleAlertsEnabled", "vouchAlertsEnabled", "ticketAlertsEnabled",
    "setupAlertsEnabled",
  ];
  const patch: Record<string, string | null | boolean> = {};
  for (const key of allowedKeys) {
    if (key in req.body) {
      const val = req.body[key];
      patch[key] = typeof val === "string" && val.trim() !== "" ? val.trim() : null;
    }
  }
  for (const key of booleanKeys) {
    if (key in req.body && typeof req.body[key] === "boolean") {
      patch[key] = req.body[key];
    }
  }
  const updated = await updateGuildConfig(guildId, patch);
  res.json(updated);
});

router.post("/dashboard/welcome/test", async (req: Request, res: Response): Promise<void> => {
  if (!requireAuth(req, res)) return;
  const guildId = req.session.discordUser!.guildId!;
  const cfg = await getGuildConfig(guildId);

  if (!cfg.welcomeEnabled) {
    res.status(409).json({ ok: false, message: "El módulo de bienvenida está desactivado." });
    return;
  }
  if (!cfg.welcomeChannelId) {
    res.status(400).json({ ok: false, message: "Configura primero un canal de bienvenida." });
    return;
  }

  const client = getDiscordClient();
  if (!client) {
    res.status(503).json({ ok: false, message: "Bot no conectado." });
    return;
  }

  try {
    const guild = client.guilds.cache.get(guildId) ?? await client.guilds.fetch(guildId);
    const channel = await guild.channels.fetch(cfg.welcomeChannelId).catch(() => null);
    if (!channel || channel.type !== ChannelType.GuildText) {
      res.status(400).json({ ok: false, message: "El canal de bienvenida no existe o no es de texto." });
      return;
    }

    const discordUser = req.session.discordUser!;
    const member = await guild.members.fetch(discordUser.id).catch(() => null);
    const payload = buildWelcomePayload(
      {
        memberId: discordUser.id,
        memberMention: `<@${discordUser.id}>`,
        memberAvatarUrl: member?.user.displayAvatarURL({ size: 256 }),
        guildName: guild.name,
        memberCount: guild.memberCount,
      },
      cfg,
    );

    await channel.send(payload);
    res.json({ ok: true, message: `Mensaje de prueba enviado en #${channel.name}.` });
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);
    res.status(500).json({ ok: false, message: `No se pudo enviar la prueba: ${message}` });
  }
});

router.post("/dashboard/announcements", async (req: Request, res: Response): Promise<void> => {
  if (!requireAuth(req, res)) return;
  const guildId = req.session.discordUser!.guildId!;
  const actorId = req.session.discordUser!.id;
  const actorTag = req.session.discordUser!.username;
  const cfg = await getGuildConfig(guildId);
  if (!cfg.announcementsEnabled) {
    res.status(409).json({ ok: false, message: "El módulo de anuncios está desactivado desde Configuración." });
    return;
  }

  const {
    channelId,
    title,
    description,
    color = "#9333ea",
    imageUrl,
    thumbnailUrl,
    authorName,
    authorIconUrl,
    footerText,
    footerIconUrl,
    mentionEveryone = false,
  } = req.body as {
    channelId: string;
    title?: string;
    description?: string;
    color?: string;
    imageUrl?: string;
    thumbnailUrl?: string;
    authorName?: string;
    authorIconUrl?: string;
    footerText?: string;
    footerIconUrl?: string;
    mentionEveryone?: boolean;
  };

  if (!channelId) {
    res.status(400).json({ ok: false, message: "channelId es requerido" });
    return;
  }
  if (!title && !description) {
    res.status(400).json({ ok: false, message: "Se requiere al menos título o descripción" });
    return;
  }

  const client = getDiscordClient();
  if (!client) {
    res.status(503).json({ ok: false, message: "Bot no conectado" });
    return;
  }

  try {
    const guild = client.guilds.cache.get(guildId) ?? await client.guilds.fetch(guildId);
    const channel = guild.channels.cache.get(channelId) ?? await guild.channels.fetch(channelId).catch(() => null);

    if (!channel || !(channel.type === ChannelType.GuildText || channel.type === ChannelType.GuildAnnouncement)) {
      res.status(400).json({ ok: false, message: "Canal no encontrado o no es de texto" });
      return;
    }

    const colorInt = parseInt(color.replace("#", ""), 16);

    const embed = new EmbedBuilder()
      .setColor(isNaN(colorInt) ? 0x9333ea : colorInt)
      .setTimestamp(new Date());

    if (title) embed.setTitle(title);
    if (description) embed.setDescription(description.replace(/\\n/g, "\n"));
    if (imageUrl) embed.setImage(imageUrl);
    if (thumbnailUrl) embed.setThumbnail(thumbnailUrl);
    if (authorName) embed.setAuthor({ name: authorName, iconURL: authorIconUrl || undefined });
    if (footerText) embed.setFooter({ text: footerText, iconURL: footerIconUrl || undefined });

    await (channel as TextChannel | NewsChannel).send({
      content: mentionEveryone ? "@everyone" : undefined,
      embeds: [embed],
      allowedMentions: mentionEveryone ? { parse: ["everyone"] } : { parse: [] },
    });

    await logEvent(client, {
      guildId,
      eventType: "announcement",
      actorId,
      actorTag,
      channelId,
      summary: `Comunicado "${title ?? "(sin título)"}" publicado vía dashboard en <#${channelId}>`,
    });

    res.json({ ok: true, message: `Comunicado publicado en #${channel.name}.` });
  } catch (err) {
    const msg = err instanceof Error ? err.message : String(err);
    res.status(500).json({ ok: false, message: `Error: ${msg}` });
  }
});

export default router;
