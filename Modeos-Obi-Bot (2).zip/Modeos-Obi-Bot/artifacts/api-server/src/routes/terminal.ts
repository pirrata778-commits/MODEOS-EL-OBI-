import { Router, type IRouter, type Request, type Response } from "express";
import { getDiscordClient } from "../bot";
import { addToBlacklist, removeFromBlacklist, addWarn, getGuildConfig } from "../bot/store";
import { logEvent } from "../bot/logger-events";
import { PermissionFlagsBits, ChannelType, type TextChannel } from "discord.js";

const router: IRouter = Router();

function requireAuth(req: Request, res: Response): boolean {
  if (!req.session.discordUser) {
    res.status(401).json({ error: "Not authenticated" });
    return false;
  }
  return true;
}

interface TerminalResult {
  ok: boolean;
  message: string;
  lines?: string[];
}

router.post("/dashboard/terminal", async (req: Request, res: Response): Promise<void> => {
  if (!requireAuth(req, res)) return;

  const guildId = req.session.discordUser!.guildId!;
  const actorId = req.session.discordUser!.id;
  const actorTag = req.session.discordUser!.username;
  const { action, params } = req.body as {
    action: string;
    params: Record<string, string>;
  };

  const client = getDiscordClient();
  if (!client) {
    res.status(503).json({ ok: false, message: "Bot no conectado" });
    return;
  }

  let result: TerminalResult;

  try {
    const guild = client.guilds.cache.get(guildId) ?? await client.guilds.fetch(guildId);

    switch (action) {
      case "ban": {
        const { userId, reason = "Sin motivo" } = params;
        if (!userId) { res.status(400).json({ ok: false, message: "userId requerido" }); return; }
        await guild.members.ban(userId, { reason: `[Dashboard] ${actorTag}: ${reason}` });
        await logEvent(client, {
          guildId,
          eventType: "member_banned",
          actorId,
          actorTag,
          targetId: userId,
          summary: `Ban vía dashboard — ${reason}`,
        });
        result = { ok: true, message: `Usuario ${userId} baneado correctamente.` };
        break;
      }

      case "kick": {
        const { userId, reason = "Sin motivo" } = params;
        if (!userId) { res.status(400).json({ ok: false, message: "userId requerido" }); return; }
        const member = await guild.members.fetch(userId);
        await member.kick(`[Dashboard] ${actorTag}: ${reason}`);
        await logEvent(client, {
          guildId,
          eventType: "member_kicked",
          actorId,
          actorTag,
          targetId: userId,
          summary: `Kick vía dashboard — ${reason}`,
        });
        result = { ok: true, message: `Usuario ${userId} expulsado correctamente.` };
        break;
      }

      case "warn": {
        const { userId, userTag = userId, reason } = params;
        if (!userId || !reason) { res.status(400).json({ ok: false, message: "userId y reason requeridos" }); return; }
        await addWarn({ guildId, userId, userTag: userTag ?? userId, moderatorId: actorId, reason });
        try {
          const user = await client.users.fetch(userId);
          await user.send(`⚠️ Has recibido una advertencia en el servidor: **${reason}**`);
        } catch { /* DMs closed */ }
        await logEvent(client, {
          guildId,
          eventType: "warn_added",
          actorId,
          actorTag,
          targetId: userId,
          targetTag: userTag,
          summary: `Advertencia vía dashboard — ${reason}`,
        });
        result = { ok: true, message: `Advertencia añadida a ${userTag}.` };
        break;
      }

      case "blacklist_add": {
        const { userId, userTag = userId, reason } = params;
        if (!userId || !reason) { res.status(400).json({ ok: false, message: "userId y reason requeridos" }); return; }
        await addToBlacklist({ guildId, userId, userTag: userTag ?? userId, addedById: actorId, addedByTag: actorTag, reason });
        try { await guild.members.ban(userId, { reason: `[Blacklist Dashboard] ${reason}` }); } catch { /* not in guild */ }
        await logEvent(client, {
          guildId,
          eventType: "blacklist_added",
          actorId,
          actorTag,
          targetId: userId,
          targetTag: userTag,
          summary: `Añadido a blacklist vía dashboard — ${reason}`,
        });
        result = { ok: true, message: `${userTag} añadido a la lista negra y baneado.` };
        break;
      }

      case "blacklist_remove": {
        const { userId } = params;
        if (!userId) { res.status(400).json({ ok: false, message: "userId requerido" }); return; }
        const removed = await removeFromBlacklist(guildId, userId);
        if (!removed) { res.json({ ok: false, message: "El usuario no estaba en la lista negra." }); return; }
        try { await guild.members.unban(userId); } catch { /* not banned */ }
        await logEvent(client, {
          guildId,
          eventType: "blacklist_removed",
          actorId,
          actorTag,
          targetId: userId,
          summary: `Removido de blacklist vía dashboard`,
        });
        result = { ok: true, message: `${userId} removido de la lista negra.` };
        break;
      }

      case "send_message": {
        const { channelId, message } = params;
        if (!channelId || !message) { res.status(400).json({ ok: false, message: "channelId y message requeridos" }); return; }
        const channel = guild.channels.cache.get(channelId) as TextChannel | undefined;
        if (!channel) { res.json({ ok: false, message: "Canal no encontrado." }); return; }
        await channel.send({ content: message });
        await logEvent(client, {
          guildId,
          eventType: "message_sent_dashboard",
          actorId,
          actorTag,
          channelId,
          summary: `Mensaje enviado desde dashboard al canal ${channel.name}`,
        });
        result = { ok: true, message: `Mensaje enviado al canal #${channel.name}.` };
        break;
      }

      case "clear_messages": {
        const { channelId, amount } = params;
        if (!channelId || !amount) { res.status(400).json({ ok: false, message: "channelId y amount requeridos" }); return; }
        const n = Math.min(parseInt(amount, 10), 100);
        const channel = guild.channels.cache.get(channelId) as TextChannel | undefined;
        if (!channel) { res.json({ ok: false, message: "Canal no encontrado." }); return; }
        const deleted = await channel.bulkDelete(n, true);
        result = { ok: true, message: `${deleted.size} mensajes eliminados del canal #${channel.name}.` };
        break;
      }

      case "server_info": {
        // Fetch full member list to get accurate count
        await guild.members.fetch();

        const CHANNEL_TYPE_LABEL: Record<number, string> = {
          [ChannelType.GuildText]: "texto",
          [ChannelType.GuildVoice]: "voz",
          [ChannelType.GuildAnnouncement]: "anuncio",
          [ChannelType.GuildForum]: "foro",
          [ChannelType.GuildStageVoice]: "escenario",
          [ChannelType.GuildCategory]: "categoría",
        };

        const lines: string[] = [
          `╔══════════════════════════════════════`,
          `║  PLANTILLA — ${guild.name}`,
          `╠══════════════════════════════════════`,
          `║  ID:          ${guild.id}`,
          `║  Miembros:    ${guild.memberCount}`,
          `║  Boost:       nivel ${guild.premiumTier} (${guild.premiumSubscriptionCount ?? 0} boosts)`,
          `║  Creado:      ${guild.createdAt.toLocaleDateString("es-ES")}`,
          `╠══════════════════════════════════════`,
          `║  CATEGORÍAS Y CANALES`,
          `╠══════════════════════════════════════`,
        ];

        const pos = (c: unknown) => ((c as { position?: number }).position ?? 0);

        const categories = guild.channels.cache
          .filter((c) => c.type === ChannelType.GuildCategory && !c.isThread())
          .sort((a, b) => pos(a) - pos(b));

        const noCategory = guild.channels.cache
          .filter((c) => c.type !== ChannelType.GuildCategory && !c.parentId && !c.isThread())
          .sort((a, b) => pos(a) - pos(b));

        if (noCategory.size > 0) {
          lines.push(`║  [Sin categoría]`);
          noCategory.forEach((ch) => {
            lines.push(`║    #${ch.name}  [${CHANNEL_TYPE_LABEL[ch.type] ?? ch.type}]  (${ch.id})`);
          });
        }

        categories.forEach((cat) => {
          lines.push(`║  📁 ${cat.name.toUpperCase()}  (${cat.id})`);
          guild.channels.cache
            .filter((c) => c.parentId === cat.id && !c.isThread())
            .sort((a: unknown, b: unknown) => pos(a) - pos(b))
            .forEach((ch) => {
              lines.push(`║    #${ch.name}  [${CHANNEL_TYPE_LABEL[ch.type] ?? ch.type}]  (${ch.id})`);
            });
        });

        lines.push(`╠══════════════════════════════════════`);
        lines.push(`║  ROLES (${guild.roles.cache.size})`);
        lines.push(`╠══════════════════════════════════════`);

        guild.roles.cache
          .filter((r) => r.id !== guild.id)
          .sort((a, b) => b.rawPosition - a.rawPosition)
          .forEach((r) => {
            const color = r.hexColor !== "#000000" ? `  color:${r.hexColor}` : "";
            const admin = r.permissions.has(PermissionFlagsBits.Administrator) ? "  [ADMIN]" : "";
            lines.push(`║  @${r.name}  (${r.id})${color}${admin}`);
          });

        lines.push(`╚══════════════════════════════════════`);

        result = { ok: true, message: `Plantilla generada: ${guild.name}`, lines };
        break;
      }

      case "scan_new": {
        const dias = parseInt(params.dias ?? "30", 10);
        const cutoff = Date.now() - dias * 24 * 60 * 60 * 1000;

        await guild.members.fetch();
        const recent = guild.members.cache
          .filter((m) => !m.user.bot && m.user.createdTimestamp > cutoff)
          .sort((a, b) => b.user.createdTimestamp - a.user.createdTimestamp);

        if (recent.size === 0) {
          result = { ok: true, message: `Sin cuentas recientes (< ${dias} días) en el servidor.` };
          break;
        }

        const lines: string[] = [
          `⚠  CUENTAS RECIENTES (< ${dias} días) — ${recent.size} encontradas`,
          `${"─".repeat(54)}`,
        ];

        recent.forEach((m) => {
          const created = new Date(m.user.createdTimestamp);
          const ageDays = Math.floor((Date.now() - m.user.createdTimestamp) / 86_400_000);
          const joined = m.joinedAt ? m.joinedAt.toLocaleDateString("es-ES") : "?";
          lines.push(
            `${m.user.username.padEnd(22)} ID: ${m.user.id}`,
          );
          lines.push(
            `  Cuenta: ${created.toLocaleDateString("es-ES")}  (${ageDays}d)  · Entró: ${joined}`,
          );
        });

        lines.push(`${"─".repeat(54)}`);
        lines.push(`Total: ${recent.size} cuentas nuevas de ${guild.memberCount} miembros.`);

        result = { ok: true, message: `${recent.size} cuentas recientes encontradas.`, lines };
        break;
      }

      case "list_admins": {
        await guild.members.fetch();

        const admins = guild.members.cache.filter((m) => {
          if (m.user.bot) return false;
          return (
            m.permissions.has(PermissionFlagsBits.Administrator) ||
            m.permissions.has(PermissionFlagsBits.ManageGuild)
          );
        }).sort((a, b) => a.user.username.localeCompare(b.user.username));

        if (admins.size === 0) {
          result = { ok: true, message: "No se encontraron administradores (sin permiso Admin ni Manage Guild)." };
          break;
        }

        const lines: string[] = [
          `🛡  ADMINISTRADORES — ${guild.name} (${admins.size})`,
          `${"─".repeat(54)}`,
        ];

        admins.forEach((m) => {
          const isFullAdmin = m.permissions.has(PermissionFlagsBits.Administrator);
          const label = isFullAdmin ? "[ADMIN]" : "[Gestión]";
          lines.push(`${m.user.username.padEnd(22)} ID: ${m.user.id}  ${label}`);
          lines.push(`  Mención: <@${m.user.id}>  ·  @${m.user.username}`);
        });

        lines.push(`${"─".repeat(54)}`);

        result = { ok: true, message: `${admins.size} administradores encontrados.`, lines };
        break;
      }

      default:
        res.status(400).json({ ok: false, message: `Acción desconocida: ${action}` });
        return;
    }

    res.json(result);
  } catch (err: unknown) {
    const msg = err instanceof Error ? err.message : String(err);
    res.status(500).json({ ok: false, message: `Error: ${msg}` });
  }
});

// Returns available guilds/channels for the UI to populate selects
router.get("/dashboard/terminal/guilds", async (req: Request, res: Response): Promise<void> => {
  if (!requireAuth(req, res)) return;
  const guildId = req.session.discordUser!.guildId!;
  const client = getDiscordClient();
  if (!client) { res.status(503).json({ error: "Bot no conectado" }); return; }

  try {
    const guild = client.guilds.cache.get(guildId) ?? await client.guilds.fetch(guildId);
    const channels = guild.channels.cache
      .filter((c) => c.isTextBased() && c.permissionsFor(guild.members.me!)?.has(PermissionFlagsBits.SendMessages))
      .map((c) => ({ id: c.id, name: c.name }))
      .sort((a, b) => a.name.localeCompare(b.name));

    res.json({ guildName: guild.name, channels });
  } catch (err) {
    res.status(500).json({ error: "No se pudo obtener la información del servidor" });
  }
});

export default router;
