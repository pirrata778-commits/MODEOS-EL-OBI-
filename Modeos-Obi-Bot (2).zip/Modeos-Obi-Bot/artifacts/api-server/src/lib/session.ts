import session from "express-session";
import connectPgSimple from "connect-pg-simple";
import { pool } from "@workspace/db";
import { logger } from "./logger";

const PgStore = connectPgSimple(session);

if (!process.env["SESSION_SECRET"]) {
  throw new Error("SESSION_SECRET must be set");
}

// Create the session table manually so esbuild doesn't need to bundle table.sql
async function ensureSessionTable(): Promise<void> {
  try {
    await pool.query(`
      CREATE TABLE IF NOT EXISTS user_sessions (
        sid varchar NOT NULL COLLATE "default",
        sess json NOT NULL,
        expire timestamp(6) NOT NULL,
        CONSTRAINT session_pkey PRIMARY KEY (sid) NOT DEFERRABLE INITIALLY IMMEDIATE
      ) WITH (OIDS=FALSE);
    `);
    await pool.query(`
      CREATE INDEX IF NOT EXISTS IDX_session_expire ON user_sessions (expire);
    `);
  } catch (err) {
    logger.error({ err }, "Failed to ensure session table");
  }
}

// Run on startup (non-blocking)
ensureSessionTable();

export const sessionMiddleware = session({
  store: new PgStore({
    pool,
    tableName: "user_sessions",
    // Do NOT use createTableIfMissing — esbuild strips the table.sql asset
  }),
  secret: process.env["SESSION_SECRET"]!,
  resave: false,
  saveUninitialized: false,
  cookie: {
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    maxAge: 7 * 24 * 60 * 60 * 1000, // 7 days
    sameSite: "lax",
  },
});

declare module "express-session" {
  interface SessionData {
    discordUser?: {
      id: string;
      username: string;
      globalName: string | null;
      avatar: string | null;
      guildId: string | null;
    };
  }
}
