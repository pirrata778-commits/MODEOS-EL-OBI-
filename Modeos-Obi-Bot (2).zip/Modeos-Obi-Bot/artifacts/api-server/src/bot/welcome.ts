import { EmbedBuilder } from "discord.js";
import type { GuildMember } from "discord.js";

export interface WelcomeSettings {
  welcomeEnabled: boolean;
  welcomeChannelId: string | null;
  verificationChannelId: string | null;
  salesChannelId: string | null;
  vouchChannelId: string | null;
  welcomeTitle: string | null;
  welcomeMessage: string | null;
  welcomeFooter: string | null;
  welcomeColor: string | null;
}

export interface WelcomeContext {
  memberId: string;
  memberMention: string;
  memberAvatarUrl?: string;
  guildName: string;
  memberCount: number;
}

export function getWelcomeContext(member: GuildMember): WelcomeContext {
  return {
    memberId: member.id,
    memberMention: member.toString(),
    memberAvatarUrl: member.user.displayAvatarURL({ size: 256 }),
    guildName: member.guild.name,
    memberCount: member.guild.memberCount,
  };
}

export function buildWelcomePayload(
  context: WelcomeContext,
  cfg: WelcomeSettings,
): {
  content: string;
  embeds: EmbedBuilder[];
  allowedMentions: { users: string[] };
} {
  const replaceTokens = (value: string): string =>
    value
      .replaceAll("{usuario}", context.memberMention)
      .replaceAll("{servidor}", context.guildName)
      .replaceAll(
        "{verificacion}",
        cfg.verificationChannelId
          ? `<#${cfg.verificationChannelId}>`
          : "el canal de verificación",
      )
      .replaceAll(
        "{ventas}",
        cfg.salesChannelId ? `<#${cfg.salesChannelId}>` : "el canal de ventas",
      )
      .replaceAll(
        "{vouches}",
        cfg.vouchChannelId ? `<#${cfg.vouchChannelId}>` : "el canal de vouches",
      )
      .replaceAll("{numero}", String(context.memberCount));

  const defaultDescription = [
    `Hola ${context.memberMention}, qué bueno tenerte por aquí.`,
    "",
    cfg.verificationChannelId
      ? `🔐 Pásate por <#${cfg.verificationChannelId}> para **verificarte** y desbloquear todo el servidor.`
      : "🔐 Verifícate en el canal de verificación para desbloquear todo el servidor.",
    cfg.salesChannelId
      ? `🛒 Echa un ojo a <#${cfg.salesChannelId}> para ver Discords en venta.`
      : null,
    cfg.vouchChannelId
      ? `⭐ Lee las reseñas de los vendedores en <#${cfg.vouchChannelId}>.`
      : null,
    "",
    "Disfruta de Modeos el obi.",
  ]
    .filter(Boolean)
    .join("\n");

  const color = parseInt((cfg.welcomeColor ?? "").replace("#", ""), 16);
  const embed = new EmbedBuilder()
    .setTitle(
      replaceTokens(
        cfg.welcomeTitle || `¡Bienvenido a ${context.guildName}!`,
      ),
    )
    .setColor(color || 0x9333ea)
    .setDescription(replaceTokens(cfg.welcomeMessage || defaultDescription))
    .setFooter({
      text: replaceTokens(
        cfg.welcomeFooter || `Miembro #${context.memberCount}`,
      ),
    })
    .setTimestamp(new Date());

  if (context.memberAvatarUrl) {
    embed.setThumbnail(context.memberAvatarUrl);
  }

  return {
    content: context.memberMention,
    embeds: [embed],
    allowedMentions: { users: [context.memberId] },
  };
}