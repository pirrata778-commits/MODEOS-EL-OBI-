import {
  SlashCommandBuilder,
  PermissionFlagsBits,
  ChannelType,
} from "discord.js";

export const commandDefinitions = [
  // ──────────────── CONFIG ────────────────
  new SlashCommandBuilder()
    .setName("setup")
    .setDescription("Configura el bot para este servidor")
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
    .addRoleOption((opt) =>
      opt
        .setName("rol_verificado")
        .setDescription("Rol que se asigna al verificarse"),
    )
    .addRoleOption((opt) =>
      opt
        .setName("rol_staff")
        .setDescription("Rol del staff (gestiona tickets y modera)"),
    )
    .addChannelOption((opt) =>
      opt
        .setName("canal_anuncios")
        .setDescription("Canal por defecto para los comunicados")
        .addChannelTypes(ChannelType.GuildText, ChannelType.GuildAnnouncement),
    )
    .addChannelOption((opt) =>
      opt
        .setName("canal_bienvenida")
        .setDescription("Canal donde se dará la bienvenida a nuevos miembros")
        .addChannelTypes(ChannelType.GuildText),
    )
    .addChannelOption((opt) =>
      opt
        .setName("canal_ventas")
        .setDescription("Canal donde se publican los Discords en venta")
        .addChannelTypes(ChannelType.GuildText, ChannelType.GuildAnnouncement),
    )
    .addChannelOption((opt) =>
      opt
        .setName("canal_vouches")
        .setDescription("Canal donde se publican las reseñas de vendedores")
        .addChannelTypes(ChannelType.GuildText),
    )
    .addChannelOption((opt) =>
      opt
        .setName("categoria_tickets")
        .setDescription("Categoría donde se crean los tickets privados")
        .addChannelTypes(ChannelType.GuildCategory),
    )
    .addChannelOption((opt) =>
      opt
        .setName("canal_logs")
        .setDescription("Canal donde se registran todos los eventos del servidor")
        .addChannelTypes(ChannelType.GuildText),
    ),

  new SlashCommandBuilder()
    .setName("config")
    .setDescription("Muestra la configuración actual del bot")
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),

  // ──────────────── VERIFICACIÓN ────────────────
  new SlashCommandBuilder()
    .setName("verificacion")
    .setDescription("Publica el panel de verificación en este canal")
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
    .addStringOption((opt) =>
      opt.setName("titulo").setDescription("Título del panel (opcional)"),
    )
    .addStringOption((opt) =>
      opt
        .setName("descripcion")
        .setDescription("Descripción que verán los usuarios (opcional)"),
    ),

  // ──────────────── COMUNICADOS ────────────────
  new SlashCommandBuilder()
    .setName("comunicado")
    .setDescription("Publica un comunicado bonito en un canal")
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
    .addStringOption((opt) =>
      opt
        .setName("titulo")
        .setDescription("Título del comunicado")
        .setRequired(true),
    )
    .addStringOption((opt) =>
      opt
        .setName("mensaje")
        .setDescription("Contenido del comunicado")
        .setRequired(true),
    )
    .addChannelOption((opt) =>
      opt
        .setName("canal")
        .setDescription("Canal destino (por defecto el configurado)")
        .addChannelTypes(ChannelType.GuildText, ChannelType.GuildAnnouncement),
    )
    .addStringOption((opt) =>
      opt
        .setName("color")
        .setDescription("Color del embed")
        .addChoices(
          { name: "Morado", value: "9333EA" },
          { name: "Azul", value: "3B82F6" },
          { name: "Verde", value: "22C55E" },
          { name: "Rojo", value: "EF4444" },
          { name: "Dorado", value: "EAB308" },
          { name: "Rosa", value: "EC4899" },
        ),
    )
    .addBooleanOption((opt) =>
      opt
        .setName("mencionar_todos")
        .setDescription("Hacer @everyone (por defecto: no)"),
    ),

  // ──────────────── VENTA DE DISCORDS ────────────────
  new SlashCommandBuilder()
    .setName("venta")
    .setDescription("Publica un Discord en venta con formato bonito")
    .addStringOption((opt) =>
      opt
        .setName("nombre")
        .setDescription("Nombre del servidor en venta")
        .setRequired(true),
    )
    .addIntegerOption((opt) =>
      opt
        .setName("miembros")
        .setDescription("Cantidad de miembros")
        .setRequired(true)
        .setMinValue(0),
    )
    .addStringOption((opt) =>
      opt
        .setName("precio")
        .setDescription("Precio (ej: 25€, 30 USD, intercambio…)")
        .setRequired(true),
    )
    .addStringOption((opt) =>
      opt
        .setName("nicho")
        .setDescription("Temática / nicho del servidor")
        .setRequired(true),
    )
    .addStringOption((opt) =>
      opt
        .setName("descripcion")
        .setDescription("Descripción y detalles")
        .setRequired(true),
    )
    .addStringOption((opt) =>
      opt
        .setName("metodos_pago")
        .setDescription("Métodos de pago aceptados (PayPal, Crypto, etc.)"),
    )
    .addStringOption((opt) =>
      opt
        .setName("imagen")
        .setDescription("URL de imagen del servidor (opcional)"),
    ),

  // ──────────────── VOUCHES ────────────────
  new SlashCommandBuilder()
    .setName("vouch")
    .setDescription("Deja una reseña a un vendedor con el que has comerciado")
    .addUserOption((opt) =>
      opt
        .setName("vendedor")
        .setDescription("Usuario al que dejas la reseña")
        .setRequired(true),
    )
    .addIntegerOption((opt) =>
      opt
        .setName("estrellas")
        .setDescription("Puntuación de 1 a 5")
        .setRequired(true)
        .setMinValue(1)
        .setMaxValue(5),
    )
    .addStringOption((opt) =>
      opt
        .setName("comentario")
        .setDescription("Cuenta cómo fue la experiencia")
        .setRequired(true),
    ),

  new SlashCommandBuilder()
    .setName("vouches")
    .setDescription("Mira las reseñas y reputación de un vendedor")
    .addUserOption((opt) =>
      opt
        .setName("vendedor")
        .setDescription("Usuario a consultar")
        .setRequired(true),
    ),

  // ──────────────── TICKETS ────────────────
  new SlashCommandBuilder()
    .setName("ticket")
    .setDescription("Abre un ticket privado con el staff")
    .addStringOption((opt) =>
      opt
        .setName("motivo")
        .setDescription("Motivo del ticket")
        .setRequired(true),
    ),

  new SlashCommandBuilder()
    .setName("cerrar")
    .setDescription("Cierra el ticket actual"),

  // ──────────────── MODERACIÓN ────────────────
  new SlashCommandBuilder()
    .setName("limpiar")
    .setDescription("Borra los últimos N mensajes del canal")
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages)
    .addIntegerOption((opt) =>
      opt
        .setName("cantidad")
        .setDescription("Número de mensajes (1-100)")
        .setRequired(true)
        .setMinValue(1)
        .setMaxValue(100),
    ),

  new SlashCommandBuilder()
    .setName("warn")
    .setDescription("Avisa formalmente a un usuario")
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers)
    .addUserOption((opt) =>
      opt
        .setName("usuario")
        .setDescription("Usuario a avisar")
        .setRequired(true),
    )
    .addStringOption((opt) =>
      opt
        .setName("razon")
        .setDescription("Razón del aviso")
        .setRequired(true),
    ),

  new SlashCommandBuilder()
    .setName("warns")
    .setDescription("Consulta los avisos de un usuario")
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers)
    .addUserOption((opt) =>
      opt
        .setName("usuario")
        .setDescription("Usuario a consultar")
        .setRequired(true),
    ),

  new SlashCommandBuilder()
    .setName("kick")
    .setDescription("Expulsa a un usuario del servidor")
    .setDefaultMemberPermissions(PermissionFlagsBits.KickMembers)
    .addUserOption((opt) =>
      opt
        .setName("usuario")
        .setDescription("Usuario a expulsar")
        .setRequired(true),
    )
    .addStringOption((opt) =>
      opt.setName("razon").setDescription("Razón (opcional)"),
    ),

  new SlashCommandBuilder()
    .setName("ban")
    .setDescription("Banea a un usuario del servidor")
    .setDefaultMemberPermissions(PermissionFlagsBits.BanMembers)
    .addUserOption((opt) =>
      opt
        .setName("usuario")
        .setDescription("Usuario a banear")
        .setRequired(true),
    )
    .addStringOption((opt) =>
      opt.setName("razon").setDescription("Razón (opcional)"),
    ),

  // ──────────────── BLACKLIST ────────────────
  new SlashCommandBuilder()
    .setName("blacklist")
    .setDescription("Gestiona la lista negra del servidor")
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers)
    .addSubcommand((sub) =>
      sub
        .setName("add")
        .setDescription("Añade un usuario a la blacklist y lo banea")
        .addUserOption((opt) =>
          opt
            .setName("usuario")
            .setDescription("Usuario a añadir")
            .setRequired(true),
        )
        .addStringOption((opt) =>
          opt
            .setName("razon")
            .setDescription("Razón de la blacklist")
            .setRequired(true),
        ),
    )
    .addSubcommand((sub) =>
      sub
        .setName("remove")
        .setDescription("Quita un usuario de la blacklist y lo desbanea")
        .addUserOption((opt) =>
          opt
            .setName("usuario")
            .setDescription("Usuario a quitar")
            .setRequired(true),
        ),
    )
    .addSubcommand((sub) =>
      sub
        .setName("check")
        .setDescription("Comprueba si un usuario está en la blacklist")
        .addUserOption((opt) =>
          opt
            .setName("usuario")
            .setDescription("Usuario a comprobar")
            .setRequired(true),
        ),
    )
    .addSubcommand((sub) =>
      sub
        .setName("list")
        .setDescription("Muestra la blacklist completa"),
    ),

  // ──────────────── LOGS ────────────────
  new SlashCommandBuilder()
    .setName("logs")
    .setDescription("Muestra los últimos eventos registrados")
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers)
    .addIntegerOption((opt) =>
      opt
        .setName("cantidad")
        .setDescription("Número de eventos a mostrar (1-25)")
        .setMinValue(1)
        .setMaxValue(25),
    ),

  // ──────────────── UTILIDADES ────────────────
  new SlashCommandBuilder()
    .setName("say")
    .setDescription("Hace que el bot envíe un mensaje")
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages)
    .addStringOption((opt) =>
      opt
        .setName("mensaje")
        .setDescription("Mensaje a enviar")
        .setRequired(true),
    ),

  new SlashCommandBuilder()
    .setName("embed")
    .setDescription("Crear un embed personalizado")
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
    .addStringOption((opt) =>
      opt
        .setName("titulo")
        .setDescription("Título")
        .setRequired(true),
    )
    .addStringOption((opt) =>
      opt
        .setName("descripcion")
        .setDescription("Descripción")
        .setRequired(true),
    )
    .addStringOption((opt) =>
      opt
        .setName("color")
        .setDescription("Color HEX")
        .setRequired(false),
    ),

  new SlashCommandBuilder()
    .setName("serverinfo")
    .setDescription("Muestra información del servidor"),

  new SlashCommandBuilder()
    .setName("userinfo")
    .setDescription("Muestra información de un usuario")
    .addUserOption((opt) =>
      opt
        .setName("usuario")
        .setDescription("Usuario a consultar"),
    ),

  new SlashCommandBuilder()
    .setName("rol")
    .setDescription("Añadir o quitar un rol")
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageRoles)
    .addUserOption((opt) =>
      opt
        .setName("usuario")
        .setDescription("Usuario")
        .setRequired(true),
    )
    .addRoleOption((opt) =>
      opt
        .setName("rol")
        .setDescription("Rol")
        .setRequired(true),
    ),

  new SlashCommandBuilder()
    .setName("crear-panel-tickets")
    .setDescription("Crea el panel de tickets")
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),

  new SlashCommandBuilder()
    .setName("clonar-servidor")
    .setDescription("Clona la estructura de un servidor")
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
    .addStringOption((opt) =>
      opt
        .setName("servidor_id")
        .setDescription("ID del servidor destino")
        .setRequired(true),
    ),

  // ──────────────── INFO ────────────────
  new SlashCommandBuilder()
    .setName("stats")
    .setDescription("Muestra estadísticas del servidor"),

  new SlashCommandBuilder()
    .setName("escanear-admins")
    .setDescription("Escanea los miembros que tienen permisos de Administrador")
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),

  new SlashCommandBuilder()
    .setName("avatar")
    .setDescription("Muestra el avatar de un usuario")
    .addUserOption((opt) =>
      opt.setName("usuario").setDescription("Usuario (por defecto tú)"),
    ),

  // ──────────────── MODERACIÓN AVANZADA ────────────────
  new SlashCommandBuilder()
    .setName("timeout")
    .setDescription("Silencia temporalmente a un usuario")
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers)
    .addUserOption((opt) =>
      opt.setName("usuario").setDescription("Usuario a silenciar").setRequired(true),
    )
    .addIntegerOption((opt) =>
      opt
        .setName("duracion")
        .setDescription("Duración en minutos (1-40320)")
        .setRequired(true)
        .setMinValue(1)
        .setMaxValue(40320),
    )
    .addStringOption((opt) =>
      opt.setName("razon").setDescription("Razón del silencio"),
    ),

  new SlashCommandBuilder()
    .setName("untimeout")
    .setDescription("Quita el silencio a un usuario")
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers)
    .addUserOption((opt) =>
      opt.setName("usuario").setDescription("Usuario").setRequired(true),
    ),

  new SlashCommandBuilder()
    .setName("lock")
    .setDescription("Bloquea un canal (nadie puede escribir excepto staff)")
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageChannels)
    .addChannelOption((opt) =>
      opt
        .setName("canal")
        .setDescription("Canal a bloquear (por defecto el actual)")
        .addChannelTypes(ChannelType.GuildText),
    ),

  new SlashCommandBuilder()
    .setName("unlock")
    .setDescription("Desbloquea un canal")
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageChannels)
    .addChannelOption((opt) =>
      opt
        .setName("canal")
        .setDescription("Canal a desbloquear (por defecto el actual)")
        .addChannelTypes(ChannelType.GuildText),
    ),

  new SlashCommandBuilder()
    .setName("slowmode")
    .setDescription("Activa el modo lento en un canal")
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageChannels)
    .addIntegerOption((opt) =>
      opt
        .setName("segundos")
        .setDescription("Segundos entre mensajes (0 = desactivar, máx 21600)")
        .setRequired(true)
        .setMinValue(0)
        .setMaxValue(21600),
    )
    .addChannelOption((opt) =>
      opt
        .setName("canal")
        .setDescription("Canal (por defecto el actual)")
        .addChannelTypes(ChannelType.GuildText),
    ),

  // ──────────────── DASHBOARD ────────────────
  new SlashCommandBuilder()
    .setName("acceso")
    .setDescription("Gestiona el acceso al panel de administración web")
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
    .addSubcommand((sub) =>
      sub
        .setName("add")
        .setDescription("Concede acceso al dashboard a un usuario")
        .addUserOption((opt) =>
          opt
            .setName("usuario")
            .setDescription("Usuario a quien conceder acceso")
            .setRequired(true),
        ),
    )
    .addSubcommand((sub) =>
      sub
        .setName("remove")
        .setDescription("Revoca el acceso al dashboard de un usuario")
        .addUserOption((opt) =>
          opt
            .setName("usuario")
            .setDescription("Usuario a quien revocar el acceso")
            .setRequired(true),
        ),
    )
    .addSubcommand((sub) =>
      sub
        .setName("list")
        .setDescription("Lista los usuarios con acceso al dashboard"),
    ),
].map((cmd) => cmd.toJSON());
