import {
  ChannelType,
  PermissionFlagsBits,
  type Client,
  type Guild,
  type GuildMember,
} from "discord.js";
import { logger } from "../lib/logger";
import { getGuildConfig } from "./store";

const STATS_CATEGORY_NAME = "📊 ESTADÍSTICAS DEL SERVIDOR";
const CHANNEL_PREFIXES = {
  bots: "🤖 Bots:",
  users: "👥 Usuarios:",
  admins: "🛡️ Admins:",
  total: "📈 Total:",
} as const;

const UPDATE_INTERVAL_MS = 5 * 60 * 1000;

function findChannel(
  guild: Guild,
  prefix: string,
  categoryId: string,
) {
  return guild.channels.cache.find(
    (channel) =>
      channel.parentId === categoryId &&
      channel.type === ChannelType.GuildVoice &&
      channel.name.startsWith(prefix),
  );
}

export async function updateGuildStats(guild: Guild): Promise<void> {
  try {
    const cfg = await getGuildConfig(guild.id);
    if (!cfg.statsChannelsEnabled) return;

    const me = guild.members.me;
    if (!me?.permissions.has(PermissionFlagsBits.ManageChannels)) {
      logger.warn(
        { guildId: guild.id, guildName: guild.name },
        "Stats channels skipped: bot lacks Manage Channels permission",
      );
      return;
    }

    // Fetch the complete member list so bot/admin counts are accurate.
    const members = await guild.members.fetch();
    const bots = members.filter((member) => member.user.bot).size;
    const admins = members.filter((member) =>
      member.permissions.has(PermissionFlagsBits.Administrator),
    ).size;
    const users = members.size - bots;
    const total = members.size;

    let category = guild.channels.cache.find(
      (channel) =>
        channel.type === ChannelType.GuildCategory &&
        channel.name === STATS_CATEGORY_NAME,
    );

    if (!category) {
      category = await guild.channels.create({
        name: STATS_CATEGORY_NAME,
        type: ChannelType.GuildCategory,
        reason: "Crear canales automáticos de estadísticas del servidor",
      });
    }

    const values = {
      bots: `${CHANNEL_PREFIXES.bots} ${bots}`,
      users: `${CHANNEL_PREFIXES.users} ${users}`,
      admins: `${CHANNEL_PREFIXES.admins} ${admins}`,
      total: `${CHANNEL_PREFIXES.total} ${total}`,
    };

    for (const [key, name] of Object.entries(values) as Array<
      [keyof typeof CHANNEL_PREFIXES, string]
    >) {
      let channel = findChannel(guild, CHANNEL_PREFIXES[key], category.id);

      if (!channel) {
        channel = await guild.channels.create({
          name,
          type: ChannelType.GuildVoice,
          parent: category.id,
          permissionOverwrites: [
            {
              id: guild.roles.everyone.id,
              deny: [PermissionFlagsBits.Connect],
            },
          ],
          reason: "Crear canal automático de estadísticas del servidor",
        });
      } else if (channel.name !== name) {
        await channel.setName(name, "Actualizar estadísticas del servidor");
      }
    }

    logger.info(
      { guildId: guild.id, bots, users, admins, total },
      "Server stats channels updated",
    );
  } catch (err) {
    logger.error(
      { err, guildId: guild.id, guildName: guild.name },
      "Failed to update server stats channels",
    );
  }
}

export function startServerStatsChannels(client: Client): void {
  const updateAllGuilds = async (): Promise<void> => {
    await Promise.all(client.guilds.cache.map((guild) => updateGuildStats(guild)));
  };

  client.once("ready", () => {
    void updateAllGuilds();
    setInterval(() => void updateAllGuilds(), UPDATE_INTERVAL_MS);
  });

  client.on("guildCreate", (guild) => {
    void updateGuildStats(guild);
  });

  // Keep counts fresh shortly after members join or leave.
  client.on("guildMemberAdd", (member: GuildMember) => {
    void updateGuildStats(member.guild);
  });
  client.on("guildMemberRemove", (member) => {
    void updateGuildStats(member.guild);
  });
}

export async function refreshServerStatsChannels(
  client: Client,
  guildId: string,
): Promise<void> {
  const guild =
    client.guilds.cache.get(guildId) ?? (await client.guilds.fetch(guildId));
  await updateGuildStats(guild);
}