import { and, desc, eq } from "drizzle-orm";
import { db } from "@workspace/db";
import {
  guildConfigsTable,
  vouchesTable,
  warnsTable,
  blacklistTable,
  salesTable,
  eventLogsTable,
  dashboardAdminsTable,
  type GuildConfigRow,
  type VouchRow,
  type WarnRow,
  type BlacklistRow,
  type EventLogRow,
  type DashboardAdminRow,
} from "@workspace/db/schema";

export type GuildConfig = Omit<GuildConfigRow, "guildId" | "updatedAt">;

export async function getGuildConfig(guildId: string): Promise<GuildConfig> {
  const [row] = await db
    .select()
    .from(guildConfigsTable)
    .where(eq(guildConfigsTable.guildId, guildId))
    .limit(1);
  if (!row) {
    return emptyConfig();
  }
  const { guildId: _g, updatedAt: _u, ...rest } = row;
  return rest;
}

export async function updateGuildConfig(
  guildId: string,
  patch: Partial<GuildConfig>,
): Promise<GuildConfig> {
  const [row] = await db
    .insert(guildConfigsTable)
    .values({ guildId, ...patch, updatedAt: new Date() })
    .onConflictDoUpdate({
      target: guildConfigsTable.guildId,
      set: { ...patch, updatedAt: new Date() },
    })
    .returning();
  const { guildId: _g, updatedAt: _u, ...rest } = row!;
  return rest;
}

function emptyConfig(): GuildConfig {
  return {
    verifiedRoleId: null,
    staffRoleId: null,
    announcementChannelId: null,
    welcomeChannelId: null,
    salesChannelId: null,
    vouchChannelId: null,
    ticketsCategoryId: null,
    logChannelId: null,
    verificationChannelId: null,
    verificationMessageId: null,
    welcomeEnabled: true,
    verificationEnabled: true,
    loggingEnabled: true,
    statsChannelsEnabled: true,
    announcementsEnabled: true,
    salesEnabled: true,
    vouchesEnabled: true,
    ticketsEnabled: true,
    memberJoinAlertsEnabled: true,
    memberLeaveAlertsEnabled: true,
    moderationAlertsEnabled: true,
    messageAlertsEnabled: true,
    channelAlertsEnabled: true,
    roleAlertsEnabled: true,
    verificationAlertsEnabled: true,
    announcementAlertsEnabled: true,
    saleAlertsEnabled: true,
    vouchAlertsEnabled: true,
    ticketAlertsEnabled: true,
    setupAlertsEnabled: true,
    welcomeTitle: null,
    welcomeMessage: null,
    welcomeFooter: null,
    welcomeColor: null,
  };
}

// ─── Vouches ─────────────────────────────
export async function addVouch(input: {
  guildId: string;
  sellerId: string;
  buyerId: string;
  buyerTag: string;
  stars: number;
  comment: string;
}): Promise<VouchRow> {
  const [row] = await db.insert(vouchesTable).values(input).returning();
  return row!;
}

export async function getVouchesFor(
  guildId: string,
  sellerId: string,
): Promise<VouchRow[]> {
  return db
    .select()
    .from(vouchesTable)
    .where(
      and(
        eq(vouchesTable.guildId, guildId),
        eq(vouchesTable.sellerId, sellerId),
      ),
    )
    .orderBy(desc(vouchesTable.createdAt));
}

// ─── Warns ─────────────────────────────
export async function addWarn(input: {
  guildId: string;
  userId: string;
  userTag: string;
  moderatorId: string;
  reason: string;
}): Promise<WarnRow> {
  const [row] = await db.insert(warnsTable).values(input).returning();
  return row!;
}

export async function getWarnsFor(
  guildId: string,
  userId: string,
): Promise<WarnRow[]> {
  return db
    .select()
    .from(warnsTable)
    .where(
      and(eq(warnsTable.guildId, guildId), eq(warnsTable.userId, userId)),
    )
    .orderBy(desc(warnsTable.createdAt));
}

// ─── Blacklist ─────────────────────────────
export async function addToBlacklist(input: {
  guildId: string;
  userId: string;
  userTag: string;
  reason: string;
  addedById: string;
  addedByTag: string;
}): Promise<{ added: boolean; row: BlacklistRow }> {
  const existing = await db
    .select()
    .from(blacklistTable)
    .where(
      and(
        eq(blacklistTable.guildId, input.guildId),
        eq(blacklistTable.userId, input.userId),
      ),
    )
    .limit(1);
  if (existing.length > 0) {
    return { added: false, row: existing[0]! };
  }
  const [row] = await db.insert(blacklistTable).values(input).returning();
  return { added: true, row: row! };
}

export async function removeFromBlacklist(
  guildId: string,
  userId: string,
): Promise<BlacklistRow | null> {
  const [row] = await db
    .delete(blacklistTable)
    .where(
      and(
        eq(blacklistTable.guildId, guildId),
        eq(blacklistTable.userId, userId),
      ),
    )
    .returning();
  return row ?? null;
}

export async function isBlacklisted(
  guildId: string,
  userId: string,
): Promise<BlacklistRow | null> {
  const [row] = await db
    .select()
    .from(blacklistTable)
    .where(
      and(
        eq(blacklistTable.guildId, guildId),
        eq(blacklistTable.userId, userId),
      ),
    )
    .limit(1);
  return row ?? null;
}

export async function listBlacklist(
  guildId: string,
): Promise<BlacklistRow[]> {
  return db
    .select()
    .from(blacklistTable)
    .where(eq(blacklistTable.guildId, guildId))
    .orderBy(desc(blacklistTable.createdAt));
}

// ─── Sales ─────────────────────────────
export async function recordSale(input: {
  guildId: string;
  sellerId: string;
  sellerTag: string;
  name: string;
  members: number;
  price: string;
  niche: string;
  description: string;
  paymentMethods?: string | null;
  imageUrl?: string | null;
  channelId?: string | null;
  messageId?: string | null;
}): Promise<void> {
  await db.insert(salesTable).values(input);
}

// ─── Event logs ─────────────────────────────
export async function recordEvent(input: {
  guildId: string;
  eventType: string;
  summary: string;
  actorId?: string | null;
  actorTag?: string | null;
  targetId?: string | null;
  targetTag?: string | null;
  channelId?: string | null;
  metadata?: Record<string, unknown>;
}): Promise<EventLogRow> {
  const [row] = await db
    .insert(eventLogsTable)
    .values({
      guildId: input.guildId,
      eventType: input.eventType,
      summary: input.summary,
      actorId: input.actorId ?? null,
      actorTag: input.actorTag ?? null,
      targetId: input.targetId ?? null,
      targetTag: input.targetTag ?? null,
      channelId: input.channelId ?? null,
      metadata: input.metadata ?? null,
    })
    .returning();
  return row!;
}

export async function getRecentEvents(
  guildId: string,
  limit = 10,
): Promise<EventLogRow[]> {
  return db
    .select()
    .from(eventLogsTable)
    .where(eq(eventLogsTable.guildId, guildId))
    .orderBy(desc(eventLogsTable.createdAt))
    .limit(limit);
}

// ──────────────── DASHBOARD ADMINS ────────────────

export async function addDashboardAdmin(
  guildId: string,
  userId: string,
  userTag: string,
  addedById: string,
): Promise<DashboardAdminRow | null> {
  const [row] = await db
    .insert(dashboardAdminsTable)
    .values({ guildId, userId, userTag, addedById })
    .onConflictDoNothing()
    .returning();
  return row ?? null;
}

export async function removeDashboardAdmin(
  guildId: string,
  userId: string,
): Promise<boolean> {
  const [removed] = await db
    .delete(dashboardAdminsTable)
    .where(
      and(
        eq(dashboardAdminsTable.guildId, guildId),
        eq(dashboardAdminsTable.userId, userId),
      ),
    )
    .returning();
  return Boolean(removed);
}

export async function listDashboardAdmins(
  guildId: string,
): Promise<DashboardAdminRow[]> {
  return db
    .select()
    .from(dashboardAdminsTable)
    .where(eq(dashboardAdminsTable.guildId, guildId))
    .orderBy(desc(dashboardAdminsTable.createdAt));
}
