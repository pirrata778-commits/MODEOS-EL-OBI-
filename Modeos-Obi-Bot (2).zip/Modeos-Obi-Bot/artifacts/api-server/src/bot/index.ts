import {
  Client,
  GatewayIntentBits,
  Partials,
  Events,
  REST,
  Routes,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  EmbedBuilder,
  MessageFlags,
  PermissionFlagsBits,
  ChannelType,
  OverwriteType,
  type Interaction,
  type TextChannel,
  type NewsChannel,
  type GuildMember,
  type ChatInputCommandInteraction,
  type ButtonInteraction,
  type Client as DiscordClient,
} from "discord.js";
import { logger } from "../lib/logger";
import { commandDefinitions } from "./commands";
import {
  getGuildConfig,
  updateGuildConfig,
  addVouch,
  getVouchesFor,
  addWarn,
  getWarnsFor,
  addToBlacklist,
  removeFromBlacklist,
  isBlacklisted,
  listBlacklist,
  recordSale,
  getRecentEvents,
  addDashboardAdmin,
  removeDashboardAdmin,
  listDashboardAdmins,
  type GuildConfig,
} from "./store";
import { attachEventLogger, logEvent } from "./logger-events";
import { startServerStatsChannels } from "./server-stats-channels";
import { buildWelcomePayload, getWelcomeContext } from "./welcome";

const VERIFY_BUTTON_ID = "modeos:verify";
const TICKET_CLOSE_ID = "modeos:ticket-close";
const TICKET_TOPIC_PREFIX = "ticket:";
const BRAND_COLOR = 0x9333ea;

let started = false;
let clientRef: DiscordClient | null = null;

export function getDiscordClient(): DiscordClient | null {
  return clientRef;
}

export function startDiscordBot(): void {
  if (started) return;
  const token = process.env["DISCORD_BOT_TOKEN"];
  if (!token) {
    logger.warn("DISCORD_BOT_TOKEN not set — Discord bot is disabled");
    return;
  }
  started = true;

  const client = new Client({
    intents: [
      GatewayIntentBits.Guilds,
      GatewayIntentBits.GuildMembers,
      GatewayIntentBits.GuildMessages,
      GatewayIntentBits.MessageContent,
      GatewayIntentBits.GuildModeration,
    ],
    partials: [Partials.Message, Partials.Channel, Partials.GuildMember],
  });
  clientRef = client;

  client.once(Events.ClientReady, async (ready) => {
    logger.info(
      { user: ready.user.tag, guilds: ready.guilds.cache.size },
      "Discord bot ready",
    );
    try {
      const rest = new REST({ version: "10" }).setToken(token);
      await rest.put(Routes.applicationCommands(ready.user.id), {
        body: commandDefinitions,
      });
      logger.info("Slash commands registered globally");
    } catch (err) {
      logger.error({ err }, "Failed to register slash commands");
    }
  });

  attachEventLogger(client);
  startServerStatsChannels(client);

  // Auto-kick blacklisted users that try to rejoin and run welcome
  client.on(Events.GuildMemberAdd, async (member) => {
    try {
      const bl = await isBlacklisted(member.guild.id, member.id);
      if (bl) {
        await logEvent(client, {
          guildId: member.guild.id,
          eventType: "blacklist_autokick",
          targetId: member.id,
          targetTag: member.user.username,
          summary: `${member.user.tag} intentó entrar pero está en la blacklist (motivo: ${bl.reason}). Re-baneado.`,
        });
        await member.guild.members
          .ban(member.id, {
            reason: `Blacklist activa: ${bl.reason}`,
            deleteMessageSeconds: 0,
          })
          .catch(() => undefined);
        return;
      }
      await handleMemberJoin(member);
    } catch (err) {
      logger.error({ err }, "Member join handler error");
    }
  });

  client.on(Events.InteractionCreate, async (interaction: Interaction) => {
    try {
      if (interaction.isChatInputCommand()) {
        await handleSlashCommand(interaction);
      } else if (interaction.isButton()) {
        if (interaction.customId === VERIFY_BUTTON_ID) {
          await handleVerifyButton(interaction);
        } else if (interaction.customId === TICKET_CLOSE_ID) {
          await handleTicketCloseButton(interaction);
        }
      }
    } catch (err) {
      logger.error({ err }, "Interaction handler error");
      if (
        interaction.isRepliable() &&
        !interaction.replied &&
        !interaction.deferred
      ) {
        await interaction
          .reply({
            content: "Ocurrió un error procesando esta acción.",
            flags: MessageFlags.Ephemeral,
          })
          .catch(() => undefined);
      }
    }
  });

  void loginWithRetry(client, token);
}

async function loginWithRetry(
  client: DiscordClient,
  token: string,
  maxAttempts = 8,
): Promise<void> {
  for (let attempt = 1; attempt <= maxAttempts; attempt++) {
    try {
      await client.login(token);
      return;
    } catch (err) {
      const wait = Math.min(30_000, 2_000 * attempt);
      logger.error(
        { err, attempt, nextRetryMs: wait },
        "Failed to log in to Discord — retrying",
      );
      await new Promise((r) => setTimeout(r, wait));
    }
  }
  logger.error({ maxAttempts }, "Giving up on Discord login after retries");
}

// ─────────────────────────────────────────────────────────────
// SLASH COMMAND ROUTER
// ─────────────────────────────────────────────────────────────

async function handleSlashCommand(
  interaction: ChatInputCommandInteraction,
): Promise<void> {
  if (!interaction.inGuild() || !interaction.guildId) {
    await interaction.reply({
      content: "Este comando solo funciona dentro de un servidor.",
      flags: MessageFlags.Ephemeral,
    });
    return;
  }

  switch (interaction.commandName) {
    case "setup":
      return handleSetup(interaction);
    case "config":
      return handleShowConfig(interaction);
    case "verificacion":
      return handleVerificationPanel(interaction);
    case "comunicado":
      return handleAnnouncement(interaction);
    case "venta":
      return handleSale(interaction);
    case "vouch":
      return handleVouch(interaction);
    case "vouches":
      return handleVouches(interaction);
    case "ticket":
      return handleTicketOpen(interaction);
    case "cerrar":
      return handleTicketClose(interaction);
    case "limpiar":
      return handleClear(interaction);
    case "warn":
      return handleWarn(interaction);
    case "warns":
      return handleWarnsList(interaction);
    case "kick":
      return handleKick(interaction);
    case "ban":
      return handleBan(interaction);
    case "blacklist":
      return handleBlacklist(interaction);
    case "logs":
      return handleLogsCommand(interaction);
    case "stats":
      return handleStats(interaction);
    case "escanear-admins":
      return handleAdminScan(interaction);
    case "avatar":
      return handleAvatar(interaction);
    case "acceso":
      return handleAcceso(interaction);
    case "timeout":
      return handleTimeout(interaction);
    case "untimeout":
      return handleUntimeout(interaction);
    case "lock":
      return handleLock(interaction);
    case "unlock":
      return handleUnlock(interaction);
    case "slowmode":
      return handleSlowmode(interaction);
  }
}

// ─────────────────────────────────────────────────────────────
// SETUP & CONFIG
// ─────────────────────────────────────────────────────────────

async function handleSetup(
  interaction: ChatInputCommandInteraction,
): Promise<void> {
  const guildId = interaction.guildId!;
  const verifiedRole = interaction.options.getRole("rol_verificado");
  const staffRole = interaction.options.getRole("rol_staff");
  const announcements = interaction.options.getChannel("canal_anuncios");
  const welcome = interaction.options.getChannel("canal_bienvenida");
  const sales = interaction.options.getChannel("canal_ventas");
  const vouches = interaction.options.getChannel("canal_vouches");
  const ticketsCategory = interaction.options.getChannel("categoria_tickets");
  const logs = interaction.options.getChannel("canal_logs");

  const patch: Partial<GuildConfig> = {};
  if (verifiedRole) patch.verifiedRoleId = verifiedRole.id;
  if (staffRole) patch.staffRoleId = staffRole.id;
  if (announcements) patch.announcementChannelId = announcements.id;
  if (welcome) patch.welcomeChannelId = welcome.id;
  if (sales) patch.salesChannelId = sales.id;
  if (vouches) patch.vouchChannelId = vouches.id;
  if (ticketsCategory) patch.ticketsCategoryId = ticketsCategory.id;
  if (logs) patch.logChannelId = logs.id;

  if (Object.keys(patch).length === 0) {
    await interaction.reply({
      content: "Indica al menos una opción para configurar (rol o canal).",
      flags: MessageFlags.Ephemeral,
    });
    return;
  }

  const cfg = await updateGuildConfig(guildId, patch);
  await interaction.reply({
    embeds: [buildConfigEmbed(cfg)],
    flags: MessageFlags.Ephemeral,
  });

  await logEvent(clientRef!, {
    guildId,
    eventType: "setup",
    actorId: interaction.user.id,
    actorTag: interaction.user.username,
    summary: `Se actualizó la configuración: ${Object.keys(patch).join(", ")}.`,
    metadata: patch as Record<string, unknown>,
  });
}

async function handleShowConfig(
  interaction: ChatInputCommandInteraction,
): Promise<void> {
  const cfg = await getGuildConfig(interaction.guildId!);
  await interaction.reply({
    embeds: [buildConfigEmbed(cfg)],
    flags: MessageFlags.Ephemeral,
  });
}

function buildConfigEmbed(cfg: GuildConfig) {
  const role = (id: string | null) => (id ? `<@&${id}>` : "_Sin configurar_");
  const channel = (id: string | null) =>
    id ? `<#${id}>` : "_Sin configurar_";
  return new EmbedBuilder()
    .setTitle("Configuración del bot")
    .setColor(BRAND_COLOR)
    .addFields(
      { name: "Rol verificado", value: role(cfg.verifiedRoleId), inline: true },
      { name: "Rol staff", value: role(cfg.staffRoleId), inline: true },
      { name: "\u200b", value: "\u200b", inline: true },
      {
        name: "Canal anuncios",
        value: channel(cfg.announcementChannelId),
        inline: true,
      },
      {
        name: "Canal bienvenida",
        value: channel(cfg.welcomeChannelId),
        inline: true,
      },
      { name: "Canal ventas", value: channel(cfg.salesChannelId), inline: true },
      {
        name: "Canal vouches",
        value: channel(cfg.vouchChannelId),
        inline: true,
      },
      {
        name: "Categoría tickets",
        value: channel(cfg.ticketsCategoryId),
        inline: true,
      },
      { name: "Canal logs", value: channel(cfg.logChannelId), inline: true },
      {
        name: "Panel verificación",
        value: channel(cfg.verificationChannelId),
        inline: true,
      },
    );
}

// ─────────────────────────────────────────────────────────────
// VERIFICATION
// ─────────────────────────────────────────────────────────────

async function handleVerificationPanel(
  interaction: ChatInputCommandInteraction,
): Promise<void> {
  const guildId = interaction.guildId!;
  const cfg = await getGuildConfig(guildId);

  if (!cfg.verificationEnabled) {
    await interaction.reply({
      content: "El módulo de verificación está desactivado desde el dashboard.",
      flags: MessageFlags.Ephemeral,
    });
    return;
  }

  if (!cfg.verifiedRoleId) {
    await interaction.reply({
      content: "Primero configura el rol con `/setup rol_verificado:<rol>`.",
      flags: MessageFlags.Ephemeral,
    });
    return;
  }

  const channel = interaction.channel;
  if (
    !channel ||
    !(
      channel.type === ChannelType.GuildText ||
      channel.type === ChannelType.GuildAnnouncement
    )
  ) {
    await interaction.reply({
      content: "Usa este comando dentro de un canal de texto.",
      flags: MessageFlags.Ephemeral,
    });
    return;
  }

  const title =
    interaction.options.getString("titulo") ?? "Verificación · Modeos el obi";
  const description =
    interaction.options.getString("descripcion") ??
    [
      "Bienvenido a **Modeos el obi**.",
      "",
      "Pulsa el botón **Verificarme** para confirmar que no eres un bot y desbloquear el acceso a la **zona de venta de Discords**, comunicados y demás canales.",
      "",
      "Al verificarte aceptas las normas del servidor.",
    ].join("\n");

  const embed = new EmbedBuilder()
    .setTitle(title)
    .setDescription(description)
    .setColor(BRAND_COLOR)
    .setFooter({ text: "Modeos el obi · Sistema de verificación" });

  const row = new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder()
      .setCustomId(VERIFY_BUTTON_ID)
      .setLabel("Verificarme")
      .setEmoji("✅")
      .setStyle(ButtonStyle.Success),
  );

  const sent = await (channel as TextChannel | NewsChannel).send({
    embeds: [embed],
    components: [row],
  });

  await updateGuildConfig(guildId, {
    verificationChannelId: channel.id,
    verificationMessageId: sent.id,
  });

  await interaction.reply({
    content: "Panel de verificación publicado correctamente.",
    flags: MessageFlags.Ephemeral,
  });
}

async function handleVerifyButton(
  interaction: ButtonInteraction,
): Promise<void> {
  if (!interaction.inGuild() || !interaction.guildId) return;
  const cfg = await getGuildConfig(interaction.guildId);
  if (!cfg.verificationEnabled) {
    await interaction.reply({
      content: "El módulo de verificación está desactivado desde el dashboard.",
      flags: MessageFlags.Ephemeral,
    });
    return;
  }
  if (!cfg.verifiedRoleId) {
    await interaction.reply({
      content:
        "El rol de verificación no está configurado. Avisa a un administrador.",
      flags: MessageFlags.Ephemeral,
    });
    return;
  }

  const guild = interaction.guild;
  if (!guild) return;
  const me = guild.members.me;
  if (!me?.permissions.has(PermissionFlagsBits.ManageRoles)) {
    await interaction.reply({
      content:
        "No tengo el permiso **Gestionar Roles**. Pídele a un admin que me lo conceda.",
      flags: MessageFlags.Ephemeral,
    });
    return;
  }

  const role = await guild.roles.fetch(cfg.verifiedRoleId).catch(() => null);
  if (!role) {
    await interaction.reply({
      content: "El rol configurado ya no existe. Avisa a un administrador.",
      flags: MessageFlags.Ephemeral,
    });
    return;
  }

  if (me.roles.highest.comparePositionTo(role) <= 0) {
    await interaction.reply({
      content:
        "Mi rol está por debajo del rol de verificación. Pide a un admin que suba mi rol por encima.",
      flags: MessageFlags.Ephemeral,
    });
    return;
  }

  const member = await guild.members
    .fetch(interaction.user.id)
    .catch(() => null);
  if (!member) {
    await interaction.reply({
      content: "No pude encontrarte en el servidor. Inténtalo de nuevo.",
      flags: MessageFlags.Ephemeral,
    });
    return;
  }

  if (member.roles.cache.has(role.id)) {
    await interaction.reply({
      content: "Ya estás verificado. ¡Disfruta del servidor!",
      flags: MessageFlags.Ephemeral,
    });
    return;
  }

  await member.roles.add(role, "Verificación por botón");
  await logEvent(clientRef!, {
    guildId: guild.id,
    eventType: "verification",
    actorId: interaction.user.id,
    actorTag: interaction.user.username,
    targetId: interaction.user.id,
    targetTag: interaction.user.username,
    summary: `${interaction.user.tag} se verificó y obtuvo <@&${role.id}>.`,
  });

  const embed = new EmbedBuilder()
    .setTitle("¡Verificado!")
    .setColor(0x22c55e)
    .setDescription(
      [
        "Ya tienes acceso a la **zona de venta de Discords** y al resto de canales.",
        "",
        "Recuerda revisar las normas y los comunicados anclados.",
      ].join("\n"),
    );

  await interaction.reply({
    embeds: [embed],
    flags: MessageFlags.Ephemeral,
  });
}

// ─────────────────────────────────────────────────────────────
// WELCOME
// ─────────────────────────────────────────────────────────────

async function handleMemberJoin(member: GuildMember): Promise<void> {
  if (member.user.bot) return;
  const cfg = await getGuildConfig(member.guild.id);
  if (!cfg.welcomeEnabled || !cfg.welcomeChannelId) return;

  const channel = await member.guild.channels
    .fetch(cfg.welcomeChannelId)
    .catch(() => null);
  if (!channel || channel.type !== ChannelType.GuildText) return;

  await channel.send(buildWelcomePayload(getWelcomeContext(member), cfg));
}

// ─────────────────────────────────────────────────────────────
// ANNOUNCEMENTS
// ─────────────────────────────────────────────────────────────

async function handleAnnouncement(
  interaction: ChatInputCommandInteraction,
): Promise<void> {
  const cfg = await getGuildConfig(interaction.guildId!);
  if (!cfg.announcementsEnabled) {
    await interaction.reply({
      content: "El módulo de anuncios está desactivado desde el dashboard.",
      flags: MessageFlags.Ephemeral,
    });
    return;
  }

  const title = interaction.options.getString("titulo", true);
  const message = interaction.options.getString("mensaje", true);
  const colorHex = interaction.options.getString("color") ?? "9333EA";
  const mentionEveryone =
    interaction.options.getBoolean("mencionar_todos") ?? false;

  const targetChannelOpt = interaction.options.getChannel("canal");
  const targetId = targetChannelOpt?.id ?? cfg.announcementChannelId;
  if (!targetId) {
    await interaction.reply({
      content:
        "No hay canal de anuncios. Pasa uno en `canal:` o configúralo con `/setup canal_anuncios:<canal>`.",
      flags: MessageFlags.Ephemeral,
    });
    return;
  }

  const guild = interaction.guild!;
  const channel = await guild.channels.fetch(targetId).catch(() => null);
  if (
    !channel ||
    !(
      channel.type === ChannelType.GuildText ||
      channel.type === ChannelType.GuildAnnouncement
    )
  ) {
    await interaction.reply({
      content: "El canal indicado no existe o no es de texto.",
      flags: MessageFlags.Ephemeral,
    });
    return;
  }

  const cleanMessage = message.replace(/\\n/g, "\n");
  const embed = new EmbedBuilder()
    .setTitle(title)
    .setDescription(cleanMessage)
    .setColor(parseInt(colorHex, 16))
    .setTimestamp(new Date())
    .setFooter({
      text: `Comunicado · por ${interaction.user.username}`,
      iconURL: interaction.user.displayAvatarURL(),
    });

  await (channel as TextChannel | NewsChannel).send({
    content: mentionEveryone ? "@everyone" : undefined,
    embeds: [embed],
    allowedMentions: mentionEveryone ? { parse: ["everyone"] } : { parse: [] },
  });

  await interaction.reply({
    content: `Comunicado publicado en <#${channel.id}>.`,
    flags: MessageFlags.Ephemeral,
  });

  await logEvent(clientRef!, {
    guildId: interaction.guildId!,
    eventType: "announcement",
    actorId: interaction.user.id,
    actorTag: interaction.user.username,
    channelId: channel.id,
    summary: `Comunicado **${title}** publicado en <#${channel.id}>.`,
  });
}

// ─────────────────────────────────────────────────────────────
// SALES LISTING
// ─────────────────────────────────────────────────────────────

async function handleSale(
  interaction: ChatInputCommandInteraction,
): Promise<void> {
  const cfg = await getGuildConfig(interaction.guildId!);
  if (!cfg.salesEnabled) {
    await interaction.reply({
      content: "El módulo de ventas está desactivado desde el dashboard.",
      flags: MessageFlags.Ephemeral,
    });
    return;
  }
  if (!cfg.salesChannelId) {
    await interaction.reply({
      content:
        "El canal de ventas no está configurado. Pídele a un admin que use `/setup canal_ventas:<canal>`.",
      flags: MessageFlags.Ephemeral,
    });
    return;
  }

  const guild = interaction.guild!;
  const channel = await guild.channels
    .fetch(cfg.salesChannelId)
    .catch(() => null);
  if (
    !channel ||
    !(
      channel.type === ChannelType.GuildText ||
      channel.type === ChannelType.GuildAnnouncement
    )
  ) {
    await interaction.reply({
      content: "El canal de ventas configurado ya no existe.",
      flags: MessageFlags.Ephemeral,
    });
    return;
  }

  const nombre = interaction.options.getString("nombre", true);
  const miembros = interaction.options.getInteger("miembros", true);
  const precio = interaction.options.getString("precio", true);
  const nicho = interaction.options.getString("nicho", true);
  const descripcion = interaction.options
    .getString("descripcion", true)
    .replace(/\\n/g, "\n");
  const metodos = interaction.options.getString("metodos_pago");
  const imagen = interaction.options.getString("imagen");

  const embed = new EmbedBuilder()
    .setTitle(`💎 ${nombre}`)
    .setColor(BRAND_COLOR)
    .setDescription(descripcion)
    .addFields(
      {
        name: "👥 Miembros",
        value: miembros.toLocaleString("es-ES"),
        inline: true,
      },
      { name: "💰 Precio", value: precio, inline: true },
      { name: "📂 Nicho", value: nicho, inline: true },
    )
    .setFooter({
      text: `Vendedor: ${interaction.user.username} · Usa /vouch para reseñar tras la compra`,
      iconURL: interaction.user.displayAvatarURL(),
    })
    .setTimestamp(new Date());

  if (metodos) embed.addFields({ name: "💳 Métodos de pago", value: metodos });
  if (imagen && /^https?:\/\//i.test(imagen)) embed.setImage(imagen);

  const row = new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder()
      .setLabel("Contactar al vendedor")
      .setStyle(ButtonStyle.Link)
      .setURL(`https://discord.com/users/${interaction.user.id}`),
  );

  const sent = await (channel as TextChannel | NewsChannel).send({
    content: `Nueva venta de <@${interaction.user.id}>`,
    embeds: [embed],
    components: [row],
    allowedMentions: { users: [interaction.user.id] },
  });

  await recordSale({
    guildId: interaction.guildId!,
    sellerId: interaction.user.id,
    sellerTag: interaction.user.username,
    name: nombre,
    members: miembros,
    price: precio,
    niche: nicho,
    description: descripcion,
    paymentMethods: metodos ?? null,
    imageUrl: imagen ?? null,
    channelId: channel.id,
    messageId: sent.id,
  });

  await interaction.reply({
    content: `Tu venta se publicó en <#${channel.id}>.`,
    flags: MessageFlags.Ephemeral,
  });

  await logEvent(clientRef!, {
    guildId: interaction.guildId!,
    eventType: "sale",
    actorId: interaction.user.id,
    actorTag: interaction.user.username,
    channelId: channel.id,
    summary: `${interaction.user.tag} publicó **${nombre}** (${miembros.toLocaleString(
      "es-ES",
    )} miembros · ${precio}).`,
  });
}

// ─────────────────────────────────────────────────────────────
// VOUCHES
// ─────────────────────────────────────────────────────────────

async function handleVouch(
  interaction: ChatInputCommandInteraction,
): Promise<void> {
  const cfg = await getGuildConfig(interaction.guildId!);
  if (!cfg.vouchesEnabled) {
    await interaction.reply({
      content: "El módulo de vouches está desactivado desde el dashboard.",
      flags: MessageFlags.Ephemeral,
    });
    return;
  }

  const seller = interaction.options.getUser("vendedor", true);
  const stars = interaction.options.getInteger("estrellas", true);
  const comment = interaction.options.getString("comentario", true);

  if (seller.id === interaction.user.id) {
    await interaction.reply({
      content: "No puedes dejarte una reseña a ti mismo.",
      flags: MessageFlags.Ephemeral,
    });
    return;
  }
  if (seller.bot) {
    await interaction.reply({
      content: "No puedes dejar reseñas a bots.",
      flags: MessageFlags.Ephemeral,
    });
    return;
  }

  await addVouch({
    guildId: interaction.guildId!,
    sellerId: seller.id,
    buyerId: interaction.user.id,
    buyerTag: interaction.user.username,
    stars,
    comment,
  });

  const allVouches = await getVouchesFor(interaction.guildId!, seller.id);
  const avg = average(allVouches.map((v) => v.stars));

  const embed = new EmbedBuilder()
    .setTitle("⭐ Nueva reseña de vendedor")
    .setColor(0xeab308)
    .setThumbnail(seller.displayAvatarURL({ size: 256 }))
    .setDescription(
      [
        `**Vendedor:** ${seller.toString()}`,
        `**Comprador:** ${interaction.user.toString()}`,
        `**Puntuación:** ${stars}/5  ${"★".repeat(stars)}${"☆".repeat(5 - stars)}`,
        "",
        `> ${comment}`,
      ].join("\n"),
    )
    .setFooter({
      text: `Reputación total: ${allVouches.length} reseñas · Media ${avg.toFixed(2)}/5`,
    })
    .setTimestamp(new Date());

  let postedTo: string | null = null;
  if (cfg.vouchChannelId) {
    const channel = await interaction.guild!.channels
      .fetch(cfg.vouchChannelId)
      .catch(() => null);
    if (channel && channel.type === ChannelType.GuildText) {
      await channel.send({
        embeds: [embed],
        allowedMentions: { users: [seller.id] },
      });
      postedTo = channel.id;
    }
  }

  await interaction.reply({
    content: postedTo
      ? `¡Reseña publicada en <#${postedTo}>!`
      : "¡Reseña guardada! (No hay canal de vouches configurado, así que no se publicó.)",
    embeds: postedTo ? [] : [embed],
    flags: MessageFlags.Ephemeral,
  });

  await logEvent(clientRef!, {
    guildId: interaction.guildId!,
    eventType: "vouch",
    actorId: interaction.user.id,
    actorTag: interaction.user.username,
    targetId: seller.id,
    targetTag: seller.username,
    summary: `${interaction.user.tag} dejó ${stars}★ a ${seller.tag}.`,
  });
}

async function handleVouches(
  interaction: ChatInputCommandInteraction,
): Promise<void> {
  const cfg = await getGuildConfig(interaction.guildId!);
  if (!cfg.vouchesEnabled) {
    await interaction.reply({
      content: "El módulo de vouches está desactivado desde el dashboard.",
      flags: MessageFlags.Ephemeral,
    });
    return;
  }

  const seller = interaction.options.getUser("vendedor", true);
  const all = await getVouchesFor(interaction.guildId!, seller.id);

  if (all.length === 0) {
    await interaction.reply({
      content: `${seller.toString()} todavía no tiene reseñas.`,
      flags: MessageFlags.Ephemeral,
      allowedMentions: { parse: [] },
    });
    return;
  }

  const avg = average(all.map((v) => v.stars));
  const recent = all.slice(0, 5);

  const embed = new EmbedBuilder()
    .setTitle(`Reputación de ${seller.username}`)
    .setColor(0xeab308)
    .setThumbnail(seller.displayAvatarURL({ size: 256 }))
    .setDescription(
      [
        `**Reseñas totales:** ${all.length}`,
        `**Media:** ${avg.toFixed(2)}/5  ${"★".repeat(Math.round(avg))}${"☆".repeat(5 - Math.round(avg))}`,
      ].join("\n"),
    )
    .addFields(
      recent.map((v) => ({
        name: `${"★".repeat(v.stars)}${"☆".repeat(5 - v.stars)} · ${v.buyerTag}`,
        value: `${v.comment.slice(0, 200)}\n_${formatDate(v.createdAt)}_`,
      })),
    );

  await interaction.reply({
    embeds: [embed],
    flags: MessageFlags.Ephemeral,
  });
}

function average(nums: number[]): number {
  if (nums.length === 0) return 0;
  return nums.reduce((a, b) => a + b, 0) / nums.length;
}

function formatDate(date: Date | string): string {
  const d = date instanceof Date ? date : new Date(date);
  return d.toLocaleDateString("es-ES", {
    day: "2-digit",
    month: "short",
    year: "numeric",
  });
}

// ─────────────────────────────────────────────────────────────
// TICKETS
// ─────────────────────────────────────────────────────────────

async function handleTicketOpen(
  interaction: ChatInputCommandInteraction,
): Promise<void> {
  const cfg = await getGuildConfig(interaction.guildId!);
  if (!cfg.ticketsEnabled) {
    await interaction.reply({
      content: "El módulo de tickets está desactivado desde el dashboard.",
      flags: MessageFlags.Ephemeral,
    });
    return;
  }
  if (!cfg.ticketsCategoryId) {
    await interaction.reply({
      content:
        "Los tickets no están configurados. Pídele a un admin que use `/setup categoria_tickets:<categoría>`.",
      flags: MessageFlags.Ephemeral,
    });
    return;
  }

  const guild = interaction.guild!;
  const category = await guild.channels
    .fetch(cfg.ticketsCategoryId)
    .catch(() => null);
  if (!category || category.type !== ChannelType.GuildCategory) {
    await interaction.reply({
      content: "La categoría de tickets ya no existe.",
      flags: MessageFlags.Ephemeral,
    });
    return;
  }

  const motivo = interaction.options.getString("motivo", true);

  const existing = guild.channels.cache.find(
    (c) =>
      c.type === ChannelType.GuildText &&
      c.parentId === category.id &&
      c.topic === `${TICKET_TOPIC_PREFIX}${interaction.user.id}`,
  );
  if (existing) {
    await interaction.reply({
      content: `Ya tienes un ticket abierto: <#${existing.id}>.`,
      flags: MessageFlags.Ephemeral,
    });
    return;
  }

  const overwrites = [
    {
      id: guild.roles.everyone.id,
      deny: [PermissionFlagsBits.ViewChannel],
      type: OverwriteType.Role,
    },
    {
      id: interaction.user.id,
      allow: [
        PermissionFlagsBits.ViewChannel,
        PermissionFlagsBits.SendMessages,
        PermissionFlagsBits.ReadMessageHistory,
        PermissionFlagsBits.AttachFiles,
        PermissionFlagsBits.EmbedLinks,
      ],
      type: OverwriteType.Member,
    },
  ];
  if (cfg.staffRoleId) {
    overwrites.push({
      id: cfg.staffRoleId,
      allow: [
        PermissionFlagsBits.ViewChannel,
        PermissionFlagsBits.SendMessages,
        PermissionFlagsBits.ReadMessageHistory,
        PermissionFlagsBits.ManageMessages,
      ],
      type: OverwriteType.Role,
    });
  }

  const safeName =
    interaction.user.username
      .toLowerCase()
      .replace(/[^a-z0-9-]/g, "")
      .slice(0, 20) || "usuario";
  const channelName = `ticket-${safeName}`;

  const channel = await guild.channels.create({
    name: channelName,
    type: ChannelType.GuildText,
    parent: category.id,
    topic: `${TICKET_TOPIC_PREFIX}${interaction.user.id}`,
    permissionOverwrites: overwrites,
    reason: `Ticket abierto por ${interaction.user.tag}`,
  });

  const embed = new EmbedBuilder()
    .setTitle("🎫 Ticket abierto")
    .setColor(BRAND_COLOR)
    .setDescription(
      [
        `Hola ${interaction.user.toString()}, el staff te atenderá en breve.`,
        "",
        `**Motivo:** ${motivo}`,
        "",
        "Cuando termines, pulsa **Cerrar ticket** o usa `/cerrar`.",
      ].join("\n"),
    )
    .setTimestamp(new Date());

  const row = new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder()
      .setCustomId(TICKET_CLOSE_ID)
      .setLabel("Cerrar ticket")
      .setEmoji("🔒")
      .setStyle(ButtonStyle.Danger),
  );

  await channel.send({
    content: cfg.staffRoleId
      ? `<@&${cfg.staffRoleId}> ${interaction.user.toString()}`
      : interaction.user.toString(),
    embeds: [embed],
    components: [row],
    allowedMentions: {
      users: [interaction.user.id],
      roles: cfg.staffRoleId ? [cfg.staffRoleId] : [],
    },
  });

  await interaction.reply({
    content: `Ticket creado: <#${channel.id}>.`,
    flags: MessageFlags.Ephemeral,
  });

  await logEvent(clientRef!, {
    guildId: interaction.guildId!,
    eventType: "ticket_open",
    actorId: interaction.user.id,
    actorTag: interaction.user.username,
    channelId: channel.id,
    summary: `${interaction.user.tag} abrió un ticket — Motivo: ${motivo}`,
  });
}

async function handleTicketClose(
  interaction: ChatInputCommandInteraction,
): Promise<void> {
  await closeTicket(interaction);
}

async function handleTicketCloseButton(
  interaction: ButtonInteraction,
): Promise<void> {
  await closeTicket(interaction);
}

async function closeTicket(
  interaction: ChatInputCommandInteraction | ButtonInteraction,
): Promise<void> {
  const channel = interaction.channel;
  if (
    !channel ||
    channel.type !== ChannelType.GuildText ||
    !channel.topic?.startsWith(TICKET_TOPIC_PREFIX)
  ) {
    await interaction.reply({
      content: "Este comando solo funciona dentro de un ticket.",
      flags: MessageFlags.Ephemeral,
    });
    return;
  }

  const ticketOwnerId = channel.topic.slice(TICKET_TOPIC_PREFIX.length);
  const cfg = await getGuildConfig(interaction.guildId!);
  if (!cfg.ticketsEnabled) {
    await interaction.reply({
      content: "El módulo de tickets está desactivado desde el dashboard.",
      flags: MessageFlags.Ephemeral,
    });
    return;
  }
  const member = interaction.member;
  const isOwner = interaction.user.id === ticketOwnerId;
  const isStaff =
    !!cfg.staffRoleId &&
    !!member &&
    "roles" in member &&
    "cache" in member.roles &&
    member.roles.cache.has(cfg.staffRoleId);
  const isAdmin =
    !!member &&
    "permissions" in member &&
    typeof member.permissions !== "string" &&
    member.permissions.has(PermissionFlagsBits.ManageChannels);

  if (!isOwner && !isStaff && !isAdmin) {
    await interaction.reply({
      content: "Solo el dueño del ticket o el staff pueden cerrarlo.",
      flags: MessageFlags.Ephemeral,
    });
    return;
  }

  await interaction.reply({
    embeds: [
      new EmbedBuilder()
        .setTitle("Cerrando ticket en 5 segundos…")
        .setColor(0xef4444)
        .setDescription(`Cerrado por ${interaction.user.toString()}.`),
    ],
  });

  await logEvent(clientRef!, {
    guildId: interaction.guildId!,
    eventType: "ticket_close",
    actorId: interaction.user.id,
    actorTag: interaction.user.username,
    channelId: channel.id,
    targetId: ticketOwnerId,
    summary: `Ticket de <@${ticketOwnerId}> cerrado por ${interaction.user.tag}.`,
  });

  setTimeout(() => {
    channel
      .delete(`Ticket cerrado por ${interaction.user.tag}`)
      .catch(() => undefined);
  }, 5000);
}

// ─────────────────────────────────────────────────────────────
// MODERATION
// ─────────────────────────────────────────────────────────────

async function handleClear(
  interaction: ChatInputCommandInteraction,
): Promise<void> {
  const channel = interaction.channel;
  if (!channel || channel.type !== ChannelType.GuildText) {
    await interaction.reply({
      content: "Solo en canales de texto.",
      flags: MessageFlags.Ephemeral,
    });
    return;
  }
  const amount = interaction.options.getInteger("cantidad", true);
  const deleted = await channel.bulkDelete(amount, true).catch(() => null);
  if (!deleted) {
    await interaction.reply({
      content:
        "No pude borrar los mensajes (¿quizá tienen más de 14 días o me faltan permisos?).",
      flags: MessageFlags.Ephemeral,
    });
    return;
  }
  await interaction.reply({
    content: `🧹 Borrados ${deleted.size} mensajes.`,
    flags: MessageFlags.Ephemeral,
  });

  await logEvent(clientRef!, {
    guildId: interaction.guildId!,
    eventType: "clear",
    actorId: interaction.user.id,
    actorTag: interaction.user.username,
    channelId: channel.id,
    summary: `${interaction.user.tag} borró ${deleted.size} mensajes en <#${channel.id}>.`,
  });
}

async function handleWarn(
  interaction: ChatInputCommandInteraction,
): Promise<void> {
  const user = interaction.options.getUser("usuario", true);
  const reason = interaction.options.getString("razon", true);

  if (user.bot) {
    await interaction.reply({
      content: "No puedes avisar a un bot.",
      flags: MessageFlags.Ephemeral,
    });
    return;
  }

  await addWarn({
    guildId: interaction.guildId!,
    userId: user.id,
    userTag: user.username,
    moderatorId: interaction.user.id,
    reason,
  });

  const list = await getWarnsFor(interaction.guildId!, user.id);

  const embed = new EmbedBuilder()
    .setTitle("⚠️ Aviso")
    .setColor(0xef4444)
    .setDescription(
      [
        `**Usuario:** ${user.toString()}`,
        `**Moderador:** ${interaction.user.toString()}`,
        `**Razón:** ${reason}`,
        "",
        `Avisos totales: **${list.length}**`,
      ].join("\n"),
    )
    .setTimestamp(new Date());

  await interaction.reply({
    embeds: [embed],
    allowedMentions: { users: [user.id] },
  });

  await user
    .send({
      embeds: [
        new EmbedBuilder()
          .setTitle(`Has recibido un aviso en ${interaction.guild!.name}`)
          .setColor(0xef4444)
          .setDescription(`**Razón:** ${reason}`),
      ],
    })
    .catch(() => undefined);

  await logEvent(clientRef!, {
    guildId: interaction.guildId!,
    eventType: "warn",
    actorId: interaction.user.id,
    actorTag: interaction.user.username,
    targetId: user.id,
    targetTag: user.username,
    summary: `Aviso a ${user.tag} (total ${list.length}). Razón: ${reason}`,
  });
}

async function handleWarnsList(
  interaction: ChatInputCommandInteraction,
): Promise<void> {
  const user = interaction.options.getUser("usuario", true);
  const list = await getWarnsFor(interaction.guildId!, user.id);
  if (list.length === 0) {
    await interaction.reply({
      content: `${user.toString()} no tiene avisos.`,
      flags: MessageFlags.Ephemeral,
      allowedMentions: { parse: [] },
    });
    return;
  }

  const embed = new EmbedBuilder()
    .setTitle(`Avisos de ${user.username}`)
    .setColor(0xef4444)
    .setThumbnail(user.displayAvatarURL({ size: 256 }))
    .setDescription(`Total: **${list.length}** avisos`)
    .addFields(
      list.slice(0, 10).map((w, i) => ({
        name: `#${list.length - i} · ${formatDate(w.createdAt)}`,
        value: `**Razón:** ${w.reason}\n**Mod:** <@${w.moderatorId}>`,
      })),
    );

  await interaction.reply({
    embeds: [embed],
    flags: MessageFlags.Ephemeral,
  });
}

async function handleKick(
  interaction: ChatInputCommandInteraction,
): Promise<void> {
  const user = interaction.options.getUser("usuario", true);
  const reason = interaction.options.getString("razon") ?? "Sin razón";
  const member = await interaction.guild!.members
    .fetch(user.id)
    .catch(() => null);
  if (!member) {
    await interaction.reply({
      content: "Ese usuario no está en el servidor.",
      flags: MessageFlags.Ephemeral,
    });
    return;
  }
  if (!member.kickable) {
    await interaction.reply({
      content: "No puedo expulsar a ese usuario (jerarquía o permisos).",
      flags: MessageFlags.Ephemeral,
    });
    return;
  }
  await member.kick(`${reason} · por ${interaction.user.tag}`);
  await interaction.reply({
    embeds: [
      new EmbedBuilder()
        .setTitle("👢 Usuario expulsado")
        .setColor(0xef4444)
        .setDescription(
          `**${user.username}** fue expulsado.\n**Razón:** ${reason}`,
        ),
    ],
  });

  await logEvent(clientRef!, {
    guildId: interaction.guildId!,
    eventType: "member_kick",
    actorId: interaction.user.id,
    actorTag: interaction.user.username,
    targetId: user.id,
    targetTag: user.username,
    summary: `${user.tag} fue expulsado por ${interaction.user.tag}. Razón: ${reason}`,
  });
}

async function handleBan(
  interaction: ChatInputCommandInteraction,
): Promise<void> {
  const user = interaction.options.getUser("usuario", true);
  const reason = interaction.options.getString("razon") ?? "Sin razón";
  const guild = interaction.guild!;
  const member = await guild.members.fetch(user.id).catch(() => null);
  if (member && !member.bannable) {
    await interaction.reply({
      content: "No puedo banear a ese usuario (jerarquía o permisos).",
      flags: MessageFlags.Ephemeral,
    });
    return;
  }
  await guild.members.ban(user.id, {
    reason: `${reason} · por ${interaction.user.tag}`,
    deleteMessageSeconds: 0,
  });
  await interaction.reply({
    embeds: [
      new EmbedBuilder()
        .setTitle("🔨 Usuario baneado")
        .setColor(0xef4444)
        .setDescription(
          `**${user.username}** fue baneado.\n**Razón:** ${reason}`,
        ),
    ],
  });
}

// ─────────────────────────────────────────────────────────────
// BLACKLIST
// ─────────────────────────────────────────────────────────────

async function handleBlacklist(
  interaction: ChatInputCommandInteraction,
): Promise<void> {
  const sub = interaction.options.getSubcommand();
  switch (sub) {
    case "add":
      return handleBlacklistAdd(interaction);
    case "remove":
      return handleBlacklistRemove(interaction);
    case "check":
      return handleBlacklistCheck(interaction);
    case "list":
      return handleBlacklistList(interaction);
  }
}

async function handleBlacklistAdd(
  interaction: ChatInputCommandInteraction,
): Promise<void> {
  const user = interaction.options.getUser("usuario", true);
  const reason = interaction.options.getString("razon", true);
  const guild = interaction.guild!;

  if (user.bot) {
    await interaction.reply({
      content: "No tiene sentido añadir bots a la blacklist.",
      flags: MessageFlags.Ephemeral,
    });
    return;
  }
  if (user.id === interaction.user.id) {
    await interaction.reply({
      content: "No puedes añadirte a ti mismo.",
      flags: MessageFlags.Ephemeral,
    });
    return;
  }

  const result = await addToBlacklist({
    guildId: guild.id,
    userId: user.id,
    userTag: user.username,
    reason,
    addedById: interaction.user.id,
    addedByTag: interaction.user.username,
  });

  if (!result.added) {
    await interaction.reply({
      content: `${user.toString()} ya está en la blacklist.`,
      flags: MessageFlags.Ephemeral,
      allowedMentions: { parse: [] },
    });
    return;
  }

  // Try to ban so even existing members are removed
  let banResult: "banned" | "skipped" | "error" = "skipped";
  try {
    const member = await guild.members.fetch(user.id).catch(() => null);
    if (member && !member.bannable) {
      banResult = "error";
    } else {
      await guild.members.ban(user.id, {
        reason: `Blacklist: ${reason}`,
        deleteMessageSeconds: 0,
      });
      banResult = "banned";
    }
  } catch {
    banResult = "error";
  }

  const embed = new EmbedBuilder()
    .setTitle("⛔ Añadido a la blacklist")
    .setColor(0x991b1b)
    .setThumbnail(user.displayAvatarURL({ size: 256 }))
    .setDescription(
      [
        `**Usuario:** ${user.toString()} (${user.tag})`,
        `**Razón:** ${reason}`,
        `**Añadido por:** ${interaction.user.toString()}`,
        "",
        banResult === "banned"
          ? "🔨 Usuario baneado del servidor."
          : banResult === "error"
            ? "⚠️ No pude banearlo (jerarquía o permisos), pero queda en la blacklist."
            : "El usuario queda registrado en la blacklist.",
      ].join("\n"),
    );

  await interaction.reply({ embeds: [embed] });

  await logEvent(clientRef!, {
    guildId: guild.id,
    eventType: "blacklist_add",
    actorId: interaction.user.id,
    actorTag: interaction.user.username,
    targetId: user.id,
    targetTag: user.username,
    summary: `${user.tag} añadido a la blacklist por ${interaction.user.tag}. Razón: ${reason}.`,
    metadata: { banResult },
  });
}

async function handleBlacklistRemove(
  interaction: ChatInputCommandInteraction,
): Promise<void> {
  const user = interaction.options.getUser("usuario", true);
  const guild = interaction.guild!;
  const removed = await removeFromBlacklist(guild.id, user.id);
  if (!removed) {
    await interaction.reply({
      content: `${user.toString()} no estaba en la blacklist.`,
      flags: MessageFlags.Ephemeral,
      allowedMentions: { parse: [] },
    });
    return;
  }

  let unbanResult = "skipped";
  try {
    await guild.bans.remove(user.id, `Blacklist eliminada por ${interaction.user.tag}`);
    unbanResult = "unbanned";
  } catch {
    unbanResult = "no-ban";
  }

  await interaction.reply({
    embeds: [
      new EmbedBuilder()
        .setTitle("♻️ Quitado de la blacklist")
        .setColor(0x16a34a)
        .setDescription(
          [
            `${user.toString()} ya no está en la blacklist.`,
            unbanResult === "unbanned"
              ? "Y también ha sido desbaneado del servidor."
              : "(No estaba baneado actualmente.)",
          ].join("\n"),
        ),
    ],
  });

  await logEvent(clientRef!, {
    guildId: guild.id,
    eventType: "blacklist_remove",
    actorId: interaction.user.id,
    actorTag: interaction.user.username,
    targetId: user.id,
    targetTag: user.username,
    summary: `${user.tag} quitado de la blacklist por ${interaction.user.tag}.`,
  });
}

async function handleBlacklistCheck(
  interaction: ChatInputCommandInteraction,
): Promise<void> {
  const user = interaction.options.getUser("usuario", true);
  const entry = await isBlacklisted(interaction.guildId!, user.id);
  if (!entry) {
    await interaction.reply({
      content: `✅ ${user.toString()} **no** está en la blacklist.`,
      flags: MessageFlags.Ephemeral,
      allowedMentions: { parse: [] },
    });
    return;
  }
  const embed = new EmbedBuilder()
    .setTitle("⛔ Usuario en la blacklist")
    .setColor(0x991b1b)
    .setThumbnail(user.displayAvatarURL({ size: 256 }))
    .addFields(
      { name: "Usuario", value: `${user.toString()} (${entry.userTag})` },
      { name: "Razón", value: entry.reason },
      {
        name: "Añadido por",
        value: `<@${entry.addedById}> (${entry.addedByTag})`,
        inline: true,
      },
      { name: "Fecha", value: formatDate(entry.createdAt), inline: true },
    );
  await interaction.reply({
    embeds: [embed],
    flags: MessageFlags.Ephemeral,
  });
}

async function handleBlacklistList(
  interaction: ChatInputCommandInteraction,
): Promise<void> {
  const list = await listBlacklist(interaction.guildId!);
  if (list.length === 0) {
    await interaction.reply({
      content: "La blacklist está vacía.",
      flags: MessageFlags.Ephemeral,
    });
    return;
  }
  const lines = list
    .slice(0, 25)
    .map(
      (b, i) =>
        `**${i + 1}.** <@${b.userId}> · ${b.reason} · _por ${b.addedByTag} el ${formatDate(b.createdAt)}_`,
    );
  const embed = new EmbedBuilder()
    .setTitle(`⛔ Blacklist · ${list.length} usuarios`)
    .setColor(0x991b1b)
    .setDescription(lines.join("\n"))
    .setFooter({
      text:
        list.length > 25
          ? `Mostrando los primeros 25 de ${list.length}`
          : "Lista completa",
    });
  await interaction.reply({
    embeds: [embed],
    flags: MessageFlags.Ephemeral,
    allowedMentions: { parse: [] },
  });
}

// ─────────────────────────────────────────────────────────────
// LOGS COMMAND
// ─────────────────────────────────────────────────────────────

async function handleLogsCommand(
  interaction: ChatInputCommandInteraction,
): Promise<void> {
  const limit = interaction.options.getInteger("cantidad") ?? 10;
  const events = await getRecentEvents(interaction.guildId!, limit);
  if (events.length === 0) {
    await interaction.reply({
      content: "Aún no hay eventos registrados.",
      flags: MessageFlags.Ephemeral,
    });
    return;
  }
  const lines = events.map((e) => {
    const ts = `<t:${Math.floor(new Date(e.createdAt).getTime() / 1000)}:R>`;
    return `**${e.eventType}** · ${ts}\n${e.summary.slice(0, 240)}`;
  });
  const embed = new EmbedBuilder()
    .setTitle(`📜 Últimos ${events.length} eventos`)
    .setColor(BRAND_COLOR)
    .setDescription(lines.join("\n\n"));
  await interaction.reply({
    embeds: [embed],
    flags: MessageFlags.Ephemeral,
    allowedMentions: { parse: [] },
  });
}

// ─────────────────────────────────────────────────────────────
// INFO
// ─────────────────────────────────────────────────────────────

async function handleStats(
  interaction: ChatInputCommandInteraction,
): Promise<void> {
  const guild = interaction.guild!;
  await guild.members.fetch().catch(() => undefined);

  const total = guild.memberCount;
  const humans = guild.members.cache.filter((m) => !m.user.bot).size;
  const bots = guild.members.cache.filter((m) => m.user.bot).size;
  const channels = guild.channels.cache.size;
  const roles = guild.roles.cache.size;

  const embed = new EmbedBuilder()
    .setTitle(`📊 Estadísticas de ${guild.name}`)
    .setColor(BRAND_COLOR)
    .setThumbnail(guild.iconURL({ size: 256 }))
    .addFields(
      { name: "Miembros", value: total.toLocaleString("es-ES"), inline: true },
      { name: "Humanos", value: humans.toLocaleString("es-ES"), inline: true },
      { name: "Bots", value: bots.toLocaleString("es-ES"), inline: true },
      { name: "Canales", value: channels.toString(), inline: true },
      { name: "Roles", value: roles.toString(), inline: true },
      {
        name: "Creado",
        value: `<t:${Math.floor(guild.createdTimestamp / 1000)}:R>`,
        inline: true,
      },
    );

  await interaction.reply({ embeds: [embed] });
}

async function handleAdminScan(
  interaction: ChatInputCommandInteraction,
): Promise<void> {
  const guild = interaction.guild!;
  if (!interaction.memberPermissions?.has(PermissionFlagsBits.Administrator)) {
    await interaction.reply({
      content: "Solo los administradores pueden ejecutar este escaneo.",
      flags: MessageFlags.Ephemeral,
    });
    return;
  }

  try {
    await guild.members.fetch();
  } catch {
    await interaction.reply({
      content: "No pude cargar la lista completa de miembros para escanear los administradores.",
      flags: MessageFlags.Ephemeral,
    });
    return;
  }

  const administrators = guild.members.cache
    .filter((member) => member.permissions.has(PermissionFlagsBits.Administrator))
    .sort((a, b) => b.roles.highest.position - a.roles.highest.position);

  if (administrators.size === 0) {
    await interaction.reply({
      content: "El escaneo terminó: no se encontraron miembros con el permiso Administrador.",
      flags: MessageFlags.Ephemeral,
    });
    return;
  }

  const shown = [...administrators.values()].slice(0, 25);
  const lines = shown.map((member, index) => {
    const roles = member.roles.cache
      .filter((role) => role.id !== guild.id)
      .sort((a, b) => b.position - a.position)
      .map((role) => role.name)
      .slice(0, 3);
    const roleText = roles.length > 0 ? ` · Roles: ${roles.join(", ")}` : "";
    const botMarker = member.user.bot ? " · Bot" : "";
    return `**${index + 1}.** ${member.toString()} · \`${member.user.username}\`${botMarker}${roleText}`;
  });

  const embed = new EmbedBuilder()
    .setTitle("🛡️ Escaneo de administradores")
    .setColor(BRAND_COLOR)
    .setDescription(lines.join("\n"))
    .addFields(
      {
        name: "Administradores encontrados",
        value: administrators.size.toLocaleString("es-ES"),
        inline: true,
      },
      {
        name: "Escaneados",
        value: guild.memberCount.toLocaleString("es-ES"),
        inline: true,
      },
    )
    .setFooter({
      text:
        administrators.size > shown.length
          ? `Mostrando ${shown.length} de ${administrators.size}`
          : "Escaneo completado",
    })
    .setTimestamp();

  await interaction.reply({
    embeds: [embed],
    flags: MessageFlags.Ephemeral,
    allowedMentions: { parse: [] },
  });
}

async function handleAvatar(
  interaction: ChatInputCommandInteraction,
): Promise<void> {
  const user = interaction.options.getUser("usuario") ?? interaction.user;
  const embed = new EmbedBuilder()
    .setTitle(`Avatar de ${user.username}`)
    .setColor(BRAND_COLOR)
    .setImage(user.displayAvatarURL({ size: 1024 }));
  await interaction.reply({ embeds: [embed] });
}

// ─────────────────────────────────────────────────────────────
// DASHBOARD ACCESS
// ─────────────────────────────────────────────────────────────

// ─────────────────────────────────────────────────────────────
// MODERACIÓN AVANZADA
// ─────────────────────────────────────────────────────────────

async function handleTimeout(
  interaction: ChatInputCommandInteraction,
): Promise<void> {
  const guildId = interaction.guildId!;
  const target = interaction.options.getUser("usuario", true);
  const minutes = interaction.options.getInteger("duracion", true);
  const reason = interaction.options.getString("razon") ?? "Sin razón especificada";

  const member = await interaction.guild!.members.fetch(target.id).catch(() => null);
  if (!member) {
    await interaction.reply({ content: "No se encontró al miembro en el servidor.", flags: MessageFlags.Ephemeral });
    return;
  }
  if (!member.moderatable) {
    await interaction.reply({ content: "No tengo permisos para silenciar a este usuario (puede tener un rol superior al mío).", flags: MessageFlags.Ephemeral });
    return;
  }

  await member.timeout(minutes * 60 * 1000, reason);

  const embed = new EmbedBuilder()
    .setColor(0xf59e0b)
    .setTitle("🔇 Usuario silenciado")
    .addFields(
      { name: "Usuario", value: `${target.username} (<@${target.id}>)`, inline: true },
      { name: "Duración", value: `${minutes} minuto${minutes !== 1 ? "s" : ""}`, inline: true },
      { name: "Razón", value: reason },
    )
    .setTimestamp();

  await interaction.reply({ embeds: [embed] });

  await logEvent(clientRef!, {
    guildId,
    eventType: "timeout",
    actorId: interaction.user.id,
    actorTag: interaction.user.username,
    targetId: target.id,
    targetTag: target.username,
    summary: `${interaction.user.username} silenció a ${target.username} por ${minutes} min. Razón: ${reason}`,
  });
}

async function handleUntimeout(
  interaction: ChatInputCommandInteraction,
): Promise<void> {
  const guildId = interaction.guildId!;
  const target = interaction.options.getUser("usuario", true);

  const member = await interaction.guild!.members.fetch(target.id).catch(() => null);
  if (!member) {
    await interaction.reply({ content: "No se encontró al miembro en el servidor.", flags: MessageFlags.Ephemeral });
    return;
  }
  if (!member.communicationDisabledUntil) {
    await interaction.reply({ content: `${target.username} no tiene ningún silencio activo.`, flags: MessageFlags.Ephemeral });
    return;
  }

  await member.timeout(null);

  const embed = new EmbedBuilder()
    .setColor(0x22c55e)
    .setTitle("🔊 Silencio eliminado")
    .addFields({ name: "Usuario", value: `${target.username} (<@${target.id}>)` })
    .setTimestamp();

  await interaction.reply({ embeds: [embed] });

  await logEvent(clientRef!, {
    guildId,
    eventType: "untimeout",
    actorId: interaction.user.id,
    actorTag: interaction.user.username,
    targetId: target.id,
    targetTag: target.username,
    summary: `${interaction.user.username} quitó el silencio a ${target.username}.`,
  });
}

async function handleLock(
  interaction: ChatInputCommandInteraction,
): Promise<void> {
  const guildId = interaction.guildId!;
  const targetChannel = interaction.options.getChannel("canal") ?? interaction.channel;

  if (!targetChannel || targetChannel.type !== ChannelType.GuildText) {
    await interaction.reply({ content: "Canal no válido.", flags: MessageFlags.Ephemeral });
    return;
  }

  const ch = targetChannel as TextChannel;
  const everyoneRole = interaction.guild!.roles.everyone;

  await ch.permissionOverwrites.edit(everyoneRole, { SendMessages: false });

  const embed = new EmbedBuilder()
    .setColor(0xef4444)
    .setTitle("🔒 Canal bloqueado")
    .setDescription(`${ch} ha sido bloqueado. Nadie puede escribir hasta que se desbloquee.`)
    .setTimestamp();

  await interaction.reply({ embeds: [embed] });

  await logEvent(clientRef!, {
    guildId,
    eventType: "lock",
    actorId: interaction.user.id,
    actorTag: interaction.user.username,
    channelId: ch.id,
    summary: `${interaction.user.username} bloqueó el canal #${ch.name}.`,
  });
}

async function handleUnlock(
  interaction: ChatInputCommandInteraction,
): Promise<void> {
  const guildId = interaction.guildId!;
  const targetChannel = interaction.options.getChannel("canal") ?? interaction.channel;

  if (!targetChannel || targetChannel.type !== ChannelType.GuildText) {
    await interaction.reply({ content: "Canal no válido.", flags: MessageFlags.Ephemeral });
    return;
  }

  const ch = targetChannel as TextChannel;
  const everyoneRole = interaction.guild!.roles.everyone;

  await ch.permissionOverwrites.edit(everyoneRole, { SendMessages: null });

  const embed = new EmbedBuilder()
    .setColor(0x22c55e)
    .setTitle("🔓 Canal desbloqueado")
    .setDescription(`${ch} ha sido desbloqueado.`)
    .setTimestamp();

  await interaction.reply({ embeds: [embed] });

  await logEvent(clientRef!, {
    guildId,
    eventType: "unlock",
    actorId: interaction.user.id,
    actorTag: interaction.user.username,
    channelId: ch.id,
    summary: `${interaction.user.username} desbloqueó el canal #${ch.name}.`,
  });
}

async function handleSlowmode(
  interaction: ChatInputCommandInteraction,
): Promise<void> {
  const guildId = interaction.guildId!;
  const seconds = interaction.options.getInteger("segundos", true);
  const targetChannel = interaction.options.getChannel("canal") ?? interaction.channel;

  if (!targetChannel || targetChannel.type !== ChannelType.GuildText) {
    await interaction.reply({ content: "Canal no válido.", flags: MessageFlags.Ephemeral });
    return;
  }

  const ch = targetChannel as TextChannel;
  await ch.setRateLimitPerUser(seconds);

  const msg = seconds === 0
    ? `🟢 Modo lento desactivado en ${ch}.`
    : `🐢 Modo lento activado en ${ch}: **${seconds}s** entre mensajes.`;

  const embed = new EmbedBuilder()
    .setColor(seconds === 0 ? 0x22c55e : 0xf59e0b)
    .setDescription(msg)
    .setTimestamp();

  await interaction.reply({ embeds: [embed] });

  await logEvent(clientRef!, {
    guildId,
    eventType: "slowmode",
    actorId: interaction.user.id,
    actorTag: interaction.user.username,
    channelId: ch.id,
    summary: `${interaction.user.username} ${seconds === 0 ? "desactivó" : `activó (${seconds}s)`} el modo lento en #${ch.name}.`,
  });
}

async function handleAcceso(
  interaction: ChatInputCommandInteraction,
): Promise<void> {
  const guildId = interaction.guildId!;
  const sub = interaction.options.getSubcommand();

  if (sub === "add") {
    const target = interaction.options.getUser("usuario", true);
    const tag = target.username;
    const result = await addDashboardAdmin(
      guildId,
      target.id,
      tag,
      interaction.user.id,
    );
    if (!result) {
      await interaction.reply({
        content: `⚠️ **${tag}** ya tiene acceso al dashboard.`,
        flags: MessageFlags.Ephemeral,
      });
      return;
    }
    await interaction.reply({
      content: `✅ Se ha concedido acceso al dashboard a **${tag}** (<@${target.id}>).`,
      flags: MessageFlags.Ephemeral,
    });
    return;
  }

  if (sub === "remove") {
    const target = interaction.options.getUser("usuario", true);
    const removed = await removeDashboardAdmin(guildId, target.id);
    if (!removed) {
      await interaction.reply({
        content: `⚠️ **${target.username}** no tenía acceso al dashboard.`,
        flags: MessageFlags.Ephemeral,
      });
      return;
    }
    await interaction.reply({
      content: `✅ Se ha revocado el acceso al dashboard de **${target.username}**.`,
      flags: MessageFlags.Ephemeral,
    });
    return;
  }

  if (sub === "list") {
    const admins = await listDashboardAdmins(guildId);
    if (admins.length === 0) {
      await interaction.reply({
        content: "No hay usuarios con acceso al dashboard.",
        flags: MessageFlags.Ephemeral,
      });
      return;
    }
    const lines = admins.map(
      (a) => `• **${a.userTag}** (\`${a.userId}\`) — añadido <t:${Math.floor(a.createdAt.getTime() / 1000)}:R>`,
    );
    const embed = new EmbedBuilder()
      .setTitle("👤 Acceso al Dashboard")
      .setColor(BRAND_COLOR)
      .setDescription(lines.join("\n"));
    await interaction.reply({ embeds: [embed], flags: MessageFlags.Ephemeral });
  }
}
