import {
  Events,
  AuditLogEvent,
  ChannelType,
  EmbedBuilder,
  type Client,
  type Guild,
  type GuildAuditLogsEntry,
  type Message,
  type PartialMessage,
  type GuildBan,
  type GuildMember,
  type Role,
  type GuildChannel,
  type DMChannel,
} from "discord.js";
import { logger } from "../lib/logger";
import { getGuildConfig, recordEvent } from "./store";

const EVENT_COLORS: Record<string, number> = {
  member_join: 0x22c55e,
  member_leave: 0xef4444,
  member_ban: 0x991b1b,
  member_unban: 0x16a34a,
  member_kick: 0xef4444,
  message_delete: 0xf97316,
  message_edit: 0xeab308,
  channel_create: 0x3b82f6,
  channel_delete: 0xef4444,
  role_create: 0x3b82f6,
  role_delete: 0xef4444,
  default: 0x9333ea,
};

const EVENT_TITLES: Record<string, string> = {
  member_join: "👋 Miembro entró",
  member_leave: "🚪 Miembro salió",
  member_ban: "🔨 Usuario baneado",
  member_unban: "♻️ Usuario desbaneado",
  member_kick: "👢 Usuario expulsado",
  message_delete: "🗑️ Mensaje borrado",
  message_edit: "✏️ Mensaje editado",
  channel_create: "📁 Canal creado",
  channel_delete: "📁 Canal eliminado",
  role_create: "🏷️ Rol creado",
  role_delete: "🏷️ Rol eliminado",
  blacklist_add: "⛔ Añadido a la blacklist",
  blacklist_remove: "♻️ Quitado de la blacklist",
  blacklist_autokick: "⛔ Blacklist · expulsión automática",
  verification: "✅ Usuario verificado",
  sale: "💎 Nueva venta publicada",
  vouch: "⭐ Reseña dejada",
  ticket_open: "🎫 Ticket abierto",
  ticket_close: "🔒 Ticket cerrado",
  warn: "⚠️ Aviso",
  announcement: "📣 Comunicado publicado",
  setup: "⚙️ Configuración cambiada",
  clear: "🧹 Mensajes borrados",
};

type AlertSettingKey =
  | "memberJoinAlertsEnabled"
  | "memberLeaveAlertsEnabled"
  | "moderationAlertsEnabled"
  | "messageAlertsEnabled"
  | "channelAlertsEnabled"
  | "roleAlertsEnabled"
  | "verificationAlertsEnabled"
  | "announcementAlertsEnabled"
  | "saleAlertsEnabled"
  | "vouchAlertsEnabled"
  | "ticketAlertsEnabled"
  | "setupAlertsEnabled";

const ALERT_SETTING_BY_EVENT: Record<string, AlertSettingKey> = {
  member_join: "memberJoinAlertsEnabled",
  member_leave: "memberLeaveAlertsEnabled",
  member_ban: "moderationAlertsEnabled",
  member_unban: "moderationAlertsEnabled",
  member_kick: "moderationAlertsEnabled",
  member_banned: "moderationAlertsEnabled",
  member_kicked: "moderationAlertsEnabled",
  blacklist_autokick: "moderationAlertsEnabled",
  blacklist_add: "moderationAlertsEnabled",
  blacklist_remove: "moderationAlertsEnabled",
  blacklist_added: "moderationAlertsEnabled",
  blacklist_removed: "moderationAlertsEnabled",
  warn: "moderationAlertsEnabled",
  warn_added: "moderationAlertsEnabled",
  clear: "moderationAlertsEnabled",
  timeout: "moderationAlertsEnabled",
  untimeout: "moderationAlertsEnabled",
  lock: "moderationAlertsEnabled",
  unlock: "moderationAlertsEnabled",
  slowmode: "moderationAlertsEnabled",
  message_delete: "messageAlertsEnabled",
  message_edit: "messageAlertsEnabled",
  message_sent_dashboard: "messageAlertsEnabled",
  channel_create: "channelAlertsEnabled",
  channel_delete: "channelAlertsEnabled",
  role_create: "roleAlertsEnabled",
  role_delete: "roleAlertsEnabled",
  role_update: "roleAlertsEnabled",
  verification: "verificationAlertsEnabled",
  announcement: "announcementAlertsEnabled",
  sale: "saleAlertsEnabled",
  vouch: "vouchAlertsEnabled",
  ticket_open: "ticketAlertsEnabled",
  ticket_close: "ticketAlertsEnabled",
  setup: "setupAlertsEnabled",
};

export interface LogPayload {
  guildId: string;
  eventType: string;
  summary: string;
  actorId?: string | null;
  actorTag?: string | null;
  targetId?: string | null;
  targetTag?: string | null;
  channelId?: string | null;
  metadata?: Record<string, unknown>;
}

/** Persists an event to DB and mirrors it to the configured log channel. */
export async function logEvent(
  client: Client,
  payload: LogPayload,
): Promise<void> {
  try {
    const cfg = await getGuildConfig(payload.guildId);
    if (!cfg.loggingEnabled) return;
    const alertSetting = ALERT_SETTING_BY_EVENT[payload.eventType];
    if (alertSetting && !cfg[alertSetting]) return;

    await recordEvent(payload);
    if (!cfg.logChannelId) return;
    const guild = await client.guilds.fetch(payload.guildId).catch(() => null);
    if (!guild) return;
    const channel = await guild.channels
      .fetch(cfg.logChannelId)
      .catch(() => null);
    if (!channel || channel.type !== ChannelType.GuildText) return;

    const embed = new EmbedBuilder()
      .setTitle(EVENT_TITLES[payload.eventType] ?? `Evento · ${payload.eventType}`)
      .setColor(EVENT_COLORS[payload.eventType] ?? EVENT_COLORS.default!)
      .setDescription(payload.summary)
      .setTimestamp(new Date());

    const fields: { name: string; value: string; inline?: boolean }[] = [];
    if (payload.actorId)
      fields.push({
        name: "Por",
        value: `<@${payload.actorId}>${payload.actorTag ? ` (${payload.actorTag})` : ""}`,
        inline: true,
      });
    if (payload.targetId)
      fields.push({
        name: "Sobre",
        value: `<@${payload.targetId}>${payload.targetTag ? ` (${payload.targetTag})` : ""}`,
        inline: true,
      });
    if (payload.channelId)
      fields.push({
        name: "Canal",
        value: `<#${payload.channelId}>`,
        inline: true,
      });
    if (fields.length > 0) embed.addFields(fields);

    await channel.send({ embeds: [embed], allowedMentions: { parse: [] } });
  } catch (err) {
    logger.error({ err, payload }, "Failed to mirror event to log channel");
  }
}

/** Wires Discord client events to the logger. */
export function attachEventLogger(client: Client): void {
  client.on(Events.GuildMemberAdd, async (member) => {
    await logEvent(client, {
      guildId: member.guild.id,
      eventType: "member_join",
      targetId: member.id,
      targetTag: member.user.username,
      summary: `${member.user.tag} se unió al servidor (cuenta creada <t:${Math.floor(
        member.user.createdTimestamp / 1000,
      )}:R>).`,
      metadata: {
        accountCreatedAt: new Date(member.user.createdTimestamp).toISOString(),
        memberCount: member.guild.memberCount,
      },
    });
  });

  client.on(Events.GuildMemberRemove, async (member) => {
    await logEvent(client, {
      guildId: member.guild.id,
      eventType: "member_leave",
      targetId: member.id,
      targetTag: member.user?.username ?? "desconocido",
      summary: `${member.user?.tag ?? member.id} salió o fue expulsado del servidor.`,
    });
  });

  client.on(Events.GuildBanAdd, async (ban: GuildBan) => {
    const actor = await fetchAuditActor(ban.guild, AuditLogEvent.MemberBanAdd, ban.user.id);
    await logEvent(client, {
      guildId: ban.guild.id,
      eventType: "member_ban",
      targetId: ban.user.id,
      targetTag: ban.user.username,
      actorId: actor?.id,
      actorTag: actor?.tag,
      summary: `${ban.user.tag} fue baneado.${ban.reason ? `\nRazón: ${ban.reason}` : ""}`,
    });
  });

  client.on(Events.GuildBanRemove, async (ban: GuildBan) => {
    await logEvent(client, {
      guildId: ban.guild.id,
      eventType: "member_unban",
      targetId: ban.user.id,
      targetTag: ban.user.username,
      summary: `${ban.user.tag} fue desbaneado.`,
    });
  });

  client.on(Events.MessageDelete, async (message) => {
    if (!message.guildId) return;
    await handleMessageDelete(client, message);
  });

  client.on(Events.MessageUpdate, async (oldMessage, newMessage) => {
    if (!newMessage.guildId) return;
    await handleMessageEdit(client, oldMessage, newMessage);
  });

  client.on(Events.ChannelCreate, async (channel) => {
    if (!isGuildChannel(channel)) return;
    await logEvent(client, {
      guildId: channel.guild.id,
      eventType: "channel_create",
      summary: `Canal creado: **#${channel.name}**`,
      channelId: channel.id,
    });
  });

  client.on(Events.ChannelDelete, async (channel) => {
    if (!isGuildChannel(channel)) return;
    await logEvent(client, {
      guildId: channel.guild.id,
      eventType: "channel_delete",
      summary: `Canal eliminado: **#${channel.name}**`,
    });
  });

  client.on(Events.GuildRoleCreate, async (role: Role) => {
    await logEvent(client, {
      guildId: role.guild.id,
      eventType: "role_create",
      summary: `Rol creado: **${role.name}**`,
    });
  });

  client.on(Events.GuildRoleDelete, async (role: Role) => {
    await logEvent(client, {
      guildId: role.guild.id,
      eventType: "role_delete",
      summary: `Rol eliminado: **${role.name}**`,
    });
  });

  client.on(Events.GuildMemberUpdate, async (oldMember, newMember) => {
    if (oldMember.partial) return;
    const oldRoles = new Set(oldMember.roles.cache.keys());
    const newRoles = new Set(newMember.roles.cache.keys());
    const added = [...newRoles].filter((r) => !oldRoles.has(r));
    const removed = [...oldRoles].filter((r) => !newRoles.has(r));
    if (added.length === 0 && removed.length === 0) return;
    const parts: string[] = [];
    if (added.length > 0)
      parts.push(`**+** ${added.map((r) => `<@&${r}>`).join(" ")}`);
    if (removed.length > 0)
      parts.push(`**−** ${removed.map((r) => `<@&${r}>`).join(" ")}`);
    await logEvent(client, {
      guildId: newMember.guild.id,
      eventType: "role_update",
      targetId: newMember.id,
      targetTag: newMember.user.username,
      summary: `Roles actualizados para ${newMember.user.tag}\n${parts.join("\n")}`,
    });
  });
}

async function handleMessageDelete(
  client: Client,
  message: Message | PartialMessage,
): Promise<void> {
  if (message.author?.bot) return;
  const content = message.content || "_(sin contenido visible)_";
  await logEvent(client, {
    guildId: message.guildId!,
    eventType: "message_delete",
    actorId: message.author?.id ?? null,
    actorTag: message.author?.username ?? null,
    channelId: message.channelId ?? null,
    summary: `Mensaje de ${message.author?.tag ?? "desconocido"} borrado en <#${message.channelId}>:\n>>> ${truncate(content, 800)}`,
  });
}

async function handleMessageEdit(
  client: Client,
  oldMessage: Message | PartialMessage,
  newMessage: Message | PartialMessage,
): Promise<void> {
  if (newMessage.author?.bot) return;
  if ((oldMessage.content ?? "") === (newMessage.content ?? "")) return;
  await logEvent(client, {
    guildId: newMessage.guildId!,
    eventType: "message_edit",
    actorId: newMessage.author?.id ?? null,
    actorTag: newMessage.author?.username ?? null,
    channelId: newMessage.channelId ?? null,
    summary: [
      `Mensaje editado en <#${newMessage.channelId}>:`,
      `**Antes:** ${truncate(oldMessage.content || "_(sin contenido)_", 400)}`,
      `**Después:** ${truncate(newMessage.content || "_(sin contenido)_", 400)}`,
    ].join("\n"),
  });
}

function isGuildChannel(
  channel: GuildChannel | DMChannel | unknown,
): channel is GuildChannel {
  return (
    typeof channel === "object" &&
    channel !== null &&
    "guild" in channel &&
    "name" in channel &&
    !!(channel as GuildChannel).guild
  );
}

function truncate(value: string, max: number): string {
  if (value.length <= max) return value;
  return `${value.slice(0, max)}…`;
}

async function fetchAuditActor(
  guild: Guild,
  type: AuditLogEvent,
  targetId: string,
): Promise<{ id: string; tag: string } | null> {
  try {
    const audit = await guild.fetchAuditLogs({ type, limit: 5 });
    const entry = audit.entries.find(
      (e: GuildAuditLogsEntry) =>
        e.targetId === targetId &&
        Date.now() - e.createdTimestamp < 10_000,
    );
    if (!entry?.executor) return null;
    return { id: entry.executor.id, tag: entry.executor.username ?? entry.executor.id };
  } catch {
    return null;
  }
}
