import { useState } from "react";
import { useGetDashboardVouches } from "@workspace/api-client-react";
import { format } from "date-fns";
import { es } from "date-fns/locale";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { ChevronLeft, ChevronRight, Star } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";

const PAGE_SIZE = 50;

function StarRating({ stars }: { stars: number }) {
  return (
    <div className="flex items-center gap-0.5 text-yellow-500">
      {Array.from({ length: 5 }).map((_, i) => (
        <Star 
          key={i} 
          className={`h-3 w-3 ${i < stars ? "fill-current" : "opacity-20"}`} 
        />
      ))}
    </div>
  );
}

export default function VouchesPage() {
  const [page, setPage] = useState(0);

  const { data: vouches, isLoading, error } = useGetDashboardVouches({
    limit: PAGE_SIZE,
    offset: page * PAGE_SIZE,
  });

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight">Historial de Vouches</h1>
        <p className="text-sm text-muted-foreground mt-1">
          Registro de reputación y calificaciones entre usuarios.
        </p>
      </div>

      {error && (
        <div className="rounded-md border border-destructive/30 bg-destructive/10 px-4 py-3 text-sm text-destructive">
          No se pudieron cargar los vouches.
        </div>
      )}

      <div className="border border-border rounded-md bg-card">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead className="w-[120px]">Fecha</TableHead>
              <TableHead>Vendedor (ID)</TableHead>
              <TableHead>Comprador</TableHead>
              <TableHead>Calificación</TableHead>
              <TableHead className="w-1/3">Comentario</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {isLoading ? (
              Array.from({ length: 5 }).map((_, i) => (
                <TableRow key={i}>
                  <TableCell><Skeleton className="h-4 w-[100px]" /></TableCell>
                  <TableCell><Skeleton className="h-4 w-[160px]" /></TableCell>
                  <TableCell><Skeleton className="h-4 w-[160px]" /></TableCell>
                  <TableCell><Skeleton className="h-4 w-[80px]" /></TableCell>
                  <TableCell><Skeleton className="h-4 w-full" /></TableCell>
                </TableRow>
              ))
            ) : !vouches || vouches.length === 0 ? (
              <TableRow>
                <TableCell colSpan={5} className="h-32 text-center text-muted-foreground">
                  No hay vouches registrados.
                </TableCell>
              </TableRow>
            ) : (
              vouches.map((vouch) => (
                <TableRow key={vouch.id}>
                  <TableCell className="text-sm text-muted-foreground whitespace-nowrap">
                    {format(new Date(vouch.createdAt), "dd MMM yyyy", { locale: es })}
                  </TableCell>
                  <TableCell className="font-mono text-xs text-muted-foreground">
                    {vouch.sellerId}
                  </TableCell>
                  <TableCell>
                    <span className="font-medium">{vouch.buyerTag}</span>
                    <br />
                    <span className="font-mono text-xs text-muted-foreground">{vouch.buyerId}</span>
                  </TableCell>
                  <TableCell>
                    <StarRating stars={vouch.stars} />
                  </TableCell>
                  <TableCell className="text-sm text-muted-foreground">
                    {vouch.comment}
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </div>

      <div className="flex items-center justify-end space-x-2">
        <Button
          variant="outline"
          size="sm"
          onClick={() => setPage(p => Math.max(0, p - 1))}
          disabled={page === 0 || isLoading}
        >
          <ChevronLeft className="h-4 w-4 mr-2" />
          Anterior
        </Button>
        <Button
          variant="outline"
          size="sm"
          onClick={() => setPage(p => p + 1)}
          disabled={!vouches || vouches.length < PAGE_SIZE || isLoading}
        >
          Siguiente
          <ChevronRight className="h-4 w-4 ml-2" />
        </Button>
      </div>
    </div>
  );
}
