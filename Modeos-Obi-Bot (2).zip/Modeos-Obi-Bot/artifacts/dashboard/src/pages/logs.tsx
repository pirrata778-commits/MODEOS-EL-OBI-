import { useState } from "react";
import { useGetDashboardLogs } from "@workspace/api-client-react";
import { format } from "date-fns";
import { es } from "date-fns/locale";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { ChevronLeft, ChevronRight, FileText } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";

const PAGE_SIZE = 50;

export default function LogsPage() {
  const [page, setPage] = useState(0);
  const [eventType, setEventType] = useState<string>("all");

  const { data: logs, isLoading, error } = useGetDashboardLogs({
    limit: PAGE_SIZE,
    offset: page * PAGE_SIZE,
    eventType: eventType === "all" ? undefined : eventType,
  });

  // Extract distinct event types from currently visible data as a fallback,
  // in a real app this would ideally come from a separate endpoint or enum.
  const eventTypes = ["all", "vouch_added", "warn_added", "blacklist_added", "blacklist_removed", "admin_added", "admin_removed"];

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Registros de Auditoría</h1>
          <p className="text-sm text-muted-foreground mt-1">
            Historial de eventos y acciones realizadas en el sistema.
          </p>
        </div>
        <div className="w-[200px]">
          <Select value={eventType} onValueChange={(val) => { setEventType(val); setPage(0); }}>
            <SelectTrigger>
              <SelectValue placeholder="Filtrar por tipo" />
            </SelectTrigger>
            <SelectContent>
              {eventTypes.map(t => (
                <SelectItem key={t} value={t}>
                  {t === "all" ? "Todos los eventos" : t}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>

      {error && (
        <div className="rounded-md border border-destructive/30 bg-destructive/10 px-4 py-3 text-sm text-destructive">
          No se pudieron cargar los registros.
        </div>
      )}

      <div className="border border-border rounded-md bg-card">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead className="w-[180px]">Fecha</TableHead>
              <TableHead>Tipo</TableHead>
              <TableHead>Actor</TableHead>
              <TableHead>Objetivo</TableHead>
              <TableHead>Resumen</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {isLoading ? (
              Array.from({ length: 5 }).map((_, i) => (
                <TableRow key={i}>
                  <TableCell><Skeleton className="h-4 w-[140px]" /></TableCell>
                  <TableCell><Skeleton className="h-4 w-[100px]" /></TableCell>
                  <TableCell><Skeleton className="h-4 w-[120px]" /></TableCell>
                  <TableCell><Skeleton className="h-4 w-[120px]" /></TableCell>
                  <TableCell><Skeleton className="h-4 w-full" /></TableCell>
                </TableRow>
              ))
            ) : !logs || logs.length === 0 ? (
              <TableRow>
                <TableCell colSpan={5} className="h-32 text-center text-muted-foreground">
                  No se encontraron registros.
                </TableCell>
              </TableRow>
            ) : (
              logs.map((log) => (
                <TableRow key={log.id}>
                  <TableCell className="text-sm font-mono text-muted-foreground">
                    {format(new Date(log.createdAt), "dd MMM yyyy, HH:mm", { locale: es })}
                  </TableCell>
                  <TableCell>
                    <Badge variant="secondary" className="font-mono font-normal">
                      {log.eventType}
                    </Badge>
                  </TableCell>
                  <TableCell className="font-medium">
                    {log.actorTag || log.actorId || "-"}
                  </TableCell>
                  <TableCell>
                    {log.targetTag || log.targetId || "-"}
                  </TableCell>
                  <TableCell className="text-muted-foreground truncate max-w-md">
                    {log.summary}
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </div>

      <div className="flex items-center justify-end space-x-2">
        <Button
          variant="outline"
          size="sm"
          onClick={() => setPage(p => Math.max(0, p - 1))}
          disabled={page === 0 || isLoading}
        >
          <ChevronLeft className="h-4 w-4 mr-2" />
          Anterior
        </Button>
        <Button
          variant="outline"
          size="sm"
          onClick={() => setPage(p => p + 1)}
          disabled={!logs || logs.length < PAGE_SIZE || isLoading}
        >
          Siguiente
          <ChevronRight className="h-4 w-4 ml-2" />
        </Button>
      </div>
    </div>
  );
}
