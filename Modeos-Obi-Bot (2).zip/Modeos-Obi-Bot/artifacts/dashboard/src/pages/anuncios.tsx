import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Send, Eye, Megaphone, Loader2, ImageIcon, X } from "lucide-react";

interface Channel {
  id: string;
  name: string;
}

const PRESET_COLORS = [
  { label: "Morado", value: "#9333ea" },
  { label: "Azul", value: "#3b82f6" },
  { label: "Verde", value: "#22c55e" },
  { label: "Rojo", value: "#ef4444" },
  { label: "Amarillo", value: "#eab308" },
  { label: "Naranja", value: "#f97316" },
  { label: "Rosa", value: "#ec4899" },
  { label: "Cian", value: "#06b6d4" },
  { label: "Blanco", value: "#ffffff" },
  { label: "Negro", value: "#111827" },
];

interface FormState {
  title: string;
  description: string;
  color: string;
  channelId: string;
  imageUrl: string;
  thumbnailUrl: string;
  authorName: string;
  authorIconUrl: string;
  footerText: string;
  footerIconUrl: string;
  mentionEveryone: boolean;
}

const EMPTY: FormState = {
  title: "",
  description: "",
  color: "#9333ea",
  channelId: "",
  imageUrl: "",
  thumbnailUrl: "",
  authorName: "",
  authorIconUrl: "",
  footerText: "",
  footerIconUrl: "",
  mentionEveryone: false,
};

// ─── Discord Embed Preview ─────────────────────────────────────────────────────

function DiscordPreview({ form }: { form: FormState }) {
  const hasContent = form.title || form.description || form.imageUrl || form.thumbnailUrl || form.authorName;

  return (
    <div className="rounded-lg bg-[#313338] p-4 min-h-[200px] font-sans">
      {/* @everyone pill */}
      {form.mentionEveryone && (
        <div className="mb-2">
          <span className="bg-[#5865f2]/30 text-[#c9cdfb] text-sm px-1.5 py-0.5 rounded font-medium">@everyone</span>
        </div>
      )}

      {!hasContent ? (
        <p className="text-[#87898c] text-sm italic">Vista previa del embed — rellena los campos de la izquierda</p>
      ) : (
        <div
          className="rounded overflow-hidden"
          style={{ borderLeft: `4px solid ${form.color}`, backgroundColor: "#2b2d31" }}
        >
          <div className="p-4 flex gap-3">
            {/* Main content */}
            <div className="flex-1 min-w-0 space-y-2">
              {/* Author */}
              {form.authorName && (
                <div className="flex items-center gap-2">
                  {form.authorIconUrl && (
                    <img src={form.authorIconUrl} alt="" className="w-5 h-5 rounded-full object-cover" onError={(e) => { (e.target as HTMLImageElement).style.display = "none"; }} />
                  )}
                  <span className="text-white text-xs font-semibold">{form.authorName}</span>
                </div>
              )}

              {/* Title */}
              {form.title && (
                <p className="text-white font-semibold text-base leading-snug break-words">
                  {form.title}
                </p>
              )}

              {/* Description */}
              {form.description && (
                <p className="text-[#dbdee1] text-sm leading-relaxed break-words whitespace-pre-wrap">
                  {form.description}
                </p>
              )}

              {/* Image */}
              {form.imageUrl && (
                <div className="mt-3">
                  <img
                    src={form.imageUrl}
                    alt="embed image"
                    className="rounded max-h-72 max-w-full object-contain"
                    onError={(e) => { (e.target as HTMLImageElement).style.display = "none"; }}
                  />
                </div>
              )}

              {/* Footer */}
              {form.footerText && (
                <div className="flex items-center gap-1.5 mt-2">
                  {form.footerIconUrl && (
                    <img src={form.footerIconUrl} alt="" className="w-4 h-4 rounded-full object-cover" onError={(e) => { (e.target as HTMLImageElement).style.display = "none"; }} />
                  )}
                  <span className="text-[#87898c] text-xs">{form.footerText}</span>
                  <span className="text-[#87898c] text-xs">•</span>
                  <span className="text-[#87898c] text-xs">{new Date().toLocaleDateString("es-ES")}</span>
                </div>
              )}
            </div>

            {/* Thumbnail */}
            {form.thumbnailUrl && (
              <div className="shrink-0">
                <img
                  src={form.thumbnailUrl}
                  alt="thumbnail"
                  className="w-20 h-20 rounded object-cover"
                  onError={(e) => { (e.target as HTMLImageElement).style.display = "none"; }}
                />
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}

// ─── Field row helper ──────────────────────────────────────────────────────────

function Field({ label, children, hint }: { label: string; children: React.ReactNode; hint?: string }) {
  return (
    <div className="space-y-1.5">
      <Label className="text-sm">{label}</Label>
      {children}
      {hint && <p className="text-xs text-muted-foreground">{hint}</p>}
    </div>
  );
}

// ─── Main Page ─────────────────────────────────────────────────────────────────

export default function AnunciosPage() {
  const [form, setForm] = useState<FormState>(EMPTY);
  const [channels, setChannels] = useState<Channel[]>([]);
  const [loading, setLoading] = useState(false);
  const [sent, setSent] = useState<{ ok: boolean; message: string } | null>(null);

  const set = (key: keyof FormState, value: string | boolean) =>
    setForm((prev) => ({ ...prev, [key]: value }));

  useEffect(() => {
    fetch("/api/dashboard/terminal/guilds", { credentials: "include" })
      .then(async (r) => {
        if (!r.ok) throw new Error("No se pudieron cargar los canales.");
        return (await r.json()) as { channels?: Channel[] };
      })
      .then((data) => setChannels(data.channels ?? []))
      .catch(() => {});
  }, []);

  const handleSend = async () => {
    if (!form.channelId) { setSent({ ok: false, message: "Selecciona un canal." }); return; }
    if (!form.title && !form.description) { setSent({ ok: false, message: "El anuncio necesita al menos título o descripción." }); return; }

    setLoading(true);
    setSent(null);
    try {
      const res = await fetch("/api/dashboard/announcements", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
        body: JSON.stringify(form),
      });
      const data = (await res.json()) as { ok: boolean; message: string };
      setSent(data);
      if (data.ok) {
        setForm((prev) => ({ ...EMPTY, channelId: prev.channelId, color: prev.color }));
      }
    } catch {
      setSent({ ok: false, message: "Error de conexión con el servidor." });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight">Anuncios</h1>
        <p className="text-sm text-muted-foreground mt-1">
          Crea y publica comunicados con imágenes, colores y formato completo.
        </p>
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
        {/* ── Form ─────────────────────────────────────── */}
        <div className="space-y-4">
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="flex items-center gap-2 text-base">
                <Megaphone className="w-4 h-4 text-primary" />
                Configuración del anuncio
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {/* Channel + mention */}
              <div className="grid grid-cols-2 gap-3 items-end">
                <Field label="Canal de destino">
                  <Select value={form.channelId} onValueChange={(v) => set("channelId", v)}>
                    <SelectTrigger><SelectValue placeholder="Selecciona un canal" /></SelectTrigger>
                    <SelectContent>
                      {channels.map((c) => (
                        <SelectItem key={c.id} value={c.id}>#{c.name}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </Field>
                <div className="flex items-center gap-2 pb-1">
                  <Switch
                    id="mention"
                    checked={form.mentionEveryone}
                    onCheckedChange={(v) => set("mentionEveryone", v)}
                  />
                  <Label htmlFor="mention" className="cursor-pointer text-sm">@everyone</Label>
                </div>
              </div>

              <Separator />

              {/* Author */}
              <div className="grid grid-cols-2 gap-3">
                <Field label="Autor (nombre)" hint="Aparece encima del título">
                  <Input placeholder="MODEOS EL OBI" value={form.authorName} onChange={(e) => set("authorName", e.target.value)} />
                </Field>
                <Field label="Autor (icono URL)" hint="URL de imagen pequeña">
                  <Input placeholder="https://..." value={form.authorIconUrl} onChange={(e) => set("authorIconUrl", e.target.value)} />
                </Field>
              </div>

              {/* Title */}
              <Field label="Título">
                <Input placeholder="Título del comunicado" value={form.title} onChange={(e) => set("title", e.target.value)} />
              </Field>

              {/* Description */}
              <Field label="Descripción" hint="Soporta formato Markdown de Discord (**negrita**, *cursiva*, `código`)">
                <Textarea
                  placeholder="Escribe el contenido del comunicado aquí..."
                  value={form.description}
                  onChange={(e) => set("description", e.target.value)}
                  rows={5}
                  className="resize-none"
                />
              </Field>

              {/* Color */}
              <Field label="Color de la barra lateral">
                <div className="space-y-2">
                  <div className="flex flex-wrap gap-1.5">
                    {PRESET_COLORS.map((c) => (
                      <button
                        key={c.value}
                        title={c.label}
                        onClick={() => set("color", c.value)}
                        className="w-6 h-6 rounded-full border-2 transition-transform hover:scale-110"
                        style={{
                          backgroundColor: c.value,
                          borderColor: form.color === c.value ? "white" : "transparent",
                        }}
                      />
                    ))}
                  </div>
                  <div className="flex items-center gap-2">
                    <input
                      type="color"
                      value={form.color}
                      onChange={(e) => set("color", e.target.value)}
                      className="w-8 h-8 rounded cursor-pointer border border-border bg-transparent"
                    />
                    <Input
                      value={form.color}
                      onChange={(e) => set("color", e.target.value)}
                      placeholder="#9333ea"
                      className="font-mono text-sm w-32"
                      maxLength={7}
                    />
                  </div>
                </div>
              </Field>

              <Separator />

              {/* Images */}
              <div className="space-y-3">
                <p className="text-xs font-semibold uppercase tracking-wider text-muted-foreground flex items-center gap-1.5">
                  <ImageIcon className="w-3.5 h-3.5" /> Imágenes
                </p>
                <Field label="Imagen grande (URL)" hint="Aparece debajo de la descripción">
                  <Input placeholder="https://i.imgur.com/..." value={form.imageUrl} onChange={(e) => set("imageUrl", e.target.value)} />
                </Field>
                <Field label="Miniatura (URL)" hint="Imagen pequeña arriba a la derecha">
                  <Input placeholder="https://i.imgur.com/..." value={form.thumbnailUrl} onChange={(e) => set("thumbnailUrl", e.target.value)} />
                </Field>
              </div>

              <Separator />

              {/* Footer */}
              <div className="grid grid-cols-2 gap-3">
                <Field label="Pie de página">
                  <Input placeholder="Comunicado oficial" value={form.footerText} onChange={(e) => set("footerText", e.target.value)} />
                </Field>
                <Field label="Icono del pie (URL)">
                  <Input placeholder="https://..." value={form.footerIconUrl} onChange={(e) => set("footerIconUrl", e.target.value)} />
                </Field>
              </div>
            </CardContent>
          </Card>

          {/* Send button + result */}
          <div className="space-y-2">
            {sent && (
              <div className={`flex items-start gap-2 rounded-md border px-3 py-2 text-sm ${sent.ok ? "border-green-500/30 bg-green-500/10 text-green-400" : "border-red-500/30 bg-red-500/10 text-red-400"}`}>
                <span className="flex-1">{sent.message}</span>
                <button onClick={() => setSent(null)}><X className="w-3.5 h-3.5 shrink-0 mt-0.5" /></button>
              </div>
            )}
            <Button className="w-full gap-2" onClick={handleSend} disabled={loading}>
              {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}
              {loading ? "Enviando..." : "Publicar comunicado"}
            </Button>
            <Button variant="outline" className="w-full" onClick={() => { setForm(EMPTY); setSent(null); }}>
              Limpiar formulario
            </Button>
          </div>
        </div>

        {/* ── Preview ───────────────────────────────────── */}
        <div className="space-y-3">
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="flex items-center gap-2 text-base">
                <Eye className="w-4 h-4 text-primary" />
                Vista previa
                <Badge variant="secondary" className="text-xs ml-auto">En tiempo real</Badge>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <DiscordPreview form={form} />
            </CardContent>
          </Card>

          {/* Tips */}
          <Card className="border-dashed">
            <CardContent className="pt-4 space-y-2 text-xs text-muted-foreground">
              <p className="font-semibold text-foreground text-sm">Consejos de formato</p>
              <div className="grid grid-cols-2 gap-x-4 gap-y-1">
                <span><code className="bg-muted px-1 rounded">**texto**</code> → <strong>negrita</strong></span>
                <span><code className="bg-muted px-1 rounded">*texto*</code> → <em>cursiva</em></span>
                <span><code className="bg-muted px-1 rounded">__texto__</code> → subrayado</span>
                <span><code className="bg-muted px-1 rounded">~~texto~~</code> → tachado</span>
                <span><code className="bg-muted px-1 rounded">`código`</code> → código inline</span>
                <span><code className="bg-muted px-1 rounded">\n</code> → salto de línea</span>
                <span><code className="bg-muted px-1 rounded">&gt; texto</code> → cita</span>
                <span><code className="bg-muted px-1 rounded">{"```código```"}</code> → bloque</span>
              </div>
              <Separator />
              <p>Las imágenes deben ser URLs públicas directas (Imgur, CDN, etc.)</p>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
