import { useState, useEffect, useRef, useCallback } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Terminal, Send, ChevronRight, SquareTerminal } from "lucide-react";

// ─── Types ────────────────────────────────────────────────────────────────────

interface ActionLog {
  id: number;
  timestamp: string;
  action: string;
  ok: boolean;
  message: string;
}

interface ChannelInfo {
  id: string;
  name: string;
}

interface GuildInfo {
  guildName: string;
  channels: ChannelInfo[];
}

type TerminalLine =
  | { type: "input"; text: string }
  | { type: "output"; ok: boolean; text: string }
  | { type: "info"; text: string }
  | { type: "blank" };

// ─── Constants ────────────────────────────────────────────────────────────────

const ACTIONS = [
  { value: "ban", label: "Banear usuario" },
  { value: "kick", label: "Expulsar usuario" },
  { value: "warn", label: "Advertir usuario" },
  { value: "blacklist_add", label: "Añadir a lista negra" },
  { value: "blacklist_remove", label: "Quitar de lista negra" },
  { value: "send_message", label: "Enviar mensaje a canal" },
  { value: "clear_messages", label: "Borrar mensajes de canal" },
];

const DESTRUCTIVE_ACTIONS = new Set([
  "ban",
  "kick",
  "blacklist_add",
  "blacklist_remove",
  "clear_messages",
]);

const ACTION_FIELDS: Record<string, { key: string; label: string; placeholder: string; type?: string }[]> = {
  ban: [
    { key: "userId", label: "ID del usuario", placeholder: "760963006485102594" },
    { key: "reason", label: "Motivo", placeholder: "Comportamiento inapropiado" },
  ],
  kick: [
    { key: "userId", label: "ID del usuario", placeholder: "760963006485102594" },
    { key: "reason", label: "Motivo", placeholder: "Incumplimiento de normas" },
  ],
  warn: [
    { key: "userId", label: "ID del usuario", placeholder: "760963006485102594" },
    { key: "userTag", label: "Tag del usuario", placeholder: "usuario#0001" },
    { key: "reason", label: "Motivo", placeholder: "Primera advertencia" },
  ],
  blacklist_add: [
    { key: "userId", label: "ID del usuario", placeholder: "760963006485102594" },
    { key: "userTag", label: "Tag del usuario", placeholder: "usuario#0001" },
    { key: "reason", label: "Motivo", placeholder: "Estafa confirmada" },
  ],
  blacklist_remove: [
    { key: "userId", label: "ID del usuario", placeholder: "760963006485102594" },
  ],
  send_message: [
    { key: "channelId", label: "ID del canal", placeholder: "Selecciona o escribe el ID" },
    { key: "message", label: "Mensaje", placeholder: "Escribe el mensaje aquí...", type: "textarea" },
  ],
  clear_messages: [
    { key: "channelId", label: "ID del canal", placeholder: "Selecciona o escribe el ID" },
    { key: "amount", label: "Cantidad de mensajes (máx. 100)", placeholder: "10" },
  ],
};

const HELP_TEXT = [
  "Comandos de moderación:",
  "  ban <userId> [motivo]",
  "  kick <userId> [motivo]",
  "  warn <userId> <userTag> <motivo>",
  "  blacklist add <userId> [userTag] <motivo>",
  "  blacklist remove <userId>",
  "  send <channelId> <mensaje...>",
  "  clear <channelId> <cantidad>",
  "",
  "Comandos de información:",
  "  plantilla            — estructura del servidor (canales, roles, IDs)",
  "  nuevas [dias]        — cuentas creadas hace menos de N días (def: 30)",
  "  admins               — ID y @ de todos los administradores",
  "  canales              — lista canales con sus IDs",
  "",
  "Utilidades:",
  "  help                 — muestra esta ayuda",
  "  clear-log            — limpia el historial",
  "",
  "Nota: argumentos con espacios van entre comillas",
  'Ejemplo: ban 123456789 "Estafa confirmada"',
];

// ─── CLI Parser ───────────────────────────────────────────────────────────────

function parseArgs(input: string): string[] {
  const args: string[] = [];
  let current = "";
  let inQuotes = false;
  let quoteChar = "";

  for (let i = 0; i < input.length; i++) {
    const ch = input[i]!;
    if (inQuotes) {
      if (ch === quoteChar) {
        inQuotes = false;
      } else {
        current += ch;
      }
    } else if (ch === '"' || ch === "'") {
      inQuotes = true;
      quoteChar = ch;
    } else if (ch === " ") {
      if (current.length > 0) {
        args.push(current);
        current = "";
      }
    } else {
      current += ch;
    }
  }
  if (current.length > 0) args.push(current);
  return args;
}

async function executeTerminalCommand(
  raw: string,
): Promise<{ ok: boolean; message: string; lines?: string[]; action?: string }> {
  const args = parseArgs(raw.trim());
  if (!args.length) return { ok: true, message: "" };

  const cmd = args[0]!.toLowerCase();

  let action: string;
  let params: Record<string, string> = {};

  switch (cmd) {
    case "ban":
      if (!args[1]) return { ok: false, message: "Uso: ban <userId> [motivo]" };
      action = "ban";
      params = { userId: args[1], reason: args.slice(2).join(" ") || "Sin motivo" };
      break;

    case "kick":
      if (!args[1]) return { ok: false, message: "Uso: kick <userId> [motivo]" };
      action = "kick";
      params = { userId: args[1], reason: args.slice(2).join(" ") || "Sin motivo" };
      break;

    case "warn":
      if (!args[1] || !args[2]) return { ok: false, message: "Uso: warn <userId> <userTag> <motivo>" };
      action = "warn";
      params = { userId: args[1], userTag: args[2], reason: args.slice(3).join(" ") };
      if (!params.reason) return { ok: false, message: "Uso: warn <userId> <userTag> <motivo>" };
      break;

    case "blacklist":
      if (args[1] === "add") {
        if (!args[2]) return { ok: false, message: "Uso: blacklist add <userId> [userTag] <motivo>" };
        action = "blacklist_add";
        params = { userId: args[2], userTag: args[3] ?? args[2], reason: args.slice(4).join(" ") || args.slice(3).join(" ") };
        if (!params.reason) return { ok: false, message: "Uso: blacklist add <userId> [userTag] <motivo>" };
      } else if (args[1] === "remove") {
        if (!args[2]) return { ok: false, message: "Uso: blacklist remove <userId>" };
        action = "blacklist_remove";
        params = { userId: args[2] };
      } else {
        return { ok: false, message: "Uso: blacklist add|remove ..." };
      }
      break;

    case "send":
      if (!args[1] || !args[2]) return { ok: false, message: "Uso: send <channelId> <mensaje...>" };
      action = "send_message";
      params = { channelId: args[1], message: args.slice(2).join(" ") };
      break;

    case "clear":
      if (!args[1] || !args[2]) return { ok: false, message: "Uso: clear <channelId> <cantidad>" };
      action = "clear_messages";
      params = { channelId: args[1], amount: args[2] };
      break;

    case "plantilla":
      action = "server_info";
      params = {};
      break;

    case "nuevas":
      action = "scan_new";
      params = { dias: args[1] ?? "30" };
      break;

    case "admins":
      action = "list_admins";
      params = {};
      break;

    default:
      return { ok: false, message: `Comando desconocido: "${cmd}". Escribe "help" para ver los comandos.` };
  }

  const res = await fetch("/api/dashboard/terminal", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    credentials: "include",
    body: JSON.stringify({ action, params }),
  });

  const data = (await res.json()) as { ok: boolean; message: string; lines?: string[] };
  return { ...data, action };
}

// ─── Written Terminal Component ────────────────────────────────────────────────

function WrittenTerminal({ guildInfo }: { guildInfo: GuildInfo | null }) {
  const [lines, setLines] = useState<TerminalLine[]>([
    { type: "info", text: "Terminal MODEOS EL OBI — escribe \"help\" para ver los comandos disponibles." },
    { type: "blank" },
  ]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const [history, setHistory] = useState<string[]>([]);
  const [historyIdx, setHistoryIdx] = useState(-1);
  const [draftInput, setDraftInput] = useState("");
  const inputRef = useRef<HTMLInputElement>(null);
  const bottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [lines]);

  const pushLines = useCallback((...newLines: TerminalLine[]) => {
    setLines((prev) => [...prev, ...newLines]);
  }, []);

  const handleSubmit = async () => {
    const raw = input.trim();
    if (!raw) return;

    pushLines({ type: "input", text: raw });
    setInput("");
    setHistoryIdx(-1);
    setDraftInput("");
    setHistory((h) => [raw, ...h.slice(0, 49)]);

    const cmd = raw.split(/\s+/)[0]?.toLowerCase();

    if (cmd === "help") {
      pushLines(...HELP_TEXT.map((t) => ({ type: "info" as const, text: t })), { type: "blank" });
      return;
    }
    if (cmd === "clear-log") {
      setLines([{ type: "info", text: 'Terminal limpiada. Escribe "help" para ayuda.' }, { type: "blank" }]);
      return;
    }
    if (cmd === "canales" || cmd === "channels") {
      if (!guildInfo) {
        pushLines({ type: "output", ok: false, text: "No se pudo obtener la lista de canales." }, { type: "blank" });
      } else {
        pushLines(
          { type: "info", text: `Canales de ${guildInfo.guildName}:` },
          ...guildInfo.channels.map((c) => ({ type: "info" as const, text: `  #${c.name}  (${c.id})` })),
          { type: "blank" },
        );
      }
      return;
    }

    setLoading(true);
    try {
      const result = await executeTerminalCommand(raw);
      if (result.lines && result.lines.length > 0) {
        pushLines(
          ...result.lines.map((t) => ({ type: "info" as const, text: t })),
          { type: "blank" },
        );
      } else if (result.message) {
        pushLines({ type: "output", ok: result.ok, text: result.message }, { type: "blank" });
      } else {
        pushLines({ type: "blank" });
      }
    } catch {
      pushLines({ type: "output", ok: false, text: "Error de conexión con el servidor." }, { type: "blank" });
    } finally {
      setLoading(false);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === "Enter") {
      handleSubmit();
      return;
    }
    if (e.key === "ArrowUp") {
      e.preventDefault();
      if (history.length === 0) return;
      const newIdx = Math.min(historyIdx + 1, history.length - 1);
      if (historyIdx === -1) setDraftInput(input);
      setHistoryIdx(newIdx);
      setInput(history[newIdx] ?? "");
      return;
    }
    if (e.key === "ArrowDown") {
      e.preventDefault();
      if (historyIdx <= 0) {
        setHistoryIdx(-1);
        setInput(draftInput);
        return;
      }
      const newIdx = historyIdx - 1;
      setHistoryIdx(newIdx);
      setInput(history[newIdx] ?? "");
      return;
    }
  };

  return (
    <div
      className="rounded-lg border border-border bg-black font-mono text-sm flex flex-col"
      style={{ height: "520px" }}
      onClick={() => inputRef.current?.focus()}
    >
      {/* Output area */}
      <div className="flex-1 overflow-y-auto p-4 space-y-0.5 select-text">
        {lines.map((line, i) => {
          if (line.type === "blank") return <div key={i} className="h-2" />;
          if (line.type === "input") {
            return (
              <div key={i} className="flex items-start gap-2">
                <span className="text-purple-400 shrink-0 select-none">$</span>
                <span className="text-white break-all">{line.text}</span>
              </div>
            );
          }
          if (line.type === "output") {
            return (
              <div key={i} className={`pl-4 break-all ${line.ok ? "text-green-400" : "text-red-400"}`}>
                {line.text}
              </div>
            );
          }
          // info
          return (
            <div key={i} className="pl-4 text-zinc-400 break-all whitespace-pre">
              {line.text}
            </div>
          );
        })}
        <div ref={bottomRef} />
      </div>

      {/* Input row */}
      <div className="border-t border-zinc-800 px-4 py-2 flex items-center gap-2 shrink-0">
        <span className="text-purple-400 select-none">$</span>
        <input
          ref={inputRef}
          className="flex-1 bg-transparent text-white outline-none placeholder:text-zinc-600 caret-purple-400"
          placeholder={loading ? "ejecutando…" : "escribe un comando…"}
          value={input}
          disabled={loading}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={handleKeyDown}
          autoFocus
          autoComplete="off"
          spellCheck={false}
        />
        {loading && <span className="text-zinc-500 text-xs animate-pulse">●</span>}
      </div>
    </div>
  );
}

// ─── Form Terminal Component ───────────────────────────────────────────────────

function FormTerminal({ guildInfo }: { guildInfo: GuildInfo | null }) {
  const [action, setAction] = useState("ban");
  const [params, setParams] = useState<Record<string, string>>({});
  const [logs, setLogs] = useState<ActionLog[]>([]);
  const [loading, setLoading] = useState(false);
  const logIdRef = useRef(0);
  const scrollRef = useRef<HTMLDivElement>(null);

  const isChannelAction = action === "send_message" || action === "clear_messages";
  const fields = ACTION_FIELDS[action] ?? [];

  useEffect(() => { setParams({}); }, [action]);
  useEffect(() => {
    if (scrollRef.current) scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
  }, [logs]);

  const handleExecute = async () => {
    if (
      DESTRUCTIVE_ACTIONS.has(action) &&
      !window.confirm("Esta acción puede afectar a usuarios o mensajes. ¿Quieres continuar?")
    ) {
      return;
    }
    setLoading(true);
    const timestamp = new Date().toLocaleTimeString("es-ES");
    const actionLabel = ACTIONS.find((a) => a.value === action)?.label ?? action;
    try {
      const res = await fetch("/api/dashboard/terminal", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
        body: JSON.stringify({ action, params }),
      });
      const data = (await res.json()) as { ok: boolean; message: string };
      setLogs((prev) => [...prev, { id: ++logIdRef.current, timestamp, action: actionLabel, ok: data.ok, message: data.message }]);
    } catch {
      setLogs((prev) => [...prev, { id: ++logIdRef.current, timestamp, action: actionLabel, ok: false, message: "Error de conexión." }]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center gap-2 text-base">
            <Terminal className="w-4 h-4 text-primary" />
            Constructor de acción
          </CardTitle>
          {guildInfo && (
            <CardDescription>Servidor: <span className="text-foreground font-medium">{guildInfo.guildName}</span></CardDescription>
          )}
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-1.5">
            <Label>Acción</Label>
            <Select value={action} onValueChange={setAction}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                {ACTIONS.map((a) => (
                  <SelectItem key={a.value} value={a.value}>{a.label}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          {fields.map((field) => (
            <div key={field.key} className="space-y-1.5">
              <Label>{field.label}</Label>
              {field.type === "textarea" ? (
                <Textarea
                  placeholder={field.placeholder}
                  value={params[field.key] ?? ""}
                  onChange={(e) => setParams((p) => ({ ...p, [field.key]: e.target.value }))}
                  rows={3}
                />
              ) : isChannelAction && field.key === "channelId" && guildInfo?.channels.length ? (
                <div className="space-y-2">
                  <Select value={params[field.key] ?? ""} onValueChange={(v) => setParams((p) => ({ ...p, [field.key]: v }))}>
                    <SelectTrigger><SelectValue placeholder="Selecciona un canal" /></SelectTrigger>
                    <SelectContent>
                      {guildInfo.channels.map((c) => (
                        <SelectItem key={c.id} value={c.id}>#{c.name}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <Input
                    placeholder="O escribe el ID manualmente"
                    value={params[field.key] ?? ""}
                    onChange={(e) => setParams((p) => ({ ...p, [field.key]: e.target.value }))}
                  />
                </div>
              ) : (
                <Input
                  placeholder={field.placeholder}
                  value={params[field.key] ?? ""}
                  onChange={(e) => setParams((p) => ({ ...p, [field.key]: e.target.value }))}
                />
              )}
            </div>
          ))}
          <Button className="w-full gap-2 mt-2" onClick={handleExecute} disabled={loading}>
            <Send className="w-4 h-4" />
            {loading ? "Ejecutando..." : "Ejecutar"}
          </Button>
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center gap-2 text-base">
            <ChevronRight className="w-4 h-4 text-primary" />
            Historial
          </CardTitle>
          <CardDescription>
            {logs.length === 0 ? "Sin ejecuciones aún" : `${logs.length} acción${logs.length !== 1 ? "es" : ""}`}
          </CardDescription>
        </CardHeader>
        <CardContent className="p-0">
          <ScrollArea className="h-[400px]" ref={scrollRef}>
            {logs.length === 0 ? (
              <div className="flex items-center justify-center h-full text-muted-foreground text-sm p-6">
                Las ejecuciones aparecerán aquí.
              </div>
            ) : (
              <div>
                {logs.map((log, i) => (
                  <div key={log.id}>
                    <div className="px-4 py-3 space-y-1">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <Badge variant={log.ok ? "default" : "destructive"} className="text-xs font-mono">
                            {log.ok ? "OK" : "ERROR"}
                          </Badge>
                          <span className="text-xs font-medium">{log.action}</span>
                        </div>
                        <span className="text-xs text-muted-foreground font-mono">{log.timestamp}</span>
                      </div>
                      <p className="text-sm text-muted-foreground">{log.message}</p>
                    </div>
                    {i < logs.length - 1 && <Separator />}
                  </div>
                ))}
              </div>
            )}
          </ScrollArea>
        </CardContent>
      </Card>
    </div>
  );
}

// ─── Main Page ─────────────────────────────────────────────────────────────────

export default function TerminalPage() {
  const [guildInfo, setGuildInfo] = useState<GuildInfo | null>(null);

  useEffect(() => {
    fetch("/api/dashboard/terminal/guilds", { credentials: "include" })
      .then((r) => r.json())
      .then((data: GuildInfo) => setGuildInfo(data))
      .catch(() => {});
  }, []);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight">Terminal Remota</h1>
        <p className="text-sm text-muted-foreground mt-1">
          Ejecuta acciones del bot directamente desde el panel, sin necesidad de permisos en Discord.
        </p>
      </div>

      <Tabs defaultValue="cli">
        <TabsList className="mb-4">
          <TabsTrigger value="cli" className="gap-2">
            <SquareTerminal className="w-4 h-4" />
            Terminal escrita
          </TabsTrigger>
          <TabsTrigger value="form" className="gap-2">
            <Terminal className="w-4 h-4" />
            Formulario
          </TabsTrigger>
        </TabsList>

        <TabsContent value="cli">
          <div className="space-y-3">
            {guildInfo && (
              <p className="text-xs text-muted-foreground font-mono">
                Servidor: <span className="text-foreground">{guildInfo.guildName}</span>
                {" · "}escribe <span className="text-purple-400">canales</span> para ver IDs de canales
              </p>
            )}
            <WrittenTerminal guildInfo={guildInfo} />
          </div>
        </TabsContent>

        <TabsContent value="form">
          <FormTerminal guildInfo={guildInfo} />
        </TabsContent>
      </Tabs>
    </div>
  );
}
