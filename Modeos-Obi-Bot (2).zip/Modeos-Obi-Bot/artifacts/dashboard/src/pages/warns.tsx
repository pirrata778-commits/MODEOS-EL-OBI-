import { useState } from "react";
import { useGetDashboardWarns } from "@workspace/api-client-react";
import { format } from "date-fns";
import { es } from "date-fns/locale";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";

const PAGE_SIZE = 50;

export default function WarnsPage() {
  const [page, setPage] = useState(0);

  const { data: warns, isLoading, error } = useGetDashboardWarns({
    limit: PAGE_SIZE,
    offset: page * PAGE_SIZE,
  });

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight">Advertencias</h1>
        <p className="text-sm text-muted-foreground mt-1">
          Historial de infracciones y advertencias emitidas.
        </p>
      </div>

      {error && (
        <div className="rounded-md border border-destructive/30 bg-destructive/10 px-4 py-3 text-sm text-destructive">
          No se pudieron cargar las advertencias.
        </div>
      )}

      <div className="border border-border rounded-md bg-card">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead className="w-[120px]">Fecha</TableHead>
              <TableHead>Usuario</TableHead>
              <TableHead>ID de Usuario</TableHead>
              <TableHead>Moderador (ID)</TableHead>
              <TableHead className="w-1/3">Motivo</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {isLoading ? (
              Array.from({ length: 5 }).map((_, i) => (
                <TableRow key={i}>
                  <TableCell><Skeleton className="h-4 w-[100px]" /></TableCell>
                  <TableCell><Skeleton className="h-4 w-[120px]" /></TableCell>
                  <TableCell><Skeleton className="h-4 w-[140px]" /></TableCell>
                  <TableCell><Skeleton className="h-4 w-[140px]" /></TableCell>
                  <TableCell><Skeleton className="h-4 w-full" /></TableCell>
                </TableRow>
              ))
            ) : !warns || warns.length === 0 ? (
              <TableRow>
                <TableCell colSpan={5} className="h-32 text-center text-muted-foreground">
                  No hay advertencias registradas.
                </TableCell>
              </TableRow>
            ) : (
              warns.map((warn) => (
                <TableRow key={warn.id}>
                  <TableCell className="text-sm text-muted-foreground whitespace-nowrap">
                    {format(new Date(warn.createdAt), "dd MMM yyyy", { locale: es })}
                  </TableCell>
                  <TableCell className="font-medium text-destructive">
                    {warn.userTag}
                  </TableCell>
                  <TableCell className="font-mono text-xs text-muted-foreground">
                    {warn.userId}
                  </TableCell>
                  <TableCell className="font-mono text-xs text-muted-foreground">
                    {warn.moderatorId}
                  </TableCell>
                  <TableCell className="text-sm text-muted-foreground">
                    {warn.reason}
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </div>

      <div className="flex items-center justify-end space-x-2">
        <Button
          variant="outline"
          size="sm"
          onClick={() => setPage(p => Math.max(0, p - 1))}
          disabled={page === 0 || isLoading}
        >
          <ChevronLeft className="h-4 w-4 mr-2" />
          Anterior
        </Button>
        <Button
          variant="outline"
          size="sm"
          onClick={() => setPage(p => p + 1)}
          disabled={!warns || warns.length < PAGE_SIZE || isLoading}
        >
          Siguiente
          <ChevronRight className="h-4 w-4 ml-2" />
        </Button>
      </div>
    </div>
  );
}
