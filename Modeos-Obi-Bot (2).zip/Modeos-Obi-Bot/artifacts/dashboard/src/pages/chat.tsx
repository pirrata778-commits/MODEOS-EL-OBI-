import { useState, useEffect, useRef, useCallback } from "react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { ScrollArea } from "@/components/ui/scroll-area";
import { useToast } from "@/hooks/use-toast";
import {
  Bot,
  User,
  Send,
  Plus,
  Trash2,
  Loader2,
  MessageSquare,
} from "lucide-react";

interface Conversation {
  id: number;
  title: string;
  createdAt: string;
}

interface Message {
  id: number;
  conversationId: number;
  role: "user" | "assistant";
  content: string;
  createdAt: string;
}

function MessageBubble({ msg }: { msg: Message | { role: "assistant"; content: string; streaming: true } }) {
  const isUser = msg.role === "user";
  return (
    <div className={`flex gap-3 ${isUser ? "justify-end" : "justify-start"}`}>
      {!isUser && (
        <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center shrink-0 mt-1">
          <Bot className="w-4 h-4 text-primary" />
        </div>
      )}
      <div
        className={`max-w-[80%] rounded-2xl px-4 py-3 text-sm whitespace-pre-wrap leading-relaxed ${
          isUser
            ? "bg-primary text-primary-foreground rounded-br-sm"
            : "bg-muted text-foreground rounded-bl-sm"
        }`}
      >
        {msg.content}
        {"streaming" in msg && msg.streaming && (
          <span className="inline-block w-2 h-4 bg-current opacity-70 animate-pulse ml-0.5 rounded-sm" />
        )}
      </div>
      {isUser && (
        <div className="w-8 h-8 rounded-full bg-primary flex items-center justify-center shrink-0 mt-1">
          <User className="w-4 h-4 text-primary-foreground" />
        </div>
      )}
    </div>
  );
}

export default function ChatPage() {
  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [activeId, setActiveId] = useState<number | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState("");
  const [sending, setSending] = useState(false);
  const [streamingContent, setStreamingContent] = useState<string | null>(null);
  const [loadingConvs, setLoadingConvs] = useState(true);
  const [loadingMsgs, setLoadingMsgs] = useState(false);
  const bottomRef = useRef<HTMLDivElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const { toast } = useToast();

  const scrollToBottom = useCallback(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, []);

  useEffect(() => { scrollToBottom(); }, [messages, streamingContent, scrollToBottom]);

  const fetchConversations = useCallback(async () => {
    try {
      const res = await fetch("/api/openai/conversations", { credentials: "include" });
      if (!res.ok) throw new Error("No se pudieron cargar las conversaciones.");
      const data: unknown = await res.json();
      if (!Array.isArray(data)) throw new Error("Respuesta no válida.");
      setConversations(data as Conversation[]);
    } catch {
      setConversations([]);
      toast({ title: "No se pudieron cargar las conversaciones", variant: "destructive" });
    } finally {
      setLoadingConvs(false);
    }
  }, [toast]);

  useEffect(() => { fetchConversations(); }, [fetchConversations]);

  const loadConversation = useCallback(async (id: number) => {
    setActiveId(id);
    setStreamingContent(null);
    setLoadingMsgs(true);
    try {
      const res = await fetch(`/api/openai/conversations/${id}`, { credentials: "include" });
      if (!res.ok) throw new Error("No se pudo cargar la conversación.");
      const data = await res.json();
      setMessages(data.messages ?? []);
    } catch {
      setMessages([]);
    } finally {
      setLoadingMsgs(false);
    }
  }, []);

  const createConversation = async () => {
    const title = `Chat ${new Date().toLocaleString("es", { day: "2-digit", month: "short", hour: "2-digit", minute: "2-digit" })}`;
    const res = await fetch("/api/openai/conversations", {
      method: "POST",
      credentials: "include",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ title }),
    });
    if (!res.ok) { toast({ title: "Error creando conversación", variant: "destructive" }); return; }
    const conv: Conversation = await res.json();
    setConversations((prev) => [...prev, conv]);
    setMessages([]);
    setStreamingContent(null);
    setActiveId(conv.id);
  };

  const deleteConversation = async (id: number, e: React.MouseEvent) => {
    e.stopPropagation();
    const res = await fetch(`/api/openai/conversations/${id}`, { method: "DELETE", credentials: "include" });
    if (!res.ok) {
      toast({ title: "No se pudo borrar la conversación", variant: "destructive" });
      return;
    }
    setConversations((prev) => prev.filter((c) => c.id !== id));
    if (activeId === id) { setActiveId(null); setMessages([]); }
  };

  const sendMessage = async () => {
    const text = input.trim();
    if (!text || !activeId || sending) return;

    setInput("");
    setSending(true);

    const userMsg: Message = {
      id: Date.now(),
      conversationId: activeId,
      role: "user",
      content: text,
      createdAt: new Date().toISOString(),
    };
    setMessages((prev) => [...prev, userMsg]);
    setStreamingContent("");

    try {
      const res = await fetch(`/api/openai/conversations/${activeId}/messages`, {
        method: "POST",
        credentials: "include",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ content: text }),
      });

      if (!res.ok || !res.body) {
        const errorBody = await res.json().catch(() => null) as { error?: string } | null;
        throw new Error(errorBody?.error ?? "Error del servidor");
      }

      const reader = res.body.getReader();
      const decoder = new TextDecoder();
      let buffer = "";
      let full = "";

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        buffer += decoder.decode(value, { stream: true });
        const parts = buffer.split("\n\n");
        buffer = parts.pop() ?? "";
        for (const part of parts) {
          if (!part.startsWith("data: ")) continue;
          const json = part.slice(6).trim();
          try {
            const ev = JSON.parse(json);
            if (ev.content) { full += ev.content; setStreamingContent(full); }
            if (ev.done || ev.error) break;
          } catch { /* skip */ }
        }
      }

      if (full) {
        const assistantMsg: Message = {
          id: Date.now() + 1,
          conversationId: activeId,
          role: "assistant",
          content: full,
          createdAt: new Date().toISOString(),
        };
        setMessages((prev) => [...prev, assistantMsg]);
      }
      setStreamingContent(null);
    } catch (err) {
      toast({ title: "Error enviando mensaje", description: String(err), variant: "destructive" });
      setMessages((prev) => prev.filter((m) => m.id !== userMsg.id));
      setInput(text);
      setStreamingContent(null);
    } finally {
      setSending(false);
      textareaRef.current?.focus();
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); sendMessage(); }
  };

  const allMessages = [
    ...messages,
    ...(streamingContent !== null
      ? [{ role: "assistant" as const, content: streamingContent, streaming: true as const }]
      : []),
  ];

  return (
    <div className="flex h-[calc(100vh-4rem)] gap-0 -m-6 overflow-hidden">
      {/* Sidebar */}
      <div className="w-64 shrink-0 border-r bg-card flex flex-col">
        <div className="p-3 border-b">
          <Button onClick={createConversation} className="w-full justify-start gap-2" size="sm">
            <Plus className="w-4 h-4" /> Nueva conversación
          </Button>
        </div>
        <ScrollArea className="flex-1">
          <div className="p-2 space-y-1">
            {loadingConvs ? (
              <div className="flex justify-center py-8">
                <Loader2 className="w-5 h-5 animate-spin text-muted-foreground" />
              </div>
            ) : conversations.length === 0 ? (
              <p className="text-xs text-muted-foreground text-center py-8">
                Crea una conversación para empezar
              </p>
            ) : (
              conversations.map((c) => (
                <div
                  key={c.id}
                  onClick={() => loadConversation(c.id)}
                  className={`group flex items-center justify-between gap-2 rounded-lg px-3 py-2 cursor-pointer text-sm transition-colors ${
                    activeId === c.id
                      ? "bg-primary/10 text-primary"
                      : "hover:bg-muted text-muted-foreground hover:text-foreground"
                  }`}
                >
                  <span className="truncate flex-1">{c.title}</span>
                  <button
                    onClick={(e) => deleteConversation(c.id, e)}
                    className="opacity-0 group-hover:opacity-100 text-muted-foreground hover:text-destructive transition-opacity"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              ))
            )}
          </div>
        </ScrollArea>
      </div>

      {/* Chat area */}
      <div className="flex-1 flex flex-col bg-background min-w-0">
        {activeId === null ? (
          <div className="flex-1 flex flex-col items-center justify-center gap-4 text-muted-foreground">
            <div className="w-16 h-16 rounded-2xl bg-primary/10 flex items-center justify-center">
              <MessageSquare className="w-8 h-8 text-primary" />
            </div>
            <div className="text-center">
              <p className="font-medium text-foreground">Chat de IA</p>
              <p className="text-sm mt-1">Selecciona o crea una conversación para empezar</p>
            </div>
            <Button onClick={createConversation} size="sm">
              <Plus className="w-4 h-4 mr-2" /> Nueva conversación
            </Button>
          </div>
        ) : (
          <>
            {/* Messages */}
            <ScrollArea className="flex-1 p-4">
              {loadingMsgs ? (
                <div className="flex justify-center py-8">
                  <Loader2 className="w-5 h-5 animate-spin text-muted-foreground" />
                </div>
              ) : allMessages.length === 0 ? (
                <div className="flex flex-col items-center justify-center h-full gap-3 py-16 text-muted-foreground">
                  <Bot className="w-10 h-10 opacity-30" />
                  <p className="text-sm">Escribe un mensaje para empezar</p>
                </div>
              ) : (
                <div className="space-y-4 max-w-3xl mx-auto">
                  {allMessages.map((msg, i) => (
                    <MessageBubble key={i} msg={msg as Message} />
                  ))}
                  <div ref={bottomRef} />
                </div>
              )}
            </ScrollArea>

            {/* Input */}
            <div className="p-4 border-t bg-card">
              <div className="max-w-3xl mx-auto flex gap-2 items-end">
                <Textarea
                  ref={textareaRef}
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  onKeyDown={handleKeyDown}
                  placeholder="Escribe un mensaje... (Enter para enviar, Shift+Enter para salto de línea)"
                  className="resize-none min-h-[44px] max-h-[160px]"
                  rows={1}
                  disabled={sending}
                />
                <Button
                  onClick={sendMessage}
                  disabled={!input.trim() || sending}
                  size="icon"
                  className="shrink-0 h-[44px] w-[44px]"
                >
                  {sending ? <Loader2 className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}
                </Button>
              </div>
              <p className="text-xs text-muted-foreground text-center mt-2">
                Powered by GPT-4o mini · Las conversaciones se guardan en la base de datos
              </p>
            </div>
          </>
        )}
      </div>
    </div>
  );
}
