import { useCallback, useEffect, useState } from "react";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import {
  Bot,
  Hash,
  Loader2,
  RefreshCw,
  Save,
  Send,
  Settings,
  Shield,
  Users,
  Power,
} from "lucide-react";

interface GuildConfig {
  verifiedRoleId: string | null;
  staffRoleId: string | null;
  announcementChannelId: string | null;
  welcomeChannelId: string | null;
  salesChannelId: string | null;
  vouchChannelId: string | null;
  ticketsCategoryId: string | null;
  logChannelId: string | null;
  verificationChannelId: string | null;
  welcomeEnabled: boolean;
  verificationEnabled: boolean;
  loggingEnabled: boolean;
  statsChannelsEnabled: boolean;
  announcementsEnabled: boolean;
  salesEnabled: boolean;
  vouchesEnabled: boolean;
  ticketsEnabled: boolean;
  memberJoinAlertsEnabled: boolean;
  memberLeaveAlertsEnabled: boolean;
  moderationAlertsEnabled: boolean;
  messageAlertsEnabled: boolean;
  channelAlertsEnabled: boolean;
  roleAlertsEnabled: boolean;
  verificationAlertsEnabled: boolean;
  announcementAlertsEnabled: boolean;
  saleAlertsEnabled: boolean;
  vouchAlertsEnabled: boolean;
  ticketAlertsEnabled: boolean;
  setupAlertsEnabled: boolean;
  welcomeTitle: string | null;
  welcomeMessage: string | null;
  welcomeFooter: string | null;
  welcomeColor: string | null;
}

interface DiscordInfo {
  guild: { id: string; name: string; icon: string | null; memberCount: number };
  stats: { bots: number; users: number; admins: number; total: number };
  channels: { id: string; name: string; type: number; parentId: string | null }[];
  roles: { id: string; name: string; color: string; position: number }[];
}

const ROLE_FIELDS: { key: "verifiedRoleId" | "staffRoleId"; label: string; description: string }[] = [
  { key: "verifiedRoleId", label: "Rol verificado", description: "Se asigna al pulsar el botón de verificación." },
  { key: "staffRoleId", label: "Rol staff", description: "Rol de referencia para el equipo moderador." },
];

const CHANNEL_FIELDS: {
  key:
    | "announcementChannelId"
    | "welcomeChannelId"
    | "salesChannelId"
    | "vouchChannelId"
    | "ticketsCategoryId"
    | "logChannelId"
    | "verificationChannelId";
  label: string;
  description: string;
  category?: boolean;
}[] = [
  { key: "announcementChannelId", label: "Anuncios", description: "Canal usado por los comunicados." },
  { key: "welcomeChannelId", label: "Bienvenida", description: "Canal para los mensajes de nuevos miembros." },
  { key: "salesChannelId", label: "Ventas", description: "Canal donde se publican las ventas." },
  { key: "vouchChannelId", label: "Vouches", description: "Canal de reseñas de vendedores." },
  { key: "ticketsCategoryId", label: "Categoría de tickets", description: "Categoría donde se crean los tickets.", category: true },
  { key: "logChannelId", label: "Logs", description: "Canal donde se registran los eventos del bot." },
  { key: "verificationChannelId", label: "Verificación", description: "Canal del panel de verificación." },
];

const NO_SELECTION = "__none__";

const MODULE_FIELDS: {
  key: keyof Pick<
    GuildConfig,
    | "welcomeEnabled"
    | "verificationEnabled"
    | "loggingEnabled"
    | "statsChannelsEnabled"
    | "announcementsEnabled"
    | "salesEnabled"
    | "vouchesEnabled"
    | "ticketsEnabled"
  >;
  label: string;
  description: string;
}[] = [
  { key: "welcomeEnabled", label: "Bienvenida", description: "Envía un mensaje cuando entra un miembro nuevo." },
  { key: "verificationEnabled", label: "Verificación", description: "Mantiene activo el panel y el botón de verificación." },
  { key: "loggingEnabled", label: "Logs del bot", description: "Guarda y publica los eventos en el canal de logs." },
  { key: "statsChannelsEnabled", label: "Canales estadísticos", description: "Actualiza los canales automáticos de estadísticas." },
  { key: "announcementsEnabled", label: "Anuncios", description: "Permite publicar comunicados con el bot." },
  { key: "salesEnabled", label: "Ventas", description: "Permite publicar ventas mediante el bot." },
  { key: "vouchesEnabled", label: "Vouches", description: "Permite crear y consultar reseñas." },
  { key: "ticketsEnabled", label: "Tickets", description: "Permite abrir y cerrar tickets." },
];

const ALERT_FIELDS: {
  key: keyof Pick<
    GuildConfig,
    | "memberJoinAlertsEnabled"
    | "memberLeaveAlertsEnabled"
    | "moderationAlertsEnabled"
    | "messageAlertsEnabled"
    | "channelAlertsEnabled"
    | "roleAlertsEnabled"
    | "verificationAlertsEnabled"
    | "announcementAlertsEnabled"
    | "saleAlertsEnabled"
    | "vouchAlertsEnabled"
    | "ticketAlertsEnabled"
    | "setupAlertsEnabled"
  >;
  label: string;
  description: string;
}[] = [
  { key: "memberJoinAlertsEnabled", label: "Miembros entran", description: "Avisa cuando entra un miembro nuevo." },
  { key: "memberLeaveAlertsEnabled", label: "Miembros salen", description: "Avisa cuando un miembro abandona o es expulsado." },
  { key: "moderationAlertsEnabled", label: "Moderación", description: "Bans, kicks, warns, blacklist, timeout y cambios de canales." },
  { key: "messageAlertsEnabled", label: "Mensajes", description: "Mensajes borrados, editados y enviados desde el dashboard." },
  { key: "channelAlertsEnabled", label: "Canales", description: "Canales creados o eliminados." },
  { key: "roleAlertsEnabled", label: "Roles", description: "Roles creados, eliminados o modificados." },
  { key: "verificationAlertsEnabled", label: "Verificaciones", description: "Usuarios que completan la verificación." },
  { key: "announcementAlertsEnabled", label: "Anuncios", description: "Comunicados publicados por el bot." },
  { key: "saleAlertsEnabled", label: "Ventas", description: "Ventas publicadas por los usuarios." },
  { key: "vouchAlertsEnabled", label: "Vouches", description: "Reseñas nuevas de vendedores." },
  { key: "ticketAlertsEnabled", label: "Tickets", description: "Tickets abiertos o cerrados." },
  { key: "setupAlertsEnabled", label: "Configuración", description: "Cambios realizados mediante /setup." },
];

function ResourceSelect({
  value,
  onChange,
  options,
  placeholder,
}: {
  value: string | null;
  onChange: (value: string | null) => void;
  options: { id: string; name: string }[];
  placeholder: string;
}) {
  return (
    <Select
      value={value ?? NO_SELECTION}
      onValueChange={(next) => onChange(next === NO_SELECTION ? null : next)}
    >
      <SelectTrigger>
        <SelectValue placeholder={placeholder} />
      </SelectTrigger>
      <SelectContent>
        <SelectItem value={NO_SELECTION}>Sin configurar</SelectItem>
        {options.map((option) => (
          <SelectItem key={option.id} value={option.id}>
            {option.name}
          </SelectItem>
        ))}
      </SelectContent>
    </Select>
  );
}

export default function ConfiguracionPage() {
  const [config, setConfig] = useState<GuildConfig | null>(null);
  const [info, setInfo] = useState<DiscordInfo | null>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [refreshing, setRefreshing] = useState(false);
  const [sendingWelcomeTest, setSendingWelcomeTest] = useState(false);
  const { toast } = useToast();

  const loadData = useCallback(async () => {
    setLoading(true);
    try {
      const [configResponse, infoResponse] = await Promise.all([
        fetch("/api/dashboard/config", { credentials: "include" }),
        fetch("/api/dashboard/discord-info", { credentials: "include" }),
      ]);
      if (!configResponse.ok || !infoResponse.ok) throw new Error("No se pudo cargar el servidor");
      setConfig((await configResponse.json()) as GuildConfig);
      setInfo((await infoResponse.json()) as DiscordInfo);
    } catch (error) {
      toast({
        title: "No se pudo cargar la configuración",
        description: error instanceof Error ? error.message : "Comprueba que el bot está conectado.",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  }, [toast]);

  useEffect(() => {
    void loadData();
  }, [loadData]);

  const handleSave = async () => {
    if (!config) return;
    setSaving(true);
    try {
      const response = await fetch("/api/dashboard/config", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
        body: JSON.stringify(config),
      });
      if (!response.ok) throw new Error("La configuración no se pudo guardar");
      setConfig((await response.json()) as GuildConfig);
      toast({ title: "Configuración guardada" });
    } catch (error) {
      toast({
        title: "Error al guardar",
        description: error instanceof Error ? error.message : "Inténtalo de nuevo.",
        variant: "destructive",
      });
    } finally {
      setSaving(false);
    }
  };

  const handleRefreshStats = async () => {
    setRefreshing(true);
    try {
      const response = await fetch("/api/dashboard/stats-channels/refresh", {
        method: "POST",
        credentials: "include",
      });
      const data = (await response.json()) as { ok?: boolean; error?: string };
      if (!response.ok) throw new Error(data.error ?? "No se pudieron actualizar");
      await loadData();
      toast({ title: "Canales estadísticos actualizados" });
    } catch (error) {
      toast({
        title: "Error actualizando canales",
        description: error instanceof Error ? error.message : "Comprueba el permiso Gestionar canales.",
        variant: "destructive",
      });
    } finally {
      setRefreshing(false);
    }
  };

  const handleWelcomeTest = async () => {
    setSendingWelcomeTest(true);
    try {
      const response = await fetch("/api/dashboard/welcome/test", {
        method: "POST",
        credentials: "include",
      });
      const data = (await response.json()) as { ok?: boolean; message?: string };
      if (!response.ok) throw new Error(data.message ?? "No se pudo enviar la prueba.");
      toast({ title: "Prueba enviada", description: data.message });
    } catch (error) {
      toast({
        title: "No se pudo enviar la bienvenida",
        description: error instanceof Error ? error.message : "Inténtalo de nuevo.",
        variant: "destructive",
      });
    } finally {
      setSendingWelcomeTest(false);
    }
  };

  const setField = (key: keyof GuildConfig, value: string | null) => {
    setConfig((current) => (current ? { ...current, [key]: value } : current));
  };

  const setModule = (key: keyof GuildConfig, value: boolean) => {
    setConfig((current) => (current ? { ...current, [key]: value } : current));
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-20">
        <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
      </div>
    );
  }

  if (!config || !info) {
    return (
      <Card>
        <CardContent className="flex flex-col items-center gap-4 py-16 text-center">
          <Settings className="h-8 w-8 text-muted-foreground" />
          <p className="text-muted-foreground">No se pudo cargar el panel del servidor.</p>
          <Button onClick={() => void loadData()}>Reintentar</Button>
        </CardContent>
      </Card>
    );
  }

  const textChannels = info.channels.filter((channel) => [0, 5].includes(channel.type));
  const categories = info.channels.filter((channel) => channel.type === 4);

  return (
    <div className="max-w-4xl space-y-6">
      <div className="flex flex-col justify-between gap-4 sm:flex-row sm:items-start">
        <div>
          <h1 className="flex items-center gap-2 text-2xl font-bold">
            <Settings className="h-6 w-6" />
            Control del bot
          </h1>
          <p className="mt-1 text-muted-foreground">
            Configura las funciones del bot usando los recursos reales de Discord.
          </p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" onClick={() => void loadData()} disabled={loading}>
            <RefreshCw className="mr-2 h-4 w-4" />
            Recargar
          </Button>
          <Button onClick={handleSave} disabled={saving}>
            {saving ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Save className="mr-2 h-4 w-4" />}
            Guardar
          </Button>
        </div>
      </div>

      <Card className="overflow-hidden">
        <CardHeader className="border-b">
          <div className="flex items-center gap-3">
            {info.guild.icon ? (
              <img src={info.guild.icon} alt="" className="h-11 w-11 rounded-full" />
            ) : (
              <div className="flex h-11 w-11 items-center justify-center rounded-full bg-primary/10">
                <Bot className="h-5 w-5 text-primary" />
              </div>
            )}
            <div>
              <CardTitle>{info.guild.name}</CardTitle>
              <CardDescription>ID: {info.guild.id}</CardDescription>
            </div>
            <Badge className="ml-auto" variant="secondary">Bot conectado</Badge>
          </div>
        </CardHeader>
        <CardContent className="grid gap-3 pt-6 sm:grid-cols-4">
          {[
            { label: "Bots", value: info.stats.bots, icon: Bot },
            { label: "Usuarios", value: info.stats.users, icon: Users },
            { label: "Admins", value: info.stats.admins, icon: Shield },
            { label: "Total", value: info.stats.total, icon: Users },
          ].map(({ label, value, icon: Icon }) => (
            <div key={label} className="rounded-lg border bg-muted/30 p-4">
              <div className="flex items-center justify-between text-muted-foreground">
                <span className="text-sm">{label}</span>
                <Icon className="h-4 w-4" />
              </div>
              <p className="mt-2 text-2xl font-bold">{value.toLocaleString("es-ES")}</p>
            </div>
          ))}
        </CardContent>
        <div className="flex flex-col justify-between gap-3 border-t bg-muted/20 px-6 py-4 sm:flex-row sm:items-center">
          <p className="text-sm text-muted-foreground">
            Los canales estadísticos se mantienen actualizados automáticamente.
          </p>
          <Button variant="outline" size="sm" onClick={handleRefreshStats} disabled={refreshing}>
            {refreshing ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <RefreshCw className="mr-2 h-4 w-4" />}
            Actualizar canales
          </Button>
        </div>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-base">
            <Power className="h-4 w-4" />
            Módulos del bot
          </CardTitle>
          <CardDescription>
            Activa o desactiva funciones completas. Los cambios se aplican al pulsar Guardar.
          </CardDescription>
        </CardHeader>
        <CardContent className="grid gap-3 sm:grid-cols-2">
          {MODULE_FIELDS.map(({ key, label, description }) => (
            <div key={key} className="flex items-start justify-between gap-4 rounded-lg border p-4">
              <div className="space-y-1">
                <Label htmlFor={`module-${key}`} className="cursor-pointer">{label}</Label>
                <p className="text-xs text-muted-foreground">{description}</p>
              </div>
              <Switch
                id={`module-${key}`}
                checked={config[key]}
                onCheckedChange={(checked) => setModule(key, checked)}
              />
            </div>
          ))}
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-base">
            <Power className="h-4 w-4" />
            Alertas de actividad
          </CardTitle>
          <CardDescription>
            Elige qué tipos de eventos se guardan y se publican en el canal de logs. Los cambios se aplican al pulsar Guardar.
          </CardDescription>
        </CardHeader>
        <CardContent className="grid gap-3 sm:grid-cols-2">
          {ALERT_FIELDS.map(({ key, label, description }) => (
            <div key={key} className="flex items-start justify-between gap-4 rounded-lg border p-4">
              <div className="space-y-1">
                <Label htmlFor={`alert-${key}`} className="cursor-pointer">{label}</Label>
                <p className="text-xs text-muted-foreground">{description}</p>
              </div>
              <Switch
                id={`alert-${key}`}
                checked={config[key]}
                onCheckedChange={(checked) => setModule(key, checked)}
              />
            </div>
          ))}
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-base">
            <Bot className="h-4 w-4" />
            Personalizar bienvenida
          </CardTitle>
          <CardDescription>
            Usa <code>{"{usuario}"}</code>, <code>{"{servidor}"}</code>, <code>{"{verificacion}"}</code>, <code>{"{ventas}"}</code> y <code>{"{vouches}"}</code> para insertar datos automáticamente.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-5">
          <div className="grid gap-5 sm:grid-cols-2">
            <div className="space-y-2">
              <Label htmlFor="welcome-title">Título</Label>
              <Input
                id="welcome-title"
                value={config.welcomeTitle ?? ""}
                onChange={(event) => setField("welcomeTitle", event.target.value || null)}
                placeholder="¡Bienvenido a {servidor}!"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="welcome-color">Color</Label>
              <div className="flex gap-2">
                <input
                  id="welcome-color"
                  type="color"
                  value={/^#[0-9a-f]{6}$/i.test(config.welcomeColor ?? "") ? config.welcomeColor! : "#9333ea"}
                  onChange={(event) => setField("welcomeColor", event.target.value)}
                  className="h-10 w-12 cursor-pointer rounded-md border border-input bg-transparent p-1"
                />
                <Input
                  value={config.welcomeColor ?? ""}
                  onChange={(event) => setField("welcomeColor", event.target.value || null)}
                  placeholder="#9333ea"
                  maxLength={7}
                />
              </div>
            </div>
          </div>
          <div className="space-y-2">
            <Label htmlFor="welcome-message">Mensaje</Label>
            <Textarea
              id="welcome-message"
              value={config.welcomeMessage ?? ""}
              onChange={(event) => setField("welcomeMessage", event.target.value || null)}
              placeholder={"Hola {usuario}, qué bueno tenerte en {servidor}.\n\nPásate por {verificacion} para verificarte."}
              rows={7}
              className="resize-y"
            />
            <p className="text-xs text-muted-foreground">
              Si lo dejas vacío se usará el mensaje predeterminado del bot.
            </p>
          </div>
          <div className="space-y-2">
            <Label htmlFor="welcome-footer">Pie del mensaje</Label>
            <Input
              id="welcome-footer"
              value={config.welcomeFooter ?? ""}
              onChange={(event) => setField("welcomeFooter", event.target.value || null)}
              placeholder="Miembro #{numero}"
            />
          </div>
          <div className="space-y-3 rounded-lg border bg-muted/20 p-4">
            <div>
              <p className="text-sm font-medium">Vista previa</p>
              <p className="text-xs text-muted-foreground">
                Se actualiza con los valores que estás editando. La prueba usa los valores guardados.
              </p>
            </div>
            <div
              className="rounded-md bg-[#313338] p-4 text-sm"
              style={{
                borderLeft: `4px solid ${
                  /^#[0-9a-f]{6}$/i.test(config.welcomeColor ?? "")
                    ? config.welcomeColor
                    : "#9333ea"
                }`,
              }}
            >
              <p className="font-semibold text-white">
                {(config.welcomeTitle || "¡Bienvenido a {servidor}!")
                  .replaceAll("{usuario}", "@usuario")
                  .replaceAll("{servidor}", info.guild.name)}
              </p>
              <p className="mt-2 whitespace-pre-wrap text-[#dbdee1]">
                {(config.welcomeMessage ||
                  "Hola {usuario}, qué bueno tenerte en {servidor}.\n\nPásate por {verificacion} para verificarte.")
                  .replaceAll("{usuario}", "@usuario")
                  .replaceAll("{servidor}", info.guild.name)
                  .replaceAll("{verificacion}", "#verificación")
                  .replaceAll("{ventas}", "#ventas")
                  .replaceAll("{vouches}", "#vouches")
                  .replaceAll("{numero}", String(info.guild.memberCount))}
              </p>
              <p className="mt-3 text-xs text-[#87898c]">
                {(config.welcomeFooter || "Miembro #{numero}")
                  .replaceAll("{servidor}", info.guild.name)
                  .replaceAll("{numero}", String(info.guild.memberCount))}
              </p>
            </div>
            <Button
              variant="outline"
              className="w-full sm:w-auto"
              onClick={() => void handleWelcomeTest()}
              disabled={sendingWelcomeTest || !config.welcomeEnabled}
            >
              {sendingWelcomeTest ? (
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              ) : (
                <Send className="mr-2 h-4 w-4" />
              )}
              Enviar prueba al canal
            </Button>
            {!config.welcomeEnabled && (
              <p className="text-xs text-muted-foreground">
                Activa el módulo de bienvenida para poder enviar una prueba.
              </p>
            )}
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-base">
            <Shield className="h-4 w-4" />
            Roles del bot
          </CardTitle>
          <CardDescription>Selecciona directamente los roles del servidor. Ya no necesitas copiar IDs.</CardDescription>
        </CardHeader>
        <CardContent className="grid gap-5 sm:grid-cols-2">
          {ROLE_FIELDS.map(({ key, label, description }) => (
            <div key={key} className="space-y-2">
              <Label>{label}</Label>
              <ResourceSelect
                value={config[key]}
                onChange={(value) => setField(key, value)}
                options={info.roles}
                placeholder="Selecciona un rol"
              />
              <p className="text-xs text-muted-foreground">{description}</p>
            </div>
          ))}
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-base">
            <Hash className="h-4 w-4" />
            Canales y categorías
          </CardTitle>
          <CardDescription>Elige dónde trabajará cada módulo del bot.</CardDescription>
        </CardHeader>
        <CardContent className="grid gap-5 sm:grid-cols-2">
          {CHANNEL_FIELDS.map(({ key, label, description, category }) => (
            <div key={key} className="space-y-2">
              <Label>{label}</Label>
              <ResourceSelect
                value={config[key]}
                onChange={(value) => setField(key, value)}
                options={category ? categories : textChannels}
                placeholder={category ? "Selecciona una categoría" : "Selecciona un canal"}
              />
              <p className="text-xs text-muted-foreground">{description}</p>
            </div>
          ))}
        </CardContent>
      </Card>
    </div>
  );
}