import { useLocation } from "wouter";
import { Shield } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function Login() {
  const [location] = useLocation();
  const searchParams = new URLSearchParams(window.location.search);
  const error = searchParams.get("error");

  return (
    <div className="min-h-screen w-full flex items-center justify-center bg-background p-4 relative overflow-hidden">
      {/* Background decoration */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-primary/5 rounded-full blur-[100px] pointer-events-none" />
      
      <div className="w-full max-w-md bg-card border border-border rounded-xl shadow-2xl p-8 relative z-10 flex flex-col items-center text-center">
        <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mb-6 ring-1 ring-primary/20">
          <Shield className="w-8 h-8 text-primary" />
        </div>
        
        <h1 className="text-3xl font-bold mb-2">MODEOS EL OBI</h1>
        <p className="text-muted-foreground mb-8 text-sm">
          Panel de control de moderación y herramientas operativas.
        </p>
        
        {error && (
          <div className="w-full bg-destructive/10 border border-destructive/20 text-destructive text-sm p-3 rounded-lg mb-6">
            {error === "unauthorized" ? "No tienes acceso al panel de control." : "Ocurrió un error al intentar iniciar sesión."}
          </div>
        )}

        <Button 
          asChild 
          size="lg" 
          className="w-full bg-[#5865F2] hover:bg-[#4752C4] text-white"
        >
          <a href="/api/auth/discord">
            Iniciar sesión con Discord
          </a>
        </Button>
      </div>
    </div>
  );
}
