import { useGetDashboardStats } from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ShieldBan, Star, AlertTriangle, ShoppingCart, Activity, Clock } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";

function StatCard({ 
  title, 
  value, 
  icon: Icon, 
  description,
  isLoading
}: { 
  title: string; 
  value: string | number; 
  icon: React.ElementType;
  description?: string;
  isLoading: boolean;
}) {
  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle className="text-sm font-medium text-muted-foreground">
          {title}
        </CardTitle>
        <div className="p-2 bg-secondary rounded-md">
          <Icon className="h-4 w-4 text-primary" />
        </div>
      </CardHeader>
      <CardContent>
        {isLoading ? (
          <Skeleton className="h-8 w-20" />
        ) : (
          <div className="text-2xl font-bold">{value}</div>
        )}
        {description && (
          <p className="text-xs text-muted-foreground mt-1">
            {description}
          </p>
        )}
      </CardContent>
    </Card>
  );
}

export default function StatsPage() {
  const { data: stats, isLoading, error } = useGetDashboardStats();

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight">Estadísticas Generales</h1>
        <p className="text-sm text-muted-foreground mt-1">
          Métricas clave del sistema de moderación.
        </p>
      </div>

      {error && (
        <div className="rounded-md border border-destructive/30 bg-destructive/10 px-4 py-3 text-sm text-destructive">
          No se pudieron cargar las estadísticas. Comprueba la conexión con el servidor.
        </div>
      )}

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        <StatCard 
          title="Total Vouches" 
          value={stats?.totalVouches ?? 0} 
          icon={Star} 
          isLoading={isLoading}
        />
        <StatCard 
          title="Total Advertencias" 
          value={stats?.totalWarns ?? 0} 
          icon={AlertTriangle} 
          isLoading={isLoading}
        />
        <StatCard 
          title="Lista Negra" 
          value={stats?.totalBlacklisted ?? 0} 
          icon={ShieldBan} 
          isLoading={isLoading}
        />
        <StatCard 
          title="Total Ventas" 
          value={stats?.totalSales ?? 0} 
          icon={ShoppingCart} 
          isLoading={isLoading}
        />
        <StatCard 
          title="Total Eventos" 
          value={stats?.totalEvents ?? 0} 
          icon={Activity} 
          isLoading={isLoading}
        />
        <StatCard 
          title="Eventos Recientes" 
          value={stats?.recentEvents ?? 0} 
          icon={Clock} 
          description="Últimas 24 horas"
          isLoading={isLoading}
        />
      </div>
    </div>
  );
}
