import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { format } from "date-fns";
import { es } from "date-fns/locale";
import { ShoppingBag, Search, Star, Users, DollarSign, ExternalLink } from "lucide-react";

interface SaleEntry {
  id: number;
  guildId: string;
  sellerId: string;
  sellerTag: string;
  name: string;
  members: number;
  price: string;
  niche: string;
  description: string;
  paymentMethods: string | null;
  imageUrl: string | null;
  messageId: string | null;
  channelId: string | null;
  createdAt: string;
}

const NICHES: Record<string, string> = {
  gaming: "🎮 Gaming",
  crypto: "💰 Crypto",
  anime: "🎌 Anime",
  nfsw: "🔞 NSFW",
  general: "💬 General",
  tecnologia: "💻 Tecnología",
  musica: "🎵 Música",
  arte: "🎨 Arte",
  deportes: "⚽ Deportes",
};

export default function VentasPage() {
  const [sales, setSales] = useState<SaleEntry[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [page, setPage] = useState(0);
  const PAGE_SIZE = 20;

  const fetchSales = async (offset = 0) => {
    setLoading(true);
    try {
      const res = await fetch(`/api/dashboard/sales?limit=${PAGE_SIZE}&offset=${offset}`, {
        credentials: "include",
      });
      if (!res.ok) throw new Error("Error cargando ventas");
      const data: SaleEntry[] = await res.json();
      setSales(data);
    } catch {
      setSales([]);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchSales(page * PAGE_SIZE);
  }, [page]);

  const filtered = sales.filter(
    (s) =>
      s.name.toLowerCase().includes(search.toLowerCase()) ||
      s.sellerTag.toLowerCase().includes(search.toLowerCase()) ||
      s.niche.toLowerCase().includes(search.toLowerCase()),
  );

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold flex items-center gap-2">
          <ShoppingBag className="w-6 h-6" />
          Ventas de servidores
        </h1>
        <p className="text-muted-foreground mt-1">Historial de Discords publicados en venta</p>
      </div>

      <div className="flex items-center gap-3">
        <div className="relative flex-1 max-w-sm">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            className="pl-9"
            placeholder="Buscar por nombre, vendedor o nicho..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </div>
        <Button variant="outline" size="sm" onClick={() => fetchSales(page * PAGE_SIZE)}>
          Actualizar
        </Button>
      </div>

      {loading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
          {Array.from({ length: 6 }).map((_, i) => (
            <Card key={i} className="animate-pulse">
              <CardHeader>
                <div className="h-5 bg-muted rounded w-2/3" />
                <div className="h-4 bg-muted rounded w-1/3 mt-1" />
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <div className="h-4 bg-muted rounded w-full" />
                  <div className="h-4 bg-muted rounded w-4/5" />
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      ) : filtered.length === 0 ? (
        <Card>
          <CardContent className="py-16 text-center text-muted-foreground">
            <ShoppingBag className="w-10 h-10 mx-auto mb-3 opacity-30" />
            {search ? "No hay ventas que coincidan con la búsqueda." : "No hay ventas registradas todavía."}
          </CardContent>
        </Card>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
          {filtered.map((sale) => (
            <Card key={sale.id} className="flex flex-col">
              {sale.imageUrl && (
                <div className="h-36 overflow-hidden rounded-t-lg">
                  <img
                    src={sale.imageUrl}
                    alt={sale.name}
                    className="w-full h-full object-cover"
                    onError={(e) => { (e.target as HTMLImageElement).style.display = "none"; }}
                  />
                </div>
              )}
              <CardHeader className="pb-2">
                <div className="flex items-start justify-between gap-2">
                  <CardTitle className="text-base leading-tight">{sale.name}</CardTitle>
                  <Badge variant="secondary" className="shrink-0 text-xs">
                    {NICHES[sale.niche] ?? sale.niche}
                  </Badge>
                </div>
                <p className="text-xs text-muted-foreground">
                  Vendedor: <span className="font-medium text-foreground">@{sale.sellerTag}</span>
                </p>
              </CardHeader>
              <CardContent className="flex-1 space-y-3">
                <p className="text-sm text-muted-foreground line-clamp-2">{sale.description}</p>

                <div className="flex items-center gap-4 text-sm">
                  <span className="flex items-center gap-1 text-muted-foreground">
                    <Users className="w-3.5 h-3.5" />
                    {sale.members.toLocaleString()} miembros
                  </span>
                  <span className="flex items-center gap-1 font-semibold text-green-600 dark:text-green-400">
                    <DollarSign className="w-3.5 h-3.5" />
                    {sale.price}
                  </span>
                </div>

                {sale.paymentMethods && (
                  <p className="text-xs text-muted-foreground">
                    Métodos: {sale.paymentMethods}
                  </p>
                )}

                <div className="flex items-center justify-between pt-1">
                  <span className="text-xs text-muted-foreground">
                    {format(new Date(sale.createdAt), "d MMM yyyy", { locale: es })}
                  </span>
                  {sale.messageId && sale.channelId && (
                    <a
                      href={`https://discord.com/channels/${sale.guildId}/${sale.channelId}/${sale.messageId}`}
                      target="_blank"
                      rel="noreferrer"
                      className="inline-flex items-center gap-1 text-xs text-primary hover:underline"
                    >
                      Ver en Discord <ExternalLink className="w-3 h-3" />
                    </a>
                  )}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      <div className="flex justify-center gap-2">
        <Button
          variant="outline"
          size="sm"
          disabled={page === 0}
          onClick={() => setPage((p) => p - 1)}
        >
          ← Anterior
        </Button>
        <span className="flex items-center px-3 text-sm text-muted-foreground">
          Página {page + 1}
        </span>
        <Button
          variant="outline"
          size="sm"
          disabled={sales.length < PAGE_SIZE}
          onClick={() => setPage((p) => p + 1)}
        >
          Siguiente →
        </Button>
      </div>
    </div>
  );
}
