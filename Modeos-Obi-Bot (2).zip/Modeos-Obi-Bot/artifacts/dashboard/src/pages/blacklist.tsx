import { useGetDashboardBlacklist, useRemoveDashboardBlacklist, getGetDashboardBlacklistQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { format } from "date-fns";
import { es } from "date-fns/locale";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { ShieldBan, Trash2 } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";

export default function BlacklistPage() {
  const { data: blacklist, isLoading } = useGetDashboardBlacklist();
  const removeBlacklist = useRemoveDashboardBlacklist();
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const handleRemove = (userId: string) => {
    removeBlacklist.mutate(
      { userId },
      {
        onSuccess: () => {
          toast({
            title: "Usuario eliminado",
            description: "El usuario ha sido removido de la lista negra.",
          });
          queryClient.invalidateQueries({ queryKey: getGetDashboardBlacklistQueryKey() });
        },
        onError: () => {
          toast({
            title: "Error",
            description: "No se pudo remover al usuario de la lista negra.",
            variant: "destructive",
          });
        }
      }
    );
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Lista Negra</h1>
          <p className="text-sm text-muted-foreground mt-1">
            Usuarios bloqueados permanentemente del sistema.
          </p>
        </div>
      </div>

      <div className="border border-border rounded-md bg-card">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Usuario</TableHead>
              <TableHead>ID</TableHead>
              <TableHead>Motivo</TableHead>
              <TableHead>Añadido Por</TableHead>
              <TableHead>Fecha</TableHead>
              <TableHead className="text-right">Acciones</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {isLoading ? (
              Array.from({ length: 3 }).map((_, i) => (
                <TableRow key={i}>
                  <TableCell><Skeleton className="h-4 w-[120px]" /></TableCell>
                  <TableCell><Skeleton className="h-4 w-[160px]" /></TableCell>
                  <TableCell><Skeleton className="h-4 w-[200px]" /></TableCell>
                  <TableCell><Skeleton className="h-4 w-[120px]" /></TableCell>
                  <TableCell><Skeleton className="h-4 w-[100px]" /></TableCell>
                  <TableCell><Skeleton className="h-8 w-8 ml-auto" /></TableCell>
                </TableRow>
              ))
            ) : !blacklist || blacklist.length === 0 ? (
              <TableRow>
                <TableCell colSpan={6} className="h-32 text-center text-muted-foreground">
                  La lista negra está vacía.
                </TableCell>
              </TableRow>
            ) : (
              blacklist.map((entry) => (
                <TableRow key={entry.id}>
                  <TableCell className="font-medium text-destructive">
                    {entry.userTag}
                  </TableCell>
                  <TableCell className="font-mono text-xs text-muted-foreground">
                    {entry.userId}
                  </TableCell>
                  <TableCell className="max-w-[200px] truncate" title={entry.reason}>
                    {entry.reason}
                  </TableCell>
                  <TableCell>
                    {entry.addedByTag}
                  </TableCell>
                  <TableCell className="text-sm text-muted-foreground">
                    {format(new Date(entry.createdAt), "dd MMM yyyy", { locale: es })}
                  </TableCell>
                  <TableCell className="text-right">
                    <AlertDialog>
                      <AlertDialogTrigger asChild>
                        <Button variant="ghost" size="icon" className="text-destructive hover:bg-destructive/10 hover:text-destructive">
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </AlertDialogTrigger>
                      <AlertDialogContent>
                        <AlertDialogHeader>
                          <AlertDialogTitle>¿Remover de la lista negra?</AlertDialogTitle>
                          <AlertDialogDescription>
                            El usuario {entry.userTag} ({entry.userId}) podrá volver a interactuar con el sistema. ¿Estás seguro?
                          </AlertDialogDescription>
                        </AlertDialogHeader>
                        <AlertDialogFooter>
                          <AlertDialogCancel>Cancelar</AlertDialogCancel>
                          <AlertDialogAction 
                            onClick={() => handleRemove(entry.userId)}
                            className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                          >
                            Remover
                          </AlertDialogAction>
                        </AlertDialogFooter>
                      </AlertDialogContent>
                    </AlertDialog>
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </div>
    </div>
  );
}
