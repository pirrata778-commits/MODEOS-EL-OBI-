import { useState, useEffect } from "react";
import { useGetDashboardAdmins, useRemoveDashboardAdmin, getGetDashboardAdminsQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { format } from "date-fns";
import { es } from "date-fns/locale";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Trash2, Info, ShieldCheck, UserCheck, RefreshCw } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

interface DetectedAdmin {
  id: string;
  username: string;
  displayName: string;
  avatar: string | null;
  roles: { id: string; name: string; color: string }[];
}

function Avatar({ userId, avatar, name }: { userId: string; avatar: string | null; name: string }) {
  if (avatar) {
    return (
      <img
        src={`https://cdn.discordapp.com/avatars/${userId}/${avatar}.png?size=32`}
        alt={name}
        className="w-8 h-8 rounded-full object-cover"
      />
    );
  }
  return (
    <div className="w-8 h-8 rounded-full bg-secondary flex items-center justify-center text-xs font-bold text-muted-foreground uppercase">
      {name.charAt(0)}
    </div>
  );
}

export default function AdminsPage() {
  const { data: admins, isLoading } = useGetDashboardAdmins();
  const removeAdmin = useRemoveDashboardAdmin();
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const [detected, setDetected] = useState<DetectedAdmin[] | null>(null);
  const [detectedLoading, setDetectedLoading] = useState(false);

  const fetchDetected = () => {
    setDetectedLoading(true);
    fetch("/api/dashboard/admins/detected", { credentials: "include" })
      .then(async (r) => {
        if (!r.ok) throw new Error("No se pudieron cargar los administradores.");
        const data = (await r.json()) as unknown;
        if (!Array.isArray(data)) throw new Error("Respuesta no válida.");
        return data as DetectedAdmin[];
      })
      .then((data) => setDetected(data))
      .catch(() => setDetected([]))
      .finally(() => setDetectedLoading(false));
  };

  useEffect(() => { fetchDetected(); }, []);

  const handleRemove = (userId: string, tag: string) => {
    removeAdmin.mutate(
      { userId },
      {
        onSuccess: () => {
          toast({ title: "Acceso revocado", description: `${tag} ya no puede acceder al panel.` });
          queryClient.invalidateQueries({ queryKey: getGetDashboardAdminsQueryKey() });
        },
        onError: () => {
          toast({ title: "Error", description: "No se pudo revocar el acceso.", variant: "destructive" });
        },
      },
    );
  };

  const manualAdminIds = new Set((admins ?? []).map((a) => a.userId));

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight">Administradores</h1>
        <p className="text-sm text-muted-foreground mt-1">
          Gestión de usuarios con acceso a este panel de control.
        </p>
      </div>

      <Alert>
        <Info className="h-4 w-4" />
        <AlertTitle>Añadir acceso al dashboard</AlertTitle>
        <AlertDescription>
          Usa el comando de Discord{" "}
          <code className="bg-secondary px-1 py-0.5 rounded text-primary">/acceso add @usuario</code>{" "}
          para dar acceso. Para revocar:{" "}
          <code className="bg-secondary px-1 py-0.5 rounded text-primary">/acceso remove @usuario</code>
        </AlertDescription>
      </Alert>

      {/* ── Detected Admins ───────────────────────────────────── */}
      <Card>
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center gap-2 text-base">
              <ShieldCheck className="w-4 h-4 text-primary" />
              Admins detectados en Discord
              <Badge variant="secondary" className="text-xs">{detected?.length ?? "…"}</Badge>
            </CardTitle>
            <Button variant="ghost" size="sm" onClick={fetchDetected} disabled={detectedLoading} className="gap-1.5 text-xs">
              <RefreshCw className={`w-3.5 h-3.5 ${detectedLoading ? "animate-spin" : ""}`} />
              Actualizar
            </Button>
          </div>
          <p className="text-xs text-muted-foreground mt-0.5">
            Miembros del servidor con permiso de <strong>Administrador</strong> en Discord.
          </p>
        </CardHeader>
        <CardContent>
          <div className="border border-border rounded-md">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Usuario</TableHead>
                  <TableHead>Roles</TableHead>
                  <TableHead>ID</TableHead>
                  <TableHead className="text-right">Panel</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {detectedLoading ? (
                  Array.from({ length: 3 }).map((_, i) => (
                    <TableRow key={i}>
                      <TableCell><Skeleton className="h-4 w-[140px]" /></TableCell>
                      <TableCell><Skeleton className="h-4 w-[120px]" /></TableCell>
                      <TableCell><Skeleton className="h-4 w-[160px]" /></TableCell>
                      <TableCell><Skeleton className="h-6 w-16 ml-auto" /></TableCell>
                    </TableRow>
                  ))
                ) : !detected || detected.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={4} className="h-24 text-center text-muted-foreground text-sm">
                      No se detectaron administradores.
                    </TableCell>
                  </TableRow>
                ) : (
                  detected.map((m) => (
                    <TableRow key={m.id}>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <Avatar userId={m.id} avatar={m.avatar} name={m.displayName} />
                          <div>
                            <p className="font-medium text-sm">{m.displayName}</p>
                            <p className="text-xs text-muted-foreground">@{m.username}</p>
                          </div>
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="flex flex-wrap gap-1">
                          {m.roles.map((r) => (
                            <span
                              key={r.id}
                              className="text-xs px-1.5 py-0.5 rounded border"
                              style={{
                                borderColor: r.color === "#000000" ? "hsl(var(--border))" : r.color + "60",
                                color: r.color === "#000000" ? "hsl(var(--muted-foreground))" : r.color,
                              }}
                            >
                              {r.name}
                            </span>
                          ))}
                        </div>
                      </TableCell>
                      <TableCell className="font-mono text-xs text-muted-foreground">{m.id}</TableCell>
                      <TableCell className="text-right">
                        {manualAdminIds.has(m.id) ? (
                          <Badge variant="secondary" className="gap-1 text-xs">
                            <UserCheck className="w-3 h-3" /> Con acceso
                          </Badge>
                        ) : (
                          <span className="text-xs text-muted-foreground">Sin acceso</span>
                        )}
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      {/* ── Manual Admins (Dashboard Access) ──────────────────── */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center gap-2 text-base">
            <UserCheck className="w-4 h-4 text-primary" />
            Acceso al panel
            <Badge variant="secondary" className="text-xs">{admins?.length ?? "…"}</Badge>
          </CardTitle>
          <p className="text-xs text-muted-foreground mt-0.5">
            Usuarios con acceso al dashboard — gestionado con <code className="bg-secondary px-1 rounded">/acceso</code>.
          </p>
        </CardHeader>
        <CardContent>
          <div className="border border-border rounded-md">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Usuario</TableHead>
                  <TableHead>ID</TableHead>
                  <TableHead>Añadido Por</TableHead>
                  <TableHead>Fecha</TableHead>
                  <TableHead className="text-right">Acciones</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {isLoading ? (
                  Array.from({ length: 3 }).map((_, i) => (
                    <TableRow key={i}>
                      <TableCell><Skeleton className="h-4 w-[140px]" /></TableCell>
                      <TableCell><Skeleton className="h-4 w-[160px]" /></TableCell>
                      <TableCell><Skeleton className="h-4 w-[160px]" /></TableCell>
                      <TableCell><Skeleton className="h-4 w-[100px]" /></TableCell>
                      <TableCell><Skeleton className="h-8 w-8 ml-auto" /></TableCell>
                    </TableRow>
                  ))
                ) : !admins || admins.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={5} className="h-24 text-center text-muted-foreground text-sm">
                      No hay usuarios con acceso al panel.
                    </TableCell>
                  </TableRow>
                ) : (
                  admins.map((admin) => (
                    <TableRow key={admin.id}>
                      <TableCell className="font-medium">{admin.userTag}</TableCell>
                      <TableCell className="font-mono text-xs text-muted-foreground">{admin.userId}</TableCell>
                      <TableCell className="font-mono text-xs text-muted-foreground">{admin.addedById}</TableCell>
                      <TableCell className="text-sm text-muted-foreground">
                        {format(new Date(admin.createdAt), "dd MMM yyyy", { locale: es })}
                      </TableCell>
                      <TableCell className="text-right">
                        <AlertDialog>
                          <AlertDialogTrigger asChild>
                            <Button variant="ghost" size="icon" className="text-destructive hover:bg-destructive/10 hover:text-destructive">
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </AlertDialogTrigger>
                          <AlertDialogContent>
                            <AlertDialogHeader>
                              <AlertDialogTitle>¿Revocar acceso?</AlertDialogTitle>
                              <AlertDialogDescription>
                                {admin.userTag} perderá acceso inmediato al panel. ¿Estás seguro?
                              </AlertDialogDescription>
                            </AlertDialogHeader>
                            <AlertDialogFooter>
                              <AlertDialogCancel>Cancelar</AlertDialogCancel>
                              <AlertDialogAction
                                onClick={() => handleRemove(admin.userId, admin.userTag)}
                                className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                              >
                                Revocar acceso
                              </AlertDialogAction>
                            </AlertDialogFooter>
                          </AlertDialogContent>
                        </AlertDialog>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
