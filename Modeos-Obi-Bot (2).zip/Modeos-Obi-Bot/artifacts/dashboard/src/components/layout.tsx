import { useLocation } from "wouter";
import { useEffect } from "react";
import { useGetMe, getGetMeQueryKey } from "@workspace/api-client-react";
import { SidebarProvider, Sidebar, SidebarContent, SidebarGroup, SidebarGroupContent, SidebarGroupLabel, SidebarMenu, SidebarMenuButton, SidebarMenuItem, SidebarHeader, SidebarFooter, SidebarRail } from "@/components/ui/sidebar";
import { LayoutDashboard, List, ShieldBan, Star, AlertTriangle, Users, LogOut, Loader2, Terminal, Megaphone, ShoppingBag, Settings, MessageSquare } from "lucide-react";
import { Button } from "@/components/ui/button";

function UserProfile() {
  const { data: user } = useGetMe({ query: { retry: false, queryKey: getGetMeQueryKey() } });

  if (!user) return null;

  return (
    <div className="flex items-center gap-3 p-2">
      <div className="w-10 h-10 rounded-full bg-secondary overflow-hidden shrink-0">
        {user.avatar ? (
          <img 
            src={`https://cdn.discordapp.com/avatars/${user.id}/${user.avatar}.png`} 
            alt={user.username}
            className="w-full h-full object-cover"
          />
        ) : (
          <div className="w-full h-full flex items-center justify-center text-muted-foreground uppercase">
            {user.username.charAt(0)}
          </div>
        )}
      </div>
      <div className="flex flex-col overflow-hidden">
        <span className="text-sm font-medium truncate">
          {(user as { globalName?: string | null }).globalName ?? user.username}
        </span>
        <span className="text-xs text-muted-foreground truncate">@{user.username}</span>
      </div>
    </div>
  );
}

export function AppLayout({ children }: { children: React.ReactNode }) {
  const [location, setLocation] = useLocation();
  const { data: user, isLoading, error } = useGetMe({ query: { retry: false, queryKey: getGetMeQueryKey() } });

  useEffect(() => {
    if (!isLoading && (error || !user)) {
      window.location.href = "/";
    }
  }, [isLoading, error, user]);

  if (isLoading) {
    return (
      <div className="min-h-screen w-full flex items-center justify-center bg-background">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  if (!user) {
    return null; // Will redirect
  }

  const handleLogout = async () => {
    try {
      await fetch('/api/auth/logout', { method: 'POST' });
    } catch (e) {
      console.error("Logout failed", e);
    }
    window.location.href = "/";
  };

  const navItems = [
    { title: "Estadísticas", href: "/app", icon: LayoutDashboard },
    { title: "Registros", href: "/app/logs", icon: List },
    { title: "Lista Negra", href: "/app/blacklist", icon: ShieldBan },
    { title: "Vouches", href: "/app/vouches", icon: Star },
    { title: "Advertencias", href: "/app/warns", icon: AlertTriangle },
    { title: "Administradores", href: "/app/admins", icon: Users },
    { title: "Chat IA", href: "/app/chat", icon: MessageSquare },
    { title: "Anuncios", href: "/app/anuncios", icon: Megaphone },
    { title: "Ventas", href: "/app/ventas", icon: ShoppingBag },
    { title: "Configuración", href: "/app/configuracion", icon: Settings },
    { title: "Terminal", href: "/app/terminal", icon: Terminal },
  ];

  return (
    <SidebarProvider>
      <div className="flex min-h-screen w-full bg-background">
        <Sidebar className="border-r border-border bg-card">
          <SidebarHeader className="p-4 border-b border-border">
            <h2 className="text-lg font-bold text-primary tracking-tight">MODEOS EL OBI</h2>
          </SidebarHeader>
          <SidebarContent>
            <SidebarGroup>
              <SidebarGroupLabel className="text-xs uppercase tracking-wider text-muted-foreground mt-4 mb-2">
                Navegación
              </SidebarGroupLabel>
              <SidebarGroupContent>
                <SidebarMenu>
                  {navItems.map((item) => (
                    <SidebarMenuItem key={item.href}>
                      <SidebarMenuButton
                        isActive={location === item.href}
                        onClick={() => setLocation(item.href)}
                        className="cursor-pointer w-full flex items-center gap-3"
                      >
                        <item.icon className="w-4 h-4" />
                        <span>{item.title}</span>
                      </SidebarMenuButton>
                    </SidebarMenuItem>
                  ))}
                </SidebarMenu>
              </SidebarGroupContent>
            </SidebarGroup>
          </SidebarContent>
          <SidebarFooter className="p-4 border-t border-border flex flex-col gap-4">
            <UserProfile />
            <Button variant="outline" className="w-full justify-start gap-2" onClick={handleLogout}>
              <LogOut className="w-4 h-4" />
              <span>Cerrar sesión</span>
            </Button>
          </SidebarFooter>
          <SidebarRail />
        </Sidebar>
        
        <main className="flex-1 flex flex-col min-w-0 overflow-hidden">
          <div className="flex-1 overflow-auto p-6 md:p-8">
            <div className="max-w-7xl mx-auto">
              {children}
            </div>
          </div>
        </main>
      </div>
    </SidebarProvider>
  );
}
