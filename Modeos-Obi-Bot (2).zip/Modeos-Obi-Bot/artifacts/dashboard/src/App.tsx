import { Switch, Route, Router as WouterRouter, Redirect } from "wouter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/not-found";

import Login from "@/pages/login";
import { AppLayout } from "@/components/layout";
import StatsPage from "@/pages/stats";
import LogsPage from "@/pages/logs";
import BlacklistPage from "@/pages/blacklist";
import VouchesPage from "@/pages/vouches";
import WarnsPage from "@/pages/warns";
import AdminsPage from "@/pages/admins";
import TerminalPage from "@/pages/terminal";
import AnunciosPage from "@/pages/anuncios";
import VentasPage from "@/pages/ventas";
import ConfiguracionPage from "@/pages/configuracion";
import ChatPage from "@/pages/chat";

const queryClient = new QueryClient();

function Router() {
  return (
    <Switch>
      <Route path="/" component={Login} />
      <Route path="/app">
        <AppLayout>
          <StatsPage />
        </AppLayout>
      </Route>
      <Route path="/app/logs">
        <AppLayout>
          <LogsPage />
        </AppLayout>
      </Route>
      <Route path="/app/blacklist">
        <AppLayout>
          <BlacklistPage />
        </AppLayout>
      </Route>
      <Route path="/app/vouches">
        <AppLayout>
          <VouchesPage />
        </AppLayout>
      </Route>
      <Route path="/app/warns">
        <AppLayout>
          <WarnsPage />
        </AppLayout>
      </Route>
      <Route path="/app/admins">
        <AppLayout>
          <AdminsPage />
        </AppLayout>
      </Route>
      <Route path="/app/anuncios">
        <AppLayout>
          <AnunciosPage />
        </AppLayout>
      </Route>
      <Route path="/app/chat">
        <AppLayout>
          <ChatPage />
        </AppLayout>
      </Route>
      <Route path="/app/ventas">
        <AppLayout>
          <VentasPage />
        </AppLayout>
      </Route>
      <Route path="/app/configuracion">
        <AppLayout>
          <ConfiguracionPage />
        </AppLayout>
      </Route>
      <Route path="/app/terminal">
        <AppLayout>
          <TerminalPage />
        </AppLayout>
      </Route>
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, "")}>
          <Router />
        </WouterRouter>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
