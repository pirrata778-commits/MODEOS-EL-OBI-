# Workspace

## Overview

pnpm workspace monorepo using TypeScript. Each package manages its own dependencies.

## Stack

- **Monorepo tool**: pnpm workspaces
- **Node.js version**: 24
- **Package manager**: pnpm
- **TypeScript version**: 5.9
- **API framework**: Express 5
- **Database**: PostgreSQL + Drizzle ORM
- **Validation**: Zod (`zod/v4`), `drizzle-zod`
- **API codegen**: Orval (from OpenAPI spec)
- **Build**: esbuild (CJS bundle)

## Key Commands

- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- `pnpm --filter @workspace/api-server run dev` — run API server locally

## Discord Bot — "Modeos el obi"

The API server also boots a Discord bot (discord.js v14) on startup.

- Code: `artifacts/api-server/src/bot/`
  - `index.ts` — bot bootstrap, slash command router, handlers
  - `commands.ts` — slash command definitions registered globally
  - `store.ts` — Drizzle-backed data layer (config, vouches, warns, blacklist, sales, events)
  - `logger-events.ts` — Discord event listeners that persist to DB and mirror to the configured log channel
- Persistence: Replit Postgres via `@workspace/db` (`DATABASE_URL`). Schema in `lib/db/src/schema/bot.ts` (tables: `guild_configs`, `vouches`, `warns`, `blacklist`, `sales`, `event_logs`). Push with `pnpm --filter @workspace/db run push`.
- Required secret: `DISCORD_BOT_TOKEN`
- Required Discord intents (privileged): Server Members + Message Content. Non-privileged: Guilds, GuildMessages, GuildModeration.
- Required bot permissions: Manage Roles, Manage Channels (tickets), Ban/Kick Members, Send Messages, Embed Links, View Audit Log (for ban actor attribution).
- Login uses an exponential-backoff retry to ride out occasional Discord/Cloudflare 520 gateway hiccups.

Slash commands:

**Admin / setup**
- `/setup` — configures any of: `rol_verificado`, `rol_staff`, `canal_anuncios`, `canal_bienvenida`, `canal_ventas`, `canal_vouches`, `categoria_tickets`, `canal_logs`
- `/config` — show current configuration
- `/verificacion [titulo] [descripcion]` — publish the verification panel with a button in the current channel
- `/comunicado titulo mensaje [canal] [color] [mencionar_todos]` — post an embed announcement

**Marketplace (everyone)**
- `/venta nombre miembros precio nicho descripcion [metodos_pago] [imagen]` — publish a Discord-server listing in the configured sales channel with a "Contactar al vendedor" link button
- `/vouch vendedor estrellas comentario` — leave a 1-5★ review for a seller; published in the vouches channel
- `/vouches vendedor` — show a seller's reputation summary and last reviews

**Tickets (everyone)**
- `/ticket motivo` — opens a private channel under the tickets category, accessible by the user, the staff role and admins; pings staff
- `/cerrar` (or "Cerrar ticket" button) — closes the current ticket after 5s

**Moderation**
- `/limpiar cantidad` — bulk-delete N messages (Manage Messages)
- `/warn usuario razon` — formal warning, DM'd to user, persisted (Moderate Members)
- `/warns usuario` — list a user's warnings
- `/kick usuario [razon]`, `/ban usuario [razon]`
- `/blacklist add usuario razon` — adds the user to the blacklist and bans them; will be re-banned automatically if they ever rejoin
- `/blacklist remove usuario` — removes from blacklist and unbans
- `/blacklist check usuario` — check whether a user is blacklisted (with reason and who added them)
- `/blacklist list` — show all blacklisted users for the guild

**Logs**
- `/logs [cantidad]` — shows the most recent events stored in the DB (1-25)
- All events also mirror in real time to the channel set with `/setup canal_logs:<canal>`

**Info**
- `/stats` — server statistics (members, channels, vouches recorded, etc.)
- `/avatar [usuario]` — show a user's avatar

**Auto behavior**
- On member join, posts a styled welcome embed in the configured welcome channel, mentioning the verification, sales and vouches channels.
- Blacklisted users that try to rejoin are auto-banned again.
- Event logger captures: member joins/leaves, bans/unbans/kicks, message deletes, message edits, channel create/delete, role create/delete, role updates on members, plus every bot action (verification, sale, vouch, ticket open/close, warn, announcement, blacklist, setup, clear). Each event is persisted to `event_logs` and posted as a colored embed in `canal_logs`.

Verification flow: users click the "Verificarme" button on the verification panel and receive the configured role, unlocking access to the "venta de Discords" zone.

See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details.
