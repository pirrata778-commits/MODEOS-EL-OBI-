---
name: Node hosting
description: Decisiones y restricciones para ejecutar el bot y dashboard como un servicio Node.js externo.
---

El despliegue externo debe arrancar con `npm start`; el script construye el API y el dashboard antes de iniciar el servidor Node. El proceso debe buscar el dashboard tanto desde la raíz del monorepo como desde el directorio del workspace del API, porque npm puede ejecutar scripts con cualquiera de esos directorios como `cwd`.

**Why:** En hosts Node.js, el comando se ejecuta a menudo dentro del workspace seleccionado y las rutas basadas únicamente en `process.cwd()` pueden producir un 404 aunque el build haya terminado correctamente.

**How to apply:** Mantener `npm start` como punto de entrada público, conservar el build del dashboard como parte del arranque y probar siempre la URL `/` además del build del API.