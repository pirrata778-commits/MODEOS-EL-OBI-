---
name: Database schema push
description: Protección de la tabla de sesiones al cambiar el esquema PostgreSQL
---

Los cambios de esquema de este proyecto deben ser aditivos. La tabla `user_sessions` la crea el middleware de sesiones y no está declarada en el esquema Drizzle; un `drizzle-kit push` puede interpretarla como una tabla sobrante y proponer borrarla.

**Why:** Aceptar ese prompt eliminaría sesiones activas y puede romper la autenticación del dashboard.

**How to apply:** Para nuevas columnas o tablas, rechazar cualquier propuesta de borrado y aplicar únicamente DDL aditivo en la base de desarrollo; usar el flujo de publicación de Replit para propagar el esquema a producción.