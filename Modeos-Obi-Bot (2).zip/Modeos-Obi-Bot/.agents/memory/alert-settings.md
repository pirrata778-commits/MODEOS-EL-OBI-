---
name: Alert controls
description: Criterio para controlar las alertas de actividad del bot
---

Las alertas de actividad deben tener controles independientes de los módulos funcionales. Se agrupan por tipo de evento para poder silenciar, por ejemplo, mensajes sin desactivar toda la moderación.

**Why:** Los interruptores de módulos controlan si una función puede ejecutarse; las alertas controlan si su actividad aparece en logs. Mezclar ambos comportamientos impide configurarlos con precisión.

**How to apply:** Las nuevas categorías de eventos deben añadirse como una preferencia activada por defecto y filtrarse antes de persistir o publicar el evento.