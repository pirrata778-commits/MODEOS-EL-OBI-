import {
  pgTable,
  serial,
  text,
  integer,
  boolean,
  timestamp,
  index,
  uniqueIndex,
  jsonb,
} from "drizzle-orm/pg-core";

export const guildConfigsTable = pgTable("guild_configs", {
  guildId: text("guild_id").primaryKey(),
  verifiedRoleId: text("verified_role_id"),
  staffRoleId: text("staff_role_id"),
  announcementChannelId: text("announcement_channel_id"),
  welcomeChannelId: text("welcome_channel_id"),
  salesChannelId: text("sales_channel_id"),
  vouchChannelId: text("vouch_channel_id"),
  ticketsCategoryId: text("tickets_category_id"),
  logChannelId: text("log_channel_id"),
  verificationChannelId: text("verification_channel_id"),
  verificationMessageId: text("verification_message_id"),
  welcomeEnabled: boolean("welcome_enabled").notNull().default(true),
  verificationEnabled: boolean("verification_enabled").notNull().default(true),
  loggingEnabled: boolean("logging_enabled").notNull().default(true),
  statsChannelsEnabled: boolean("stats_channels_enabled").notNull().default(true),
  announcementsEnabled: boolean("announcements_enabled").notNull().default(true),
  salesEnabled: boolean("sales_enabled").notNull().default(true),
  vouchesEnabled: boolean("vouches_enabled").notNull().default(true),
  ticketsEnabled: boolean("tickets_enabled").notNull().default(true),
  memberJoinAlertsEnabled: boolean("member_join_alerts_enabled").notNull().default(true),
  memberLeaveAlertsEnabled: boolean("member_leave_alerts_enabled").notNull().default(true),
  moderationAlertsEnabled: boolean("moderation_alerts_enabled").notNull().default(true),
  messageAlertsEnabled: boolean("message_alerts_enabled").notNull().default(true),
  channelAlertsEnabled: boolean("channel_alerts_enabled").notNull().default(true),
  roleAlertsEnabled: boolean("role_alerts_enabled").notNull().default(true),
  verificationAlertsEnabled: boolean("verification_alerts_enabled").notNull().default(true),
  announcementAlertsEnabled: boolean("announcement_alerts_enabled").notNull().default(true),
  saleAlertsEnabled: boolean("sale_alerts_enabled").notNull().default(true),
  vouchAlertsEnabled: boolean("vouch_alerts_enabled").notNull().default(true),
  ticketAlertsEnabled: boolean("ticket_alerts_enabled").notNull().default(true),
  setupAlertsEnabled: boolean("setup_alerts_enabled").notNull().default(true),
  welcomeTitle: text("welcome_title"),
  welcomeMessage: text("welcome_message"),
  welcomeFooter: text("welcome_footer"),
  welcomeColor: text("welcome_color"),
  updatedAt: timestamp("updated_at", { withTimezone: true })
    .defaultNow()
    .notNull(),
});

export type GuildConfigRow = typeof guildConfigsTable.$inferSelect;

export const vouchesTable = pgTable(
  "vouches",
  {
    id: serial("id").primaryKey(),
    guildId: text("guild_id").notNull(),
    sellerId: text("seller_id").notNull(),
    buyerId: text("buyer_id").notNull(),
    buyerTag: text("buyer_tag").notNull(),
    stars: integer("stars").notNull(),
    comment: text("comment").notNull(),
    createdAt: timestamp("created_at", { withTimezone: true })
      .defaultNow()
      .notNull(),
  },
  (table) => ({
    bySeller: index("vouches_by_seller_idx").on(table.guildId, table.sellerId),
  }),
);

export type VouchRow = typeof vouchesTable.$inferSelect;

export const warnsTable = pgTable(
  "warns",
  {
    id: serial("id").primaryKey(),
    guildId: text("guild_id").notNull(),
    userId: text("user_id").notNull(),
    userTag: text("user_tag").notNull(),
    moderatorId: text("moderator_id").notNull(),
    reason: text("reason").notNull(),
    createdAt: timestamp("created_at", { withTimezone: true })
      .defaultNow()
      .notNull(),
  },
  (table) => ({
    byUser: index("warns_by_user_idx").on(table.guildId, table.userId),
  }),
);

export type WarnRow = typeof warnsTable.$inferSelect;

export const blacklistTable = pgTable(
  "blacklist",
  {
    id: serial("id").primaryKey(),
    guildId: text("guild_id").notNull(),
    userId: text("user_id").notNull(),
    userTag: text("user_tag").notNull(),
    reason: text("reason").notNull(),
    addedById: text("added_by_id").notNull(),
    addedByTag: text("added_by_tag").notNull(),
    createdAt: timestamp("created_at", { withTimezone: true })
      .defaultNow()
      .notNull(),
  },
  (table) => ({
    uniqueEntry: uniqueIndex("blacklist_guild_user_unique").on(
      table.guildId,
      table.userId,
    ),
  }),
);

export type BlacklistRow = typeof blacklistTable.$inferSelect;

export const salesTable = pgTable(
  "sales",
  {
    id: serial("id").primaryKey(),
    guildId: text("guild_id").notNull(),
    sellerId: text("seller_id").notNull(),
    sellerTag: text("seller_tag").notNull(),
    name: text("name").notNull(),
    members: integer("members").notNull(),
    price: text("price").notNull(),
    niche: text("niche").notNull(),
    description: text("description").notNull(),
    paymentMethods: text("payment_methods"),
    imageUrl: text("image_url"),
    messageId: text("message_id"),
    channelId: text("channel_id"),
    createdAt: timestamp("created_at", { withTimezone: true })
      .defaultNow()
      .notNull(),
  },
  (table) => ({
    bySeller: index("sales_by_seller_idx").on(table.guildId, table.sellerId),
  }),
);

export type SaleRow = typeof salesTable.$inferSelect;

export const eventLogsTable = pgTable(
  "event_logs",
  {
    id: serial("id").primaryKey(),
    guildId: text("guild_id").notNull(),
    eventType: text("event_type").notNull(),
    actorId: text("actor_id"),
    actorTag: text("actor_tag"),
    targetId: text("target_id"),
    targetTag: text("target_tag"),
    channelId: text("channel_id"),
    summary: text("summary").notNull(),
    metadata: jsonb("metadata"),
    createdAt: timestamp("created_at", { withTimezone: true })
      .defaultNow()
      .notNull(),
  },
  (table) => ({
    byGuildTime: index("event_logs_guild_time_idx").on(
      table.guildId,
      table.createdAt,
    ),
    byEvent: index("event_logs_event_idx").on(
      table.guildId,
      table.eventType,
    ),
  }),
);

export type EventLogRow = typeof eventLogsTable.$inferSelect;

export const dashboardAdminsTable = pgTable(
  "dashboard_admins",
  {
    id: serial("id").primaryKey(),
    guildId: text("guild_id").notNull(),
    userId: text("user_id").notNull(),
    userTag: text("user_tag").notNull(),
    addedById: text("added_by_id").notNull(),
    createdAt: timestamp("created_at", { withTimezone: true })
      .defaultNow()
      .notNull(),
  },
  (table) => ({
    uniqueAdmin: uniqueIndex("dashboard_admins_guild_user_unique").on(
      table.guildId,
      table.userId,
    ),
  }),
);

export type DashboardAdminRow = typeof dashboardAdminsTable.$inferSelect;
